import {
	Component,
	OnInit,
	ChangeDetectionStrategy,
}                       from '@angular/core';
import { MatDialogRef } from "@angular/material/dialog";

import { ModalService } from '../../../infrastructure/core/services/modal.service';

@Component({
	selector        : 'hg-dependent-member-documents-dialog',
	template        :
		`<hg-dependent-member-document-list
		></hg-dependent-member-document-list>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class DependentMemberDocumentsDialogComponent implements OnInit {
	constructor(
		private dialogRef: MatDialogRef<DependentMemberDocumentsDialogComponent>,
		private modals: ModalService,
	) { }

	public ngOnInit(): void {
		this.modals.addModal(this.dialogRef);
	}
}
