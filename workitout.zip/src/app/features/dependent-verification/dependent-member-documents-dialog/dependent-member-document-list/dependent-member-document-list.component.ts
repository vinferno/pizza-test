import {
	Component,
	ChangeDetectionStrategy,
	Inject,
	OnInit,
}                              from '@angular/core';
import { MAT_DIALOG_DATA } from "@angular/material/dialog";

import { Observable }          from 'rxjs';
import { Store }               from '@ngrx/store';

import {
	DependentGridList,
	DependentMemberDocumentList,
	DependentMemberDocumentPayload,
}                              from 'app/infrastructure/interfaces/dependent-grid';
import { MyDependentsService } from 'app/infrastructure/core/services/mydependents.service';
import { SettingsState }       from 'app/infrastructure/store/reducers/settings/settings-state';
import { TableColumns } from 'app/infrastructure/interfaces/table-columns';

@Component({
	selector    : 'hg-dependent-member-document-list',
	template        :
		`<hg-dependent-member-document-list-presentation
			[columnList]="columnList"
			[dependentMemberDocumentList]="(dependentMemberDocumentList$ | async)"
			[settings]="settingsState$ | async"
		></hg-dependent-member-document-list-presentation>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class DependentMemberDocumentListComponent implements OnInit {
	public columnList: TableColumns[] = [
		{
			columnName : 'Document',
			columnId   : 'documentName',
		},
		{
			columnName : 'Received On',
			columnId   : 'receivedDate',
		},
		{
			columnName : 'Reviewed On',
			columnId   : 'reviewedDate',
		},
	];
	public dependentMemberDocumentList$: Observable<DependentMemberDocumentList>;
	public settingsState$: Observable<SettingsState>;
	constructor(
		@Inject(MAT_DIALOG_DATA) public selectedDependent: DependentGridList,
		private myDependentsService: MyDependentsService,
		public store: Store<any>,
	) { }
	public ngOnInit(): void {
		this.initializeState();
		this.dependentMemberDocumentList$ = this.getDependentMemberDocumentList(this.selectedDependent.dependentID);
	}

	private initializeState(): void {
		this.settingsState$ = this.store.select('settingsState');
	}

	private getDependentMemberDocumentList(id: number) {
		const payload: DependentMemberDocumentPayload = { id }
		return this.myDependentsService.getDependentMemberDocumentList(payload);
	}
}
