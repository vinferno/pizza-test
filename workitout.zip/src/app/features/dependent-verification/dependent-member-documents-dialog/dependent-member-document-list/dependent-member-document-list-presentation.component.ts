import {
	Component,
	ChangeDetectionStrategy,
	Input,
}                                      from '@angular/core';
import { MatDialogRef } 			   from '@angular/material/dialog';
import { DependentMemberDocumentList } from 'app/infrastructure/interfaces/dependent-grid';
import { SettingsState }               from 'app/infrastructure/store/reducers/settings/settings-state';
import { TableColumns }                from 'app/infrastructure/interfaces/table-columns';


@Component({
	selector        : 'hg-dependent-member-document-list-presentation',
	templateUrl     : './dependent-member-document-list-presentation.component.html',
	styleUrls       : ['./dependent-member-document-list-presentation.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class DependentMemberDocumentListPresentationComponent {
	@Input() public columnList: TableColumns[];
	@Input() public dependentMemberDocumentList: DependentMemberDocumentList;
	@Input() public settings: SettingsState;

	constructor(
		private dialogRef: MatDialogRef<DependentMemberDocumentListPresentationComponent>,
	) { }

	close(): void {
		this.dialogRef.close();
	}
}
