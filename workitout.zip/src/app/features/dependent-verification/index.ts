import { DependentMemberDocumentsDialogComponent }          from './dependent-member-documents-dialog/dependent-member-document-dialog.component';
import { DependentMemberDocumentListComponent }             from './dependent-member-documents-dialog/dependent-member-document-list/dependent-member-document-list.component';
import { DependentMemberDocumentListPresentationComponent } from './dependent-member-documents-dialog/dependent-member-document-list/dependent-member-document-list-presentation.component';
import { UploadDependentDocumentsComponent }                from './upload-dependent-documents-dialog/upload-dependent-documents/upload-dependent-documents.component';
import { UploadDependentDocumentsDialogComponent }          from './upload-dependent-documents-dialog/upload-dependent-documents-dialog.component';

export const DependentVerifyComponents = [
	DependentMemberDocumentsDialogComponent,
	DependentMemberDocumentListComponent,
	DependentMemberDocumentListPresentationComponent,
	UploadDependentDocumentsDialogComponent,
	UploadDependentDocumentsComponent,
];

export const DependentVerifyEntryComponents = [
	DependentMemberDocumentsDialogComponent,
	UploadDependentDocumentsDialogComponent,
];
