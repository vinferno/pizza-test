import {
	Component,
	Inject,
	EventEmitter,
	OnDestroy,
	OnInit,
	Output,
}                              from '@angular/core';
import { MAT_DIALOG_DATA } from "@angular/material/dialog";

import { Store }               from '@ngrx/store';
import {
	Observable,
	Subscription,
}                              from 'rxjs';

import { Constants }           from 'app/infrastructure/utils/constants';
import {
	DependentGridList,
	DependentDocumentPayload,
}                              from '../../../../infrastructure/interfaces/dependent-grid';
import { FileUploadResponse }  from 'app/infrastructure/interfaces/file-upload-response';
import { FileUploadService }   from 'app/infrastructure/core/services/file-upload.service';
import { MyDependentsService } from '../../../../infrastructure/core/services/mydependents.service';
import { SettingsState }       from '../../../../infrastructure/store/reducers/settings/settings-state';
import { MatDialogRef } 	   from '@angular/material/dialog';

@Component({
	selector    : 'hg-upload-dependent-documents',
	templateUrl : './upload-dependent-documents.component.html',
	styleUrls   : ['./upload-dependent-documents.component.scss'],
})
export class UploadDependentDocumentsComponent implements OnInit, OnDestroy {
	@Output() public emitClose = new EventEmitter<FileUploadResponse>();

	public acceptedFileListString = '.pdf, .png, .jpg, .jpeg';
	public disabled: boolean = false;
	public fileListArray: File[] = [];
	public filenameLengthError: string = `File names must be shorter than ${Constants.MAXFILENAMELENGTH} characters.`;
	public fileSelectMultipleMsg: string = 'No file(s) selected yet.';
	public formInstructions: string = '';
	public hasStartedFilenameSizeCheck: boolean;
	public hasStartedSizeCheck: boolean;
	public hasStartedTypeCheck: boolean;
	public payload: DependentDocumentPayload = new DependentDocumentPayload();
	public settings: SettingsState;
	public uploadButtonText: string = 'Choose Dependent Documents';

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private fileUploadService: FileUploadService,
		@Inject(MAT_DIALOG_DATA) public selectedDependent: DependentGridList,
		private myDependentsService: MyDependentsService,
		private store: Store<any>,
		private dialogRef: MatDialogRef<UploadDependentDocumentsComponent>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
		this.formInstructions = `
			Please upload dependent verification documentation.</br>
			The following file types are accepted: ${this.acceptedFileListString}.</br>
			Files must be smaller than 5MB.</br>
		`;
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public selectMultipleEvent(fileList: FileList | File): void {
		this.fileListArray = this.fileUploadService.selectMultipleEvent(fileList);
		const file: string = (this.fileListArray.length > 1) ? 'Files' : 'File';
		this.uploadButtonText = (this.fileListArray.length > 0)
			? `Upload ${this.fileListArray.length} ${file} Selected`
			: `Choose Dependent Documents`;
		this.checkForFilenameSizeError();
		this.checkForSizeError();
		this.checkForTypeError();
	}

	public uploadMultipleEvent(fileList: File[]): void {
		if (this.selectedDependent.dependentID && fileList && fileList.length) {
			this.payload = {
				dependentID : this.selectedDependent.dependentID,
				files       : fileList,
			};
			this.myDependentsService.uploadDependentDocument(this.payload).subscribe(response => this.emitClose.emit(response));
		}
	}

	public cancelMultipleEvent(): void {
		this.fileListArray = [];
		this.uploadButtonText = '';
		this.hasStartedFilenameSizeCheck = false;
		this.hasStartedSizeCheck = false;
		this.hasStartedTypeCheck = false;
		this.fileUploadService.cancelMultipleEvent();
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
	}

	private checkForFilenameSizeError(): boolean {
		return this.hasStartedFilenameSizeCheck = this.fileUploadService.checkForFilenameSizeError();
	}

	private checkForSizeError(): boolean {
		return this.hasStartedSizeCheck = this.fileUploadService.checkForSizeError();
	}

	private checkForTypeError(): boolean {
		return this.hasStartedTypeCheck = this.fileUploadService.checkForTypeError();
	}

	close(): void {
		this.dialogRef.close();
	}
}
