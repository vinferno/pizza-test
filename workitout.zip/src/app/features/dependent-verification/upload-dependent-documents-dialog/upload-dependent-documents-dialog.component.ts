import {
	Component,
	OnInit,
	ChangeDetectionStrategy,
}                             from '@angular/core';
import { MatDialogRef } from "@angular/material/dialog";

import { ModalService }       from '../../../infrastructure/core/services/modal.service';
import { FileUploadResponse } from 'app/infrastructure/interfaces/file-upload-response';

@Component({
	selector        : 'hg-upload-dependent-documents-dialog',
	template        :
		`<hg-upload-dependent-documents
			(emitClose)="closeModal($event)"
		></hg-upload-dependent-documents>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class UploadDependentDocumentsDialogComponent implements OnInit {
	constructor(
		private dialogRef: MatDialogRef<UploadDependentDocumentsDialogComponent>,
		private modals: ModalService,
	) { }

	public ngOnInit(): void {
		this.modals.addModal(this.dialogRef);
	}

	public closeModal(response: FileUploadResponse): void {
		this.dialogRef.close(response);
	}
}
