import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                                  from '@angular/core';
import { MatDialog, MatDialogRef, MatDialogConfig } from "@angular/material/dialog";
import { ActivatedRoute }                          from '@angular/router';

import { Store }                                   from '@ngrx/store';
import { Observable }                              from 'rxjs';

import { DependentGridList }                       from 'app/infrastructure/interfaces/dependent-grid';
import { ModalService }                            from 'app/infrastructure/core/services/modal.service';
import { SettingsState }                           from 'app/infrastructure/store/reducers/settings/settings-state';
import { TableColumns }                            from 'app/infrastructure/interfaces/table-columns';
import { DependentMemberDocumentsDialogComponent } from './dependent-member-documents-dialog/dependent-member-document-dialog.component';
import { UploadDependentDocumentsDialogComponent } from './upload-dependent-documents-dialog/upload-dependent-documents-dialog.component';

@Component({
	selector        : 'hg-dependent-verification',
	template        :
		`<hg-dependent-verification-presentation
			[columnList]="columnList"
			[dependentList]="dependentList"
			[settings]="(settingsState$ | async)"
			(emitDependentDocumentsDialog)="prepareDependentDocumentsDialog($event)"
			(emitUploadDialog)="prepareUploadDialog($event)"
		></hg-dependent-verification-presentation>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class DependentVerificationSmartComponent implements OnInit, OnDestroy {
	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId: 'dependentName',
		},
		{
			columnName: 'Relationship',
			columnId: 'dependentRelationship',
			width: 200,
		},
		{
			columnName: 'Gender',
			columnId: 'dependentGender',
			width: 100,
		},
	];
	public dependentList: DependentGridList[];
	public settingsState$: Observable<SettingsState>;

	private dialogConfig: MatDialogConfig = { autoFocus: false };

	constructor(
		private cd: ChangeDetectorRef,
		private dialog: MatDialog,
		private modals: ModalService,
		private route: ActivatedRoute,
		private store: Store<any>,
	) {
		this.dependentList = this.route.snapshot.data['dependents'].dependents;
	}

	public ngOnInit(): void {
		this.initializeState();
	}

	public ngOnDestroy(): void {
		this.cd.detach();
	}

	public prepareDependentDocumentsDialog(dependent: DependentGridList): void {
		this.openDependentDocumentsDialog(DependentMemberDocumentsDialogComponent, dependent);
	}

	public prepareUploadDialog(dependent: DependentGridList): void {
		this.openUploadDialog(UploadDependentDocumentsDialogComponent, dependent);
	}

	private initializeState(): void {
		this.settingsState$ = this.store.select('settingsState');
	}

	private openDependentDocumentsDialog(component, id: DependentGridList): void {
		const dialogRef: MatDialogRef<DependentMemberDocumentsDialogComponent> = (!id)
			? this.dialog.open(component, this.dialogConfig)
			: this.dialog.open(component, { data: id, autoFocus: false });

		dialogRef.beforeClose().subscribe(response => {
			if (response) { this.dependentList = response.dependents; }

			this.cd.detectChanges();
		});
		this.modals.addModal(dialogRef);
	}

	private openUploadDialog(component, id: DependentGridList): void {
		const dialogRef: MatDialogRef<UploadDependentDocumentsDialogComponent> = (!id)
			? this.dialog.open(component, this.dialogConfig)
			: this.dialog.open(component, { data: id, autoFocus: false });

		dialogRef.beforeClose().subscribe(response => {
			if (response) { this.dependentList = response.dependents; }

			this.cd.detectChanges();
		});
		this.modals.addModal(dialogRef);
	}
}
