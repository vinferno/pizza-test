import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                            from '@angular/core';

import { animator }          from 'app/infrastructure/core/animations/animations';
import { DependentGridList } from 'app/infrastructure/interfaces/dependent-grid';
import { SettingsState }     from 'app/infrastructure/store/reducers/settings/settings-state';
import { TableColumns }      from 'app/infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-dependent-verification-presentation',
	templateUrl     : './dependent-verification-presentation.component.html',
	styleUrls       : ['./dependent-verification-presentation.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
	animations      : [animator.slide],
})
export class DependentVerificationPresentationComponent {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	@Input() public columnList: TableColumns[];
	@Input() public dependentList: DependentGridList[];
	@Input() public settings: SettingsState;

	@Output() public emitDependentDocumentsDialog: EventEmitter<DependentGridList> = new EventEmitter();
	@Output() public emitUploadDialog: EventEmitter<DependentGridList> = new EventEmitter();

	public prepareDependentDocumentsDialog(dependent: DependentGridList): void {
		this.emitDependentDocumentsDialog.emit(dependent);
	}

	public prepareUploadDialog(dependent: DependentGridList): void {
		this.emitUploadDialog.emit(dependent);
	}
}
