import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
}                              from '@angular/core';
import {
	FormBuilder,
	FormGroup,
	Validators,
}                              from '@angular/forms';
import { Router }              from '@angular/router';

import {
	Observable,
	Subscription,
}                              from 'rxjs';
import { Store }               from '@ngrx/store';

import { animator }            from '../../../../infrastructure/core/animations/animations';
import { Dependent }           from '../../../../infrastructure/interfaces/dependent';
import { DependentGridList }   from '../../../../infrastructure/interfaces/dependent-grid';
import { EnrollmentState }     from '../../../../infrastructure/store/reducers/enrollment/enrollment-state';
import { MyDependentsService } from '../../../../infrastructure/core/services/mydependents.service';
import { SettingsState }       from '../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }        from '../../../../infrastructure/interfaces/table-columns';


@Component({
	selector        : 'hg-widget-add-dependent',
	templateUrl     : './widget-add-dependent.component.html',
	styleUrls       : ['./widget-add-dependent.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class WidgetAddDependentComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId: 'dependentName',
		},
		{
			columnName: 'Age',
			columnId: 'dependentAge',
		},
		{
			columnName: 'Relationship',
			columnId: 'dependentRelationship',
		},
		{
			columnName: 'Gender',
			columnId: 'dependentGender',
		},
	];
	public emptyGridMessage: string = 'No dependents.';
	public enrollment: EnrollmentState;
	public form: FormGroup;
	public dependent: Dependent = new Dependent();
	public dependentList: DependentGridList[] = [];
	public dependentPayload: Dependent = new Dependent();
	public saveLabels = {
		confirm : 'Save',
		cancel  : 'Cancel',
	};
	public settings: SettingsState;

	private enrollmentState: Observable<EnrollmentState>;
	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private fb: FormBuilder,
		private cd: ChangeDetectorRef,
		private myDependentsService: MyDependentsService,
		private router: Router,
		private store: Store<any>,
	) { }
	ngOnInit(): void {
		this.initializeState();
		this.getDependentList();
		this.getAddDependent();
	}

	ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public saveDependentandContinue(): void {
		this.buildDependentPayload();
		this.myDependentsService.setAddDependent(this.dependentPayload).subscribe(() => {
			this.resetForm();
			this.getDependentList();
		});
	}

	public saveDependentAndFinish(): void {
		this.buildDependentPayload();
		this.myDependentsService.setAddDependent(this.dependentPayload).subscribe(() => this.routeToWidget());
	}

	public cancel(): void {
		this.routeToWidget();
	}

	private getDependentList(): void {
		this.myDependentsService.getDependentList().subscribe(response => {
			this.dependentList = response.dependents;
			this.cd.detectChanges();
		});
	}

	private getAddDependent(): void {
		this.myDependentsService.getAddDependent().subscribe(response => {
			this.dependent = response;
			this.form = this.buildForm(this.dependent);
			this.cd.detectChanges();
		});
	}

	private initializeState(): void {
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => { this.enrollment = enrollment; });
		this.subscriptions.push(enrollmentSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
	}

	private buildForm(dependent: Dependent): FormGroup {
		const addDependentForm = this.fb.group({
			firstName: [dependent.firstName, Validators.compose([Validators.required])],
			middleName: [dependent.middleName],
			lastName: [dependent.lastName, Validators.compose([Validators.required])],
			suffix: [dependent.suffix],
			dependentSsn: [dependent.dependentSsn],
			dependentGender: [dependent.dependentGender, Validators.compose([Validators.required])],
			dependentDateOfBirth: ['', Validators.compose([Validators.required])],
			dependentAge: [dependent.dependentAge, Validators.compose([Validators.required])],
			dependentRelationship: [dependent.dependentRelationship, Validators.compose([Validators.required])],
		});

		return addDependentForm;
	}

	private buildDependentPayload(): void {
		for (const property in this.dependentPayload) {
			if (this.dependentPayload.hasOwnProperty(property) && this.form.value.hasOwnProperty(property)) {
				this.dependentPayload[property] = this.form.controls[property].value;
			}
		}
		this.dependentPayload.id = this.dependent.id;
	}

	private routeToWidget(): void {
		this.router.navigateByUrl(`/enrollment-dashboard/${this.enrollment.selectedCategory.categoryID}`);
	}

	private resetForm(): void {
		for (const property in this.form.controls) {
			if (this.form.controls.hasOwnProperty(property)) {
				(property === 'dependentDateOfBirth')
					? this.form.controls[property].setValue('')
					: this.form.controls[property].setValue(this.dependent[property]);
			}
		}
	}
}
