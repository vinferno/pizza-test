import {
	Component,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	HostBinding,
} 										from '@angular/core';
import { Observable }   				from 'rxjs';
import { Store }                      	from '@ngrx/store';

import { animator }                   	from '../../../../infrastructure/core/animations/animations';
import { stateActions }               	from '../../../../infrastructure/store/reducers/reducers-index';
import { EnrollmentDashboardService } 	from '../../../../infrastructure/enrollment/enrollment-dashboard.service';
import { Utils }                      	from '../../../../infrastructure/utils/utils';
import { EnrollmentState }            	from '../../../../infrastructure/store/reducers/enrollment/enrollment-state';
import { SettingsState }              	from '../../../../infrastructure/store/reducers/settings/settings-state';

import { checkout } 					from '../../../../features/enrollment/enrollment-dashboard/enrollment-categories';

const utils = new Utils()

@Component({
	selector: 'hg-benefit-location',
	templateUrl: './benefit-location.component.html',
	styleUrls: ['./benefit-location.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
	animations: [animator.slide],
})
export class BenefitLocationComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public subscriptions = [];
	public enrollment: EnrollmentState;
	public urlState;
	public url;
	public showIntro: boolean = true;
	public settings: SettingsState;
	public settingsState: Observable<SettingsState>;

	constructor(
		public cd: ChangeDetectorRef,
		public store: Store<any>,
		public enrollmentDashboardService: EnrollmentDashboardService,
	) { }

	ngOnInit() {
		this.initializeState();
		this.cd.detectChanges();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
		this.store.dispatch(stateActions.enrollmentActions.updateShowIntro(false));
		this.store.dispatch(stateActions.enrollmentActions.updateIntroAvailable(false));
		this.store.dispatch(stateActions.enrollmentActions.updateCategoryHTML(null));
		this.store.dispatch(stateActions.enrollmentActions.updateCategoryOptionHTML(null));
		this.cd.detach();
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe( settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		const enrollmentSubscription = this.store.select('enrollmentState').subscribe( enrollment => {
			this.enrollment = enrollment;
			if (this.enrollment && this.enrollment.categoryHTML ) {
				if (!this.enrollment.introAvailable && this.enrollment.type !== stateActions.enrollmentActions.types.ENROLLMENT_UPDATE_INTRO_AVAILABLE) {
					this.store.dispatch(stateActions.enrollmentActions.updateIntroAvailable(true));
				}
				if (!this.enrollment.showIntro && this.enrollment.type !==  stateActions.enrollmentActions.types.ENROLLMENT_UPDATE_SHOW_INTRO
						&& this.enrollment.type !== stateActions.uiActions.types.UI_UPDATE_WINDOW_WIDTH
						&& this.enrollment.type !== stateActions.uiActions.types.UI_UPDATE_MEDIA_QUERY_STATE) {
					this.store.dispatch(stateActions.enrollmentActions.updateShowIntro(true));
				}
			} else {
				if (this.enrollment) {
					if (this.enrollment.introAvailable && this.enrollment.type !== stateActions.enrollmentActions.types.ENROLLMENT_UPDATE_INTRO_AVAILABLE) {
						this.store.dispatch(stateActions.enrollmentActions.updateIntroAvailable(false));
					}
					if (this.enrollment.showIntro && this.enrollment.type !== stateActions.enrollmentActions.types.ENROLLMENT_UPDATE_SHOW_INTRO) {
						this.store.dispatch(stateActions.enrollmentActions.updateShowIntro(false));
					}
				}
			}
			this.cd.detectChanges();
		});
		this.subscriptions.push(enrollmentSubscription);
		this.urlState = this.store.select('routerState');
		const urlSub = this.urlState.subscribe( url => {
			this.url = url;
			this.cd.detectChanges();
		});
		this.subscriptions.push(urlSub);
	}

	public toggleIntro() {
		this.store.dispatch(stateActions.enrollmentActions.updateShowIntro(false));
	}

	public nextCategory(): void {
		const categories = this.enrollment.companyCategories.benefitCategories;
		const currentCategory = this.enrollment.selectedCategory;
		let category: any;
		for (let i = 0; i < categories.length; i++) {
			if (categories[i].id === currentCategory.categoryID) {
				category = categories[i + 1];
			}
		}
		if (category === undefined) {
			category = checkout;
		}
		this.enrollmentDashboardService.setSelectedCategory(category);
	}
}
