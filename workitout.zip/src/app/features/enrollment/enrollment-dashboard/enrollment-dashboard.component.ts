import {
	ChangeDetectorRef,
	Component,
	OnDestroy,
	OnInit,
	HostBinding,
} from '@angular/core';

import { Store } from '@ngrx/store';
import { animator } from '../../../infrastructure/core/animations/animations';
import { EnrollmentDashboardService } from '../../../infrastructure/enrollment/enrollment-dashboard.service';
import { EnrollmentState } from '../../../infrastructure/store/reducers/enrollment/enrollment-state';
import { EndingBenefit } from '../../../infrastructure/store/reducers/ending-benefit/ending-benefit';
@Component({
	selector: 'hg-enrollment-dashboard',
	templateUrl: './enrollment-dashboard.component.html',
	styleUrls: ['./enrollment-dashboard.component.scss'],
	animations: [animator.slide],
})
export class EnrollmentDashboardComponent implements OnDestroy, OnInit {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public endingBenefit: EndingBenefit;
	public enrollment: EnrollmentState;
	public enrollmentState;
	public url;
	public urlState;
	public subscriptions = [];
	public isLoaded: boolean;
	public checkout: string = '/enrollment-dashboard/checkout';
	public deductionSummary;
	public routerStateList: boolean[] = [];

	constructor(
		public cd: ChangeDetectorRef,
		public store: Store<any>,
		public enrollmentDashboardService: EnrollmentDashboardService,
	) { }

	ngOnInit() {
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
			this.cd.detectChanges();
		});
		this.subscriptions.push(enrollmentSubscription);
		this.urlState = this.store.select('routerState');
		const urlSubscription = this.urlState.subscribe(url => {
			this.url = url;
			this.isLoaded = !this.checkIfLoaded();
			this.cd.detectChanges();
		});
		this.subscriptions.push(urlSubscription);

		this.subscriptions.push(
			this.store.select('apiState').subscribe( api => {
				if (api.type.includes('[api]') && api.apiResponse) {
					if (
						api.apiResponse.url.toLowerCase().includes('finalize') &&
						!api.apiResponse.url.toLowerCase().includes('memberbenefitflyout') &&
						!api.apiRequest.url.toLowerCase().includes('memberbenefitflyout')
					) {
						this.enrollmentDashboardService.getMemberBenefitFlyout().subscribe(deductionSummary => {
							this.deductionSummary = deductionSummary;
							this.cd.detectChanges();
						});
					}
				}
			}),
		);
		this.enrollmentDashboardService.getMemberBenefitFlyout().subscribe(deductionSummary => {
			this.deductionSummary = deductionSummary;
			this.cd.detectChanges();
		});
		this.subscriptions.push(
			this.store.select('endingBenefitState').subscribe( benefitEnding => this.endingBenefit = benefitEnding),
		);
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
		this.cd.detach();
	}

	private checkIfLoaded(): boolean {
		let isLoading: boolean;
		this.routerStateList = [
			this.enrollment.categoryOptions && this.url.current.url === this.checkout,
			this.enrollment.categoryOptions && this.url.current.url !== this.checkout,
			!this.enrollment.categoryOptions && this.url.current.url === this.checkout,
			!this.enrollment.categoryOptions && this.url.current.url !== this.checkout,
		];
		isLoading = this.routerStateList.some(routerState => { return routerState; });

		return isLoading;
	}
}
