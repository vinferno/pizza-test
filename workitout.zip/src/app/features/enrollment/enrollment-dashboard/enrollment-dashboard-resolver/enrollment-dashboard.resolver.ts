import { Injectable }                 from '@angular/core';
import {
	ActivatedRouteSnapshot,
	Resolve,
	RouterStateSnapshot,
}                                     from '@angular/router';
import {
	Observable,
	of as observableOf,
}                            from 'rxjs';
import { Store }                      from '@ngrx/store';

import { EnrollmentCategory }         from '../../../../infrastructure/interfaces/enrollment-category';
import { EnrollmentDashboardService } from '../../../../infrastructure/enrollment/enrollment-dashboard.service';
import { EnrollmentState }            from '../../../../infrastructure/store/reducers/enrollment/enrollment-state';
import { EnrollmentWizardService }    from '../../../../infrastructure/enrollment/enrollment-wizard.service';
import { RouterState }                from '../../../../infrastructure/store/reducers/router/router-state';
import { SessionState }               from '../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class EnrollmentDashboardResolver implements Resolve<any> {
	public enrollment;
	public enrollmentState: Observable<any>;
	public selectedCategory: EnrollmentCategory;
	public session: SessionState;
	public sessionState: Observable<SessionState>;
	public setEnrollmentFunction: Function;
	public url: RouterState;
	public urlState: Observable<RouterState>;

	constructor(
		private enrollmentDashboardService: EnrollmentDashboardService,
		private enrollmentWizardService: EnrollmentWizardService,
		private store: Store<any>,
	) {
		this.initializeState();
	}

	public resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<any> {
		let categoryId: number;
		if (route.firstChild && route.firstChild.paramMap) {
			categoryId = +route.firstChild.paramMap.get('categoryId');
			this.setEnrollmentFunction = this.setEnrollmentRouteFromOutsideModule;
		} else {
			categoryId = +route.paramMap.get('categoryId');
			this.setEnrollmentFunction = this.setEnrollmentRoute;
		}
		if (this.enrollment.companyCategories && this.enrollment.companyCategories.benefitCategories) {
			this.setEnrollmentFunction(stateSnap, categoryId);

			return observableOf(this.enrollment.companyCategories);
		} else {
			const observer = this.enrollmentDashboardService.getCategoryList();
			observer.subscribe(() => this.setEnrollmentFunction(stateSnap, categoryId));

			return observer;
		}
	}

	private initializeState(): void {
		this.enrollmentState = this.store.select('enrollmentState');
		this.enrollmentState.subscribe(enrollment => { this.enrollment = enrollment; });
		this.sessionState = this.store.select('sessionState');
		this.sessionState.subscribe(session => { this.session = session; });
		this.urlState = this.store.select('routerState');
		this.urlState.subscribe(url => { this.url = url; });
	}

	private setEnrollmentRoute(stateSnap: RouterStateSnapshot, categoryId: number): Observable<any> {
		// early return if route is checkout
		if (stateSnap.url === '/enrollment-dashboard/checkout') { return observableOf(this.enrollment.companyCategories); }
		this.getEnrollmentModeIfVBO();
		this.preventDuplicateCategoryCalls(categoryId);
		this.setCategoryIfValid(categoryId);
	}

	private setEnrollmentRouteFromOutsideModule(stateSnap: RouterStateSnapshot, categoryId: number): Observable<any> {
		// early return if route is checkout
		if (stateSnap.url === '/enrollment-dashboard/checkout') { return observableOf(this.enrollment.companyCategories); }
		this.getEnrollmentModeIfVBO();
		this.preventDuplicateCategoryCalls(categoryId);
		this.setCategoryIfValid(categoryId);
		this.setCategoryWhenNavigatingFromOutsideModule();
	}

	private getEnrollmentModeIfVBO(): void {
		if (this.enrollment.mode && !this.enrollment.mode.mode && this.session.selectedMemberOptions && this.session.selectedMemberOptions.isVbo) {
			this.enrollmentWizardService.getEnrollmentMode().subscribe();
		}
	}

	private preventDuplicateCategoryCalls(categoryId: number): void {
		this.enrollment.companyCategories.benefitCategories.forEach((category, index) => {
			// compare stringified param to number id property
			if (category && category.id === categoryId) {
				// prevent duplicate call if user selects category
				if (!this.url.current.url) { this.setSelectedCategory(this.enrollment.companyCategories.benefitCategories[index]); }
			}
		});
	}

	private setCategoryIfValid(categoryId: number): void {
		const isValidCategory = this.checkIfValidCategory(categoryId);
		if (!isValidCategory) {
			this.enrollment && this.enrollment.selectedCategory
				? this.setSelectedCategory(this.enrollment.selectedCategory)
				: this.setSelectedCategory(this.enrollment.companyCategories.benefitCategories[0]);
		}
	}

	private setCategoryWhenNavigatingFromOutsideModule(): void {
		if (this.url.current.url && !this.url.current.url.includes('enrollment-dashboard')) {
			this.setSelectedCategory(this.selectedCategory);
		}
	}

	private checkIfValidCategory(categoryId: number): boolean {
		// handle null or invalid categoryIDs, route to saved selectedCategory or the first category
		return this.enrollment.companyCategories.benefitCategories.some(category => {
			if (category.id === categoryId) { this.selectedCategory = category; }
			return category.id === categoryId;
		});
	}

	private setSelectedCategory(category: EnrollmentCategory): void {
		this.enrollmentDashboardService.setSelectedCategory(category);
	}
}
