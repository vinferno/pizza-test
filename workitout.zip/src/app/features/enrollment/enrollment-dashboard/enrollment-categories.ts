import { EnrollmentCategory } from '../../../infrastructure/interfaces/enrollment-category';

export const checkout: EnrollmentCategory = {
	id: null,
	name: 'Checkout',
	isRequired: false,
	isCompleted: false,
	isNotBenefit: true,
	isCheckoutDisabled: true,
	materialIconName: 'exit_to_app',
};
