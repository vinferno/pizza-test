import { WidgetWizardDialogComponent } from './wizards/widget-wizard-dialog/widget-wizard-dialog.component';
import { TerminateWizardDialogComponent } from './wizards/terminate-wizard-dialog/terminate-wizard-dialog.component';
import { FSAWizardDialogComponent } from './wizards/fsa-wizard-dialog/fsa-wizard-dialog.component';
import { WaiveWizardDialogComponent } from './wizards/waive-wizard-dialog/waive-wizard-dialog.component';
import { CancelWizardDialogComponent } from './wizards/cancel-wizard-dialog/cancel-wizard-dialog.component';
import { BuyupWizardDialogComponent } from './wizards/buyup-wizard-dialog/buyup-wizard-dialog.component';
import { AddBenefitWizardDialogComponent } from './wizards/add-benefit-wizard-dialog/add-benefit-wizard-dialog.component';
import { BenefitLocationComponent } from './benefit-location/benefit-location.component';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { BenefitComparisonComponent } from './benefit-comparison/benefit-comparison.component';
import { EnrollmentDashboardComponent } from './enrollment-dashboard.component';
import { EnrollmentCheckoutWizardDialogComponent } from './wizards/enrollment-checkout/enrollment-checkout-wizard-dialog/enrollment-checkout-wizard-dialog.component';
import { EnrollmentWizardToolbarComponent } from './enrollment-wizard-toolbar/enrollment-wizard-toolbar.component';
import { PendingBenefitComponent } from './pending-benefit/pending-benefit.component';
import { EnrollmentDashboardGuard } from '../../../infrastructure/core/guards/enrollment-dashboard-guard.service';
import { AddWizardGuard } from '../../../infrastructure/core/guards/enrollment/add-wizard-guard.service';
import { CancelRequestWizardGuard } from '../../../infrastructure/core/guards/enrollment/cancel-request-wizard-guard.service';
import { FSAWizardGuard } from '../../../infrastructure/core/guards/enrollment/fsa-wizard-guard.service';
import { KeepCurrentElectionsWizardGuard } from '../../../infrastructure/core/guards/enrollment/keep-current-elections-guard.service';
import { ModifyWizardGuard } from '../../../infrastructure/core/guards/enrollment/modify-wizard-guard.service';
import { ReplaceWizardGuard } from '../../../infrastructure/core/guards/enrollment/replace-wizard-guard.service';
import { TerminateWizardGuard } from '../../../infrastructure/core/guards/enrollment/terminate-wizard-guard.service';
import { WaiveBenefitGuard } from '../../../infrastructure/core/guards/enrollment/waive-benefit-wizard.service';
import { WaiveCoverageGuard } from '../../../infrastructure/core/guards/enrollment/waive-coverage-guard.service';
import { DeductionSummaryComponent } from './deduction-summary/deduction-summary.component';

import {
	routedComponents as checkoutRoutedComponents,
}                                         from './wizards/enrollment-checkout/enrollment-checkout-routing.module';
import { EnrollmentCategoryGuardService } from '../../../infrastructure/core/guards/enrollment-category-guard.service';
import { EnrollmentDashboardResolver }    from './enrollment-dashboard-resolver/enrollment-dashboard.resolver';
import { TitleResolver }                  from '../../../infrastructure/core/resolvers/title.resolver';
import { DialogGuardService }             from '../../../infrastructure/core/guards/dialog-guard.service';
import { FormGuardService }               from '../../../infrastructure/core/guards/form-guard.service';

const routes: Routes = [
	{
		path: '',
		canActivateChild: [EnrollmentDashboardGuard],
		children: [
			{
				path: '',
				component: EnrollmentDashboardComponent,
				resolve: {
					companyCategories: EnrollmentDashboardResolver,
				},
				children: [
					{
						path: 'checkout',
						canDeactivate: [FormGuardService],
						component: EnrollmentCheckoutWizardDialogComponent,
						data: {title: 'Checkout'},
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId',
						component: BenefitLocationComponent,
						resolve: {
							companyCategories: EnrollmentDashboardResolver,
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/add-benefit',
						canActivate: [AddWizardGuard],
						canDeactivate: [FormGuardService],
						component: AddBenefitWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/cancel-request',
						canActivate: [CancelRequestWizardGuard],
						canDeactivate: [FormGuardService],
						component: CancelWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/modify-benefit',
						canActivate: [ModifyWizardGuard],
						canDeactivate: [FormGuardService],
						component: BuyupWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/waive-benefit',
						canActivate: [WaiveBenefitGuard],
						canDeactivate: [FormGuardService],
						component: AddBenefitWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/waive-coverage',
						canActivate: [WaiveCoverageGuard],
						canDeactivate: [FormGuardService],
						component: WaiveWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/keep-current-elections',
						canActivate: [KeepCurrentElectionsWizardGuard],
						canDeactivate: [FormGuardService],
						component: WaiveWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/term-benefit',
						canActivate: [TerminateWizardGuard],
						canDeactivate: [FormGuardService],
						component: TerminateWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/replace-benefit',
						canActivate: [ReplaceWizardGuard],
						canDeactivate: [FormGuardService],
						component: AddBenefitWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/fsa-reenroll',
						canActivate: [FSAWizardGuard],
						canDeactivate: [FormGuardService],
						component: FSAWizardDialogComponent,
						resolve: {
							title: TitleResolver,
						},
					},
					{
						path: ':categoryId/widget',
						component: WidgetWizardDialogComponent,
						data: { subTitle: 'Widget'},
						resolve: {
							title: TitleResolver,
						},
					},
				],
			},
		],
	},
];

@NgModule({
	imports: [
		ReactiveFormsModule,
		RouterModule.forChild(routes),
	],
	exports: [
		ReactiveFormsModule,
		RouterModule,
	],
	providers: [
		AddWizardGuard,
		CancelRequestWizardGuard,
		FSAWizardGuard,
		KeepCurrentElectionsWizardGuard,
		EnrollmentDashboardGuard,
		EnrollmentCategoryGuardService,
		ModifyWizardGuard,
		ReplaceWizardGuard,
		TerminateWizardGuard,
		WaiveBenefitGuard,
		WaiveCoverageGuard,
		EnrollmentDashboardResolver,
		DeductionSummaryComponent,
	],
	entryComponents: [
		EnrollmentCheckoutWizardDialogComponent,
	],
})
export class EnrollmentDashboardRoutingModule { }

export const routedComponents = [
	EnrollmentDashboardComponent,
	checkoutRoutedComponents,
	EnrollmentCheckoutWizardDialogComponent,
	EnrollmentWizardToolbarComponent,
	PendingBenefitComponent,
	BenefitComparisonComponent,
	BenefitLocationComponent,
	DeductionSummaryComponent,
];
