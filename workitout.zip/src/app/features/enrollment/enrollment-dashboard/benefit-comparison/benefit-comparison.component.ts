import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, HostBinding, OnDestroy } from '@angular/core';

import { Store } from '@ngrx/store';

import {
	BenefitComparisonList,
	IEnrollmentOptionList,
} from '../../../../infrastructure/interfaces/enrollment-option-list';
import { EnrollmentCategory } from '../../../../infrastructure/interfaces/enrollment-category';
import { TableColumns } from '../../../../infrastructure/interfaces/table-columns';
import { animator } from '../../../../infrastructure/core/animations/animations';

@Component({
	selector: 'hg-benefit-comparison',
	templateUrl: './benefit-comparison.component.html',
	styleUrls: ['./benefit-comparison.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
	animations: [animator.slide],
})
export class BenefitComparisonComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public isEnrollmentLoaded: boolean;
	public selectedCategory: EnrollmentCategory;
	public response: BenefitComparisonList[];
	public benefitComparisonList: BenefitComparisonList[];
	public displayedColumns: TableColumns[] = new Array<TableColumns>();
	public subscriptions = [];
	public state;
	public enrollmentState;
	public enrollment;
	public settingsState;
	public settings;

	constructor(
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) { }

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe( settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe( enrollment => {
			this.enrollment = enrollment;
			this.buildBenefitList(this.enrollment.categoryOptions);
		});
		this.subscriptions.push(enrollmentSubscription);

	}

	public checkVisibility(category: EnrollmentCategory): boolean {
		return (category && !category.isNotBenefit);
	}

	private buildBenefitList(benefit: IEnrollmentOptionList): void {
		this.response = benefit.benefitCompareList;
		if (this.response) { this.buildTransposedGrid(); }
	}

	private buildGrid(): void {
		const gridHeaders = this.response[0];
		this.displayedColumns = new Array<TableColumns>();
		this.benefitComparisonList = [...this.response];

		for (const property in gridHeaders) {
			if (gridHeaders.hasOwnProperty(property)) {
				this.displayedColumns.push(
					{
						columnId: property,
						columnName: gridHeaders[property],
					},
				);
			}
		}

		this.benefitComparisonList = this.benefitComparisonList.splice(2, this.response.length);
		this.cd.detectChanges();
	}

	private buildTransposedGrid() {
		const model = this.response[0];
		const keys = Object.keys(model);
		this.displayedColumns = new Array<TableColumns>();
		this.benefitComparisonList = [...this.response];

		this.benefitComparisonList.splice(1,1);
		for (const property in this.benefitComparisonList) {
				  if (this.benefitComparisonList.hasOwnProperty(property)) {
					  this.displayedColumns.push({
							  columnId: property,
							  columnName: this.benefitComparisonList[property][keys[0]],
			  });
			}
		}

		this.Rows();
	  }

	  private Rows(): void {

		const model = this.response[0];
		const keys = Object.keys(model);

		const rows = new Array();
		for (const item in keys) {
			if (keys.hasOwnProperty(item)) {
				const r = {};
				for (const row in this.benefitComparisonList) {
					if (this.benefitComparisonList.hasOwnProperty(row)) {
						const attname = this.displayedColumns[row].columnId;
						r[attname] = this.benefitComparisonList[row][keys[item]];
						rows[item] = r;
					}
				}
			}
		}
		this.benefitComparisonList = rows;
		this.benefitComparisonList = this.benefitComparisonList.splice(1, rows.length);
		this.cd.detectChanges();
	  }

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => {
			subscription.unsubscribe();
		});
	}

	benefitWidths() {
		const basic = 270;
		if (this.displayedColumns.length === 2) {
			return basic * 2;
		}
		if (this.displayedColumns.length === 3) {
			return Math.floor(basic * 1.5);
		}
		if (this.displayedColumns.length === 4) {
			return Math.floor(basic * 1.2);
		}
		if (this.displayedColumns.length > 4) {
			return Math.floor(basic);
		}
		return basic;
	}

	benefitWidthsPercentage() {
		const basic = 100 / (this.displayedColumns.length - 1) ;
		const _basic = (Math.floor(basic) - (this.displayedColumns.length)) + '%';
		return _basic;
	}
}
