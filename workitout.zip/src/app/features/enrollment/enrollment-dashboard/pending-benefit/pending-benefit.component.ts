import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
}                                		from '@angular/core';

import { Store }                 		from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                		from 'rxjs';

import { animator }              		from '../../../../infrastructure/core/animations/animations';
import { BenefitSummary }        		from '../../../../infrastructure/interfaces/benefit';
import { EnrollmentCategory }    		from '../../../../infrastructure/interfaces/enrollment-category';
import { IEnrollmentOptionList } 		from '../../../../infrastructure/interfaces/enrollment-option-list';
import { EnrollmentState }       		from '../../../../infrastructure/store/reducers/enrollment/enrollment-state';
import { SettingsState }         		from '../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-pending-benefit',
	templateUrl     : './pending-benefit.component.html',
	styleUrls       : ['./pending-benefit.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class PendingBenefitComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	public enrollment;
	public enrollmentCategoryOptionList: BenefitSummary[];
	public selectedEnrollmentCategoryOption: IEnrollmentOptionList;
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];

	private enrollmentState: Observable<EnrollmentState>;
	private settingsState: Observable<SettingsState>;

	constructor(
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
			this.buildBenefitList(this.enrollment.categoryOptions);
			this.checkVisibility(this.enrollment.selectedCategory);
			this.cd.detectChanges();
		});
		this.subscriptions.push(enrollmentSubscription);
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => { subscription.unsubscribe(); });
	}

	public checkVisibility(category: EnrollmentCategory): boolean {
		return this.enrollment &&
			this.enrollment.categoryOptions &&
			(this.enrollment.categoryOptions.isFauxCategory === false ||
				!(this.enrollment.categoryOptions.isFauxCategory === true && !this.enrollment.categoryOptions.genericBenefitSummaryModel.summaryBenefitCards.length)
			) &&
			(category && !category.isNotBenefit);
	}

	private buildBenefitList(benefit: IEnrollmentOptionList): BenefitSummary[] {
		if (!benefit.genericBenefitSummaryModel) { return this.enrollmentCategoryOptionList = null; }
		return this.enrollmentCategoryOptionList = benefit.genericBenefitSummaryModel.summaryBenefitCards;
	}
}
