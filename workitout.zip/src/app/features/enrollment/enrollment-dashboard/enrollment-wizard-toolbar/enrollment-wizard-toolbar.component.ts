import {
	Component,
	OnInit,
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	HostBinding,
	OnDestroy,
} from '@angular/core';
import { MatDialog } from "@angular/material/dialog";
import { Router } from '@angular/router';

import { Store } from '@ngrx/store';

import { AddBenefitWizardDialogComponent } from '../wizards/add-benefit-wizard-dialog/add-benefit-wizard-dialog.component';
import { animator } from '../../../../infrastructure/core/animations/animations';
import { BuyupWizardDialogComponent } from '../wizards/buyup-wizard-dialog/buyup-wizard-dialog.component';
import { CancelWizardDialogComponent } from '../wizards/cancel-wizard-dialog/cancel-wizard-dialog.component';
import { EnrollmentWizard } from '../../../../infrastructure/interfaces/enrollment-wizard';
import { FSAWizardDialogComponent } from '../wizards/fsa-wizard-dialog/fsa-wizard-dialog.component';
import { stateActions } from '../../../../infrastructure/store/reducers/reducers-index';
import { TerminateWizardDialogComponent } from '../wizards/terminate-wizard-dialog/terminate-wizard-dialog.component';
import { WaiveWizardDialogComponent } from '../wizards/waive-wizard-dialog/waive-wizard-dialog.component';
import { WidgetWizardDialogComponent } from '../wizards/widget-wizard-dialog/widget-wizard-dialog.component';

@Component({
	selector: 'hg-enrollment-wizard-toolbar',
	templateUrl: './enrollment-wizard-toolbar.component.html',
	styleUrls: ['./enrollment-wizard-toolbar.component.scss'],
	animations: [animator.slide],
	changeDetection: ChangeDetectionStrategy.OnPush,
})

export class EnrollmentWizardToolbarComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	private currentRoute;
	public wizardList;
	public enrollment;
	private enrollmentState;
	public settings;
	public settingsState;
	public subscriptions = [];

	constructor(
		public dialog: MatDialog,
		private router: Router,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) { }

	ngOnInit() {
		this.currentRoute = this.router.url;
		this.initializeState();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public showToolbar(): boolean {
		return this.enrollment &&
			this.enrollment.categoryOptions &&
			this.enrollment.categoryOptions.isFauxCategory === false;
	}

	public trackByName(index, item): number {
		return item.name;
	}

	public openThis(dialog, name, routeName): void {
		this.store.dispatch(stateActions.stepperActions.reset());
		const route = this.currentRoute + '/' + routeName;
		this.router.navigateByUrl(route);
		this.store.dispatch(stateActions.enrollmentActions.updateWizard({ name }));
		this.cd.detectChanges();
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
			if (enrollment.categoryOptions) {
				this.buildWizardList();
				this.cd.detectChanges();
			}
		});
		this.subscriptions.push(enrollmentSubscription);
	}

	private buildWizardList() {
		const wizardList: EnrollmentWizard[] = [
			{
				name: 'Keep Current Elections',
				click: WaiveWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isNoChangeAvailable,
				routeName: 'keep-current-elections',
				class: 'keep-current-elections',
				icon: 'check',
			},
			{
				name: 'Add Benefit',
				click: AddBenefitWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isAddAvailable,
				routeName: 'add-benefit',
				class: 'add-benefit',
				icon: 'add',
			},
			{
				name: 'Replace Current Benefit',
				click: AddBenefitWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isReplaceAvailable,
				routeName: 'replace-benefit',
				class: 'replace-benefit',
				icon: 'pulldown',
			},
			{
				name: 'Modify Current Benefit',
				click: BuyupWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isExistingBenefitEdit,
				routeName: 'modify-benefit',
				class: 'modify-benefit',
				icon: 'edit',
			},
			{
				name: 'FSA Reenroll',
				click: FSAWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isFSAReEnrollAvailable,
				routeName: 'fsa-reenroll',
				class: 'fsa-reenroll',
				icon: 'pulldown',
			},
			{
				name: 'Carrier Enrollment',
				click: WidgetWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isWidgetAvailable,
				routeName: 'widget',
				class: 'carrier-enrollment',
				icon: 'add',
			},
			{
				name: 'Term Benefit',
				click: TerminateWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isTermAvailable,
				routeName: 'term-benefit',
				class: 'term-benefit',
				icon: 'remove',
			},
			{
				name: 'Waive Benefit',
				click: AddBenefitWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isAddWaiveBenefitAvailable,
				routeName: 'waive-benefit',
				class: 'waive-benefit',
				icon: 'chevronright',
			},
			{
				name: 'Waive Coverage',
				click: WaiveWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isWaiveAvailable,
				routeName: 'waive-coverage',
				class: 'waive-coverage',
				icon: 'chevronright',
			},
			{
				name: 'Cancel Request',
				click: CancelWizardDialogComponent,
				isActive: this.enrollment.categoryOptions.isCancelAvailable,
				routeName: 'cancel-request',
				class: 'cancel-request',
				icon: 'remove',
			},
		];
		return this.wizardList = wizardList;
	}
}
