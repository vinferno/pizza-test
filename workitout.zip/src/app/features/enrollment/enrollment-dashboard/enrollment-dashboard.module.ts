import { CommonModule }           from '@angular/common';
import { NgModule }               from '@angular/core';
import { FlexLayoutModule }       from '@angular/flex-layout';
import { FormsModule }            from '@angular/forms';


import { CovalentModule }         from '../../../infrastructure/utils/covalent.module';
import { MaterialModule }         from '../../../infrastructure/utils/material.module';
import { SharedModule }           from 'app/infrastructure/shared/shared.module';
import { WizardsModule }          from './wizards/wizards-module';
import {
	EnrollmentDashboardRoutingModule,
	routedComponents,
}                                 from './enrollment-dashboard-routing.module';
import { ControlsModule }         from '../../../infrastructure/shared/controls/controls.module';

@NgModule({
	imports : [
		CommonModule,
		FormsModule,
		MaterialModule,
		CovalentModule,
		SharedModule.forRoot(),
		ControlsModule,
		WizardsModule,
		EnrollmentDashboardRoutingModule,
		FlexLayoutModule,
	],
	declarations: [ routedComponents ],
})
export class EnrollmentDashboardModule { }
