import {
	ChangeDetectorRef,
	Component,
	OnDestroy,
	OnInit,
	Input,
}                       from '@angular/core';

import { Store }        from '@ngrx/store';
import { TableColumns } from '../../../../infrastructure/interfaces/table-columns';
@Component({
	selector    : 'hg-deduction-summary',
	templateUrl : './deduction-summary.component.html',
	styleUrls   : ['./deduction-summary.component.scss'],
})
export class DeductionSummaryComponent implements OnInit, OnDestroy {
	public subscriptions = [];
	public settingsState;
	public settings;
	public emptyGridMessage: string = 'There are no deductions currently available.';
	public enrollmentState;
	public enrollment;
	public deductions = null;
	public totals = null;
	public currencyFormat = {
		type      : 'currency',
		precision : 2,
	};
	@Input() public deductionSummary;

	public columnList: TableColumns[] = [
		{
			columnName : 'Pretax',
			columnId   : 'pretaxAmount',
		},
		{
			columnName : 'Posttax',
			columnId   : 'posttaxAmount',
		},
	];

	constructor(
		private store: Store<any>,
		private cd: ChangeDetectorRef,
	) { }

	ngOnInit() {
		this.initializeState();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);

		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
			if (this.deductionSummary) {
				this.totals = [
					{
						deductionTotalLabel : 'TOTAL PRE & POST TAX DEDUCTIONS',
						pretaxAmount        : enrollment.memberBenefitFlyout.totalPretaxAmount,
						posttaxAmount       : enrollment.memberBenefitFlyout.totalPosttaxAmount,
					},
				]
			}
			this.cd.detectChanges();
		});
		this.subscriptions.push(enrollmentSubscription);
	}
}
