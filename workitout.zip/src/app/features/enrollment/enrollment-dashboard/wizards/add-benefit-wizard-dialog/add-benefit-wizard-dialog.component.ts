import { ChangeDetectorRef, Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder }                                                  from '@angular/forms';
import { Router }                                                       from '@angular/router';

import { Store }                    from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';

import { animator }              from '../../../../../infrastructure/core/animations/animations';
import { ApiService }            from '../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService }  from '../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormDialogBase }        from '../../../../../infrastructure/core/classes/form-wizard';
import { FormPersistentService } from '../../../../../infrastructure/core/services/form-persistent.service';
import { IError }                from '../../../../../infrastructure/interfaces/error';
import { SettingsState }         from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { StepperState } from '../../../../../infrastructure/store/reducers/stepper/stepper-state';
import { stateActions } from '../../../../../infrastructure/store/reducers/reducers-index';
import { EndingBenefit } from '../../../../../infrastructure/store/reducers/ending-benefit/ending-benefit';

@Component({
	selector   : 'hg-add-benefit-wizard-dialog',
	templateUrl: './add-benefit-wizard-dialog.component.html',
	styleUrls  : ['./add-benefit-wizard-dialog.component.scss'],
	animations : [animator.slide],
})
export class AddBenefitWizardDialogComponent extends FormDialogBase implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	public errorMessage: IError = null;
	public enrollment;
	public endingBenefit: EndingBenefit;
	public formsInit = [
		{
			name: 'Available Benefits',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Future Benefits',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Optional Benefit Plan Coverages',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Core Benefits',
			fg  : {},
		},
		{
			name: 'Tobacco Usage',
			fg  : {},
		},
		{
			name: 'Auto Enroll',
			fg  : {},
		},
		{
			name: 'Coverage Selection',
			fg  : {},
		},
		{
			name: 'General Eligibility Questions',
			fg  : {},
		},
		{
			name: 'Additional Info',
			fg  : {},
		},
		{
			name: 'Primary Care Physician (PCP)',
			fg  : {},
		},
		{
			name: 'Beneficiary',
			fg  : {},
		},
		{
			name: 'Auto-Termination of Existing Coverage',
			fg  : {},
		},
		{
			name: 'Domestic Partner Disclaimer',
			fg  : {},
		},
		{
			name: 'Future Benefits Disclaimer',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Request Term',
			fg	: {},
		},
		{
			name: 'Disclaimer',
			fg  : {},
		},
		{
			name: 'Summary',
			fg  : {},
		},
		{
			name: 'Finalize',
			fg  : {},
		},
	];
	public formWizardName: string = 'Add Benefit';
	public headerTitle: string = '';
	public minDate: Date;
	public maxDate: Date;
	public returnRoute: string = '/enrollment-dashboard';
	public settings: SettingsState;
	public settingsState: Observable<SettingsState>;
	public subscriptions: Subscription[] = [];
	public futureBenefitPass: false;
	public steppers: StepperState;
	public current = '';
	public ready = false;
	public start = 'Available Benefits';

	constructor (
		public api: ApiService,
		public fb: FormBuilder,
		public formService: FormPersistentService,
		public router: Router,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(formService, router, api, cd, store);
		this.alias = {
			Benefits      : 'Available Benefits',
			FutureBenefits: 'Future Benefits',
			KitBenefits   : 'Optional Benefit Plan Coverages',
			CoreBenefits  : 'Core Benefits',
			Tobacco       : 'Tobacco Usage',
			AutoEnroll    : 'Auto Enroll',
			Coverage      : 'Coverage Selection',
			Eligibility   : 'General Eligibility Questions',
			AdditionalInfo: 'Additional Info',
			Pcp           : 'Primary Care Physician (PCP)',
			Beneficiary   : 'Beneficiary',
			AutoTerm      : 'Auto-Termination of Existing Coverage',
			DpDisclaimer  : 'Domestic Partner Disclaimer',
			Disclaimer    : 'Disclaimer',
			Summary       : 'Summary',
			Finalize      : 'Finalize',
			FutureBenefitsDisclaimer: 'Future Benefits Disclaimer',
			RequestTerm	  : 'Request Term',
		};
	}

	ngOnInit () {
		this.initializeState();
		super.ngOnInit();
		this.setErrorMessage();
		this.setWizardName();
		this.store.dispatch(stateActions.stepperActions.reset());
		this.store.dispatch(stateActions.stepperActions.updatePrimary(this.start, 'Add-Benefit-Dialog'));
		this.store.dispatch(stateActions.stepperActions.resetSecondary());
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => sub.unsubscribe());
		this.store.dispatch(stateActions.endingBenefitActions.updateSession(0));
		this.store.dispatch(stateActions.stepperActions.reset());
	}

	private initializeState (): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		const enrollmentSubscription = this.store.select('enrollmentState').subscribe(enrollment => {
			this.enrollment = enrollment;
		});
		this.subscriptions.push(enrollmentSubscription);
		const endingBenefitState = this.store.select('endingBenefitState');
		const endingBenefitSubscription = endingBenefitState.subscribe(endingBenefit => {
			this.endingBenefit = endingBenefit;
			this.cd.detectChanges();
		});
		this.subscriptions.push(endingBenefitSubscription);
		this.subscriptions.push(
			this.store.select('endingBenefitState').subscribe( endingBenefit => {
				this.endingBenefit = endingBenefit;
			}),
		);
		this.subscriptions.push(
			this.store.select('stepperState').subscribe( (steppers: StepperState) => {
				this.steppers = steppers;
				this.current = steppers.primaryStepper.slice(-1)[0];
				if (this.current === this.start) {
					this.ready = true;
				}
			}),
		);
	}

	private setErrorMessage (): void {
		this.service.errorMessage$.subscribe((error) => {
			(error && error.error)
			? this.errorMessage = error.error
			: this.errorMessage = null;
		});
	}

	private setWizardName (): void {
		if (this.enrollment && this.enrollment.wizard) {
			if (this.enrollment.wizard.name === 'Waive Benefit') {
				this.headerTitle = 'Waive Benefit Request';
			}
			if (this.enrollment.wizard.name === 'Replace Benefit') {
				this.headerTitle = 'Replace Benefit Request';
			}
			if (this.enrollment.wizard.name === 'Add Benefit') {
				this.headerTitle = 'Add Benefit Request';
			}
		}

	}

	private submitEndingBenefit () {
		this.service.postFutureBenefits(null).subscribe((res: any) => {
			this.changeForm(res.nextPanel.value);
		});

	}
}
