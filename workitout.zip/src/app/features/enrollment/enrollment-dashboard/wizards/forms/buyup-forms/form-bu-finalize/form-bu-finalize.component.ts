import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectionStrategy,
	ChangeDetectorRef,
}                                      from '@angular/core';
import { ActivatedRoute }         from '@angular/router';

import { Store }                  from '@ngrx/store';

import { ApiService }             from '../../../../../../../infrastructure/core/api/api.service';
import { checkout }               from '../../../../enrollment-categories';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { EnrollmentWizardFormService } from '../../../../../../../infrastructure/enrollment/enrollment-wizard-form.service';
import { EnrollmentCategory }     from '../../../../../../../infrastructure/interfaces/enrollment-category';
import { Form }                   from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }        from '../../../../../../../infrastructure/core/classes/form-wizard';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';


@Component({
	selector        : 'hg-form-bu-finalize',
	templateUrl     : './form-bu-finalize.component.html',
	styleUrls       : ['./form-bu-finalize.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FormBuFinalizeComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;

	public categoryId: number;
	public checkout = checkout;
	public finalize;
	public shouldDisableNext: boolean = false;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		private route: ActivatedRoute,
		public service: EnrollmentBuyupService,
		public cd: ChangeDetectorRef,
		public wizardFormService: EnrollmentWizardFormService,
		public store: Store<any>,
	) {
		super(api, cd, store);
		this.categoryId = +route.snapshot.paramMap.get('categoryId');
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.getFinalize();
		this.skipUntil('Finalize');
		this.store.dispatch(stateActions.formsActions.started(false));
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	public selectCategory(category): void {
		this.service.selectCategory(category);
		setTimeout(() => {
			this.service.reset();
		}, 100);
	}

	public startCheckout(): void {
		this.selectCategory(this.checkout);
	}

	public selectNextRequired(): void {
		const category: EnrollmentCategory = this.wizardFormService.selectNextRequired(this.finalize.benefitCategories, this.categoryId);

		this.selectCategory(category);
	}

	private getFinalize(): void {
		this.service.getFinalize().subscribe(finalize => {
			this.finalize = finalize;
			this.shouldDisableNext = this.wizardFormService.checkNextCategoryAvailability(this.finalize.benefitCategories, this.categoryId);
			this.cd.detectChanges();
		});
	}
}
