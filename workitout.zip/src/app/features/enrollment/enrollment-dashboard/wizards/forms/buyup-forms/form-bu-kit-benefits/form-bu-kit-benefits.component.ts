import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef,
	OnDestroy,
}                                 from '@angular/core';

import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                 from 'rxjs';

import { ApiService }             from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCategory }     from '../../../../../../../infrastructure/interfaces/enrollment-category';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { Form }                   from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }        from '../../../../../../../infrastructure/core/classes/form-wizard';
import {
	BuKitBenefit,
	KitBenefit,
}                                 from '../../../../../../../infrastructure/interfaces/kit-benefit';
import { SettingsState }          from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from '../../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector: 'hg-form-bu-kit-benefits',
	templateUrl: './form-bu-kit-benefits.component.html',
	styleUrls: ['./form-bu-kit-benefits.component.scss'],
})
export class FormBuKitBenefitsComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;
	@Input() public selectedCategory: EnrollmentCategory;

	public benefitsList: KitBenefit[];
	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
		{
			columnName: 'Current Coverage',
			columnId: 'currentCoverage',
		},
	];
	public isLoaded: boolean = false;
	public payload: BuKitBenefit[] = new Array<BuKitBenefit>();
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit(): void {
		this.initializeState();
		this.getKitBenefits();
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public toggleCheckbox(event: any, cell: KitBenefit, column: string): KitBenefit {
		this.payload.forEach(benefit => {
			if (benefit.uniqueID === cell.uniqueID) {
				benefit[column] = event.value;
				cell[column] = event.value;
			}
		});

		return cell;
	}

	public postForm(): void {
		this.service.postKitBenefits({ selectedBuyupKitBenefits: this.payload }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private getKitBenefits(): void {
		this.service.getKitBenefits().subscribe(benefits => {
			this.benefitsList = benefits.items;
			this.buildPayload();
			this.isLoaded = true;
		});
	}

	private buildPayload(): void {
		this.benefitsList.forEach(benefit => {
			const benefitPayload: BuKitBenefit = new BuKitBenefit();
			benefitPayload.uniqueID = benefit.uniqueID;
			this.payload.push(benefitPayload);
		});
	}
}
