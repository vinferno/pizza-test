import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                               from '@angular/core';

import { Store }                from '@ngrx/store';
import {
	Observable,
	Subscription,
}                               from 'rxjs';

import { ApiService }           from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { Form }                 from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }      from '../../../../../../../infrastructure/core/classes/form-wizard';
import { SettingsState }        from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from 'app/infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-form-request-term',
	templateUrl     : './form-request-term.component.html',
	styleUrls       : ['./form-request-term.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FormRequestTermComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public buttonLabel: string = 'Confirm';
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];
	public requestList: any;

	public columnList: TableColumns[] = [
		{
			columnName: 'Benefit',
			columnId  : 'benefitName',
		},
		{
			columnName: 'Date Request Made',
			columnId  : 'requestDate',
		},
		{
			columnName: 'Process',
			columnId  : 'process',
		},
	];

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.getRequestTerm();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public postForm(): void {
		this.service.postRequestTerm(null).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
	}

	private getRequestTerm(): void {
		const requestSub = this.service.getRequestTerm().subscribe(request => {
			this.requestList = request.cancelRequestItems;
			this.loading = false;
			this.cd.detectChanges();
		});
		this.subscriptions.push(requestSub);
	}
}
