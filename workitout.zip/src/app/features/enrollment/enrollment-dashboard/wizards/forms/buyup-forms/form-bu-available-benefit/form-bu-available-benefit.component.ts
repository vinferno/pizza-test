import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef, OnDestroy,
} from '@angular/core';

import { DxDataGridComponent } from 'devextreme-angular';
import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { EnrollmentCategory } from '../../../../../../../infrastructure/interfaces/enrollment-category';
import { Form } from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { TableColumns } from '../../../../../../../infrastructure/interfaces/table-columns';


@Component({
	selector: 'hg-form-bu-available-benefit',
	templateUrl: './form-bu-available-benefit.component.html',
	styleUrls: ['./form-bu-available-benefit.component.scss'],
})
export class FormBuAvailableBenefitComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	@Input()
	public selectedCategory: EnrollmentCategory;
	public benefitNumber: number = 0;
	public benefitGrid: any;
	public benefitsList: any;
	public currentSelection = [];
	public effectiveDate: Date = new Date();
	public isLoaded: boolean = false;
	public lastSelection = null;
	public multiSelect: boolean = false;
	public pageDisabled: boolean = true;
	public selectMode: string;
	public selectedIndexes = [];
	public selectedObject = {};
	public selectedRows = [];
	public uniqueIds: number[] = [];

	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
	];

	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.initializeWizard();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	private initializeWizard(): void {
		this.service.postInitialize(this.benefitNumber).subscribe(() => {
			this.getAvailableBenefits();
		});
	}

	private getAvailableBenefits(): void {
		this.service.getCategoryList()
			.subscribe((benefits: any) => {
				this.selectMode = benefits.isMultiSelect ? 'multiple' : 'single';
				this.benefitsList = benefits.items;
				this.selectedIndexes = this.benefitsList.filter(benefit => { return benefit.isSelected; });
				this.isLoaded = true;
				// this.cd.detectChanges();
			});
	}

	public postForm(): void {
		this.service.postBenefitSelect({ uniqueIds: this.uniqueIds }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public dataGridChange(grid: DxDataGridComponent, event: any): void {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);

		grid.selectedRowKeysChange.subscribe((rows) => {
			if (rows.length === 1) { this.lastSelection = rows[0]; }
			if (rows.length === 2) {
				rows.splice(rows.indexOf(this.lastSelection), 1);
				this.benefitGrid.selectRows(rows);
			}
			if (rows.length > 2) { this.benefitGrid.selectRows([]); }
			this.uniqueIds = rows.map(row => { return row.uniqueID; });
			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}
}
