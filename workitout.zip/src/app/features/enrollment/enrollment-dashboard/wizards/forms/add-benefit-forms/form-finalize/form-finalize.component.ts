import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnInit, OnDestroy,
} from '@angular/core';

import { ActivatedRoute } from '@angular/router';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { checkout } from '../../../../enrollment-categories';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { EnrollmentCategory } from '../../../../../../../infrastructure/interfaces/enrollment-category';
import { Form } from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentWizardFormService } from '../../../../../../../infrastructure/enrollment/enrollment-wizard-form.service';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector: 'hg-form-finalize',
	templateUrl: './form-finalize.component.html',
	styleUrls: ['./form-finalize.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormFinalizeComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	@Input() public current;

	public categoryId: number;
	public checkout = checkout;
	public finalize;
	public shouldDisableNext: boolean = false;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		private route: ActivatedRoute,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public wizardFormService: EnrollmentWizardFormService,
		public store: Store<any>,
	) {
		super(api, cd, store);
		this.categoryId = +route.snapshot.paramMap.get('categoryId');
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.getFinalize();
		this.store.dispatch(stateActions.formsActions.started(false));
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	public selectCategory(category): void {
		this.service.selectCategory(category);
		setTimeout(() => {
			this.service.reset();
		}, 100);
	}

	public startCheckout(): void {
		this.selectCategory(this.checkout);
	}

	public selectNextRequired(): void {
		const category: EnrollmentCategory = this.wizardFormService.selectNextRequired(this.finalize.benefitCategories, this.categoryId);

		this.selectCategory(category);
	}

	private getFinalize(): void {
		this.service.getFinalize().subscribe(finalize => {
			this.finalize = finalize;
			this.shouldDisableNext = this.wizardFormService.checkNextCategoryAvailability(this.finalize.benefitCategories, this.categoryId);
			this.cd.detectChanges();
		});
	}
}
