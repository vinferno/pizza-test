import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	OnDestroy,
}                               from '@angular/core';

import { debounceTime }         from 'rxjs/operators';
import { Store }                from '@ngrx/store';

import { ApiService }           from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormContentBase }      from '../../../../../../../infrastructure/core/classes/form-wizard';

@Component({
	selector: 'hg-form-auto-enroll',
	templateUrl: './form-auto-enroll.component.html',
	styleUrls: ['./form-auto-enroll.component.scss'],
})
export class FormAutoEnrollComponent extends FormContentBase implements OnInit, OnDestroy {

	@Input() public form;
	@Input() public selectedCategory;
	public benefits: any;
	public multiSelect: boolean = false;
	public pageDisabled: boolean = true;
	public getResponse;
	public selectMode;
	public uniqueIds = [];
	public selectedObject = {};
	public selectedRows = [];
	public benefitGrid;
	public selectedIndexes = [];
	public lastSelection = null;
	public currentSelection = [];

	public displayedColumns = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
	];
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe( settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.getAvailableBenefits();

		this.setAllowContinue(true);
	}

	ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.service.postAutoErnoll({ uniqueIds: this.uniqueIds }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public dataGridChange(grid, event): void {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		grid.selectedRowKeysChange
		.pipe(debounceTime(20))
		.subscribe((rows) => {
			this.uniqueIds = rows.map(row => { return row.uniqueID; });
			this.uniqueIds = this.uniqueIds.concat(this.selectedIndexes.map(dep => dep.uniqueID).filter(id => !this.uniqueIds.includes(id)));
			this.benefitGrid.selectRows(this.selectedIndexes);
			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}

	private getAvailableBenefits(): void {
		this.service.getAutoEnroll().subscribe((benefits: any) => {
			this.selectMode = benefits.isMultiSelect ? 'multiple' : 'single';
			this.benefits = benefits.items; this.loading = false;
			this.getResponse = benefits;
			this.benefits.forEach((benefit, index) => {
				this.selectedObject[benefit.uniqueID] = benefit.isSelected;
				if (benefit.isSelected) {
					this.selectedIndexes.push(benefit);
				}
			});
		});
	}
}
