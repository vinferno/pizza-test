import { Component, OnDestroy, OnInit, ChangeDetectorRef, Output } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { FormService } from '../../../../../../../infrastructure/shared/controls/form/form.service';
import { Observable } from 'rxjs';
import { WizardTobaccoModel } from 'app/infrastructure/interfaces/wizard-tobacco-model';

const isSmoker = 'isSmoker';

@Component({
	selector: 'hg-form-tobacco-usage',
	templateUrl: './form-tobacco-usage.component.html',
	styleUrls: ['./form-tobacco-usage.component.scss'],
})
export class FormTobaccoUsageComponent extends FormContentBase implements OnInit, OnDestroy {
	public tobaccoModel: WizardTobaccoModel;
	public coveredMembers;
	public answer = { isSmoker: null };
	public SingleResponseIsSmoker = null;

	public subscriptions = [];
	public settingsState;
	public settings;
	public tobaccoQuestion: string = '';
	public displayedColumns = [
		{
			columnName: 'Covered Member',
			columnId: 'coveredMemberName',
		},
		{
			columnName: 'Relationship',
			columnId: 'relationship',
		},
	];

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
		private formService: FormService,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.service.getTobacco().subscribe(tobacco => {
			this.tobaccoModel = tobacco;
	});
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	postForm() {
		const payload = { CoveredMemberQuestions: this.tobaccoModel.coveredMembers.items, SingleResponseIsSmoker: this.answer.isSmoker };
		this.service.postTobacco(payload).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	checkValid() {
		if (!this.tobaccoModel) {
			return;
		}
		let valid = true;
		this.tobaccoModel.coveredMembers.items.forEach(member => {
			if (!member.hasOwnProperty(isSmoker)) {
				valid = false;
			}
		});
		if (this.tobaccoModel.hideSmokerResponseMembers && this.answer.isSmoker) {
			valid = true;
		}
		return valid;
	}
	onSelect(simpleAnswer, singleQuestion) {
		if (singleQuestion) {
			this.answer.isSmoker = simpleAnswer.value;
		} else {
		this.tobaccoModel.coveredMembers.items.forEach(member => {
			if (member.systemNumber === simpleAnswer.ID) {
				member.isSmoker = simpleAnswer.value;
			}
		});
	}
	}
}
