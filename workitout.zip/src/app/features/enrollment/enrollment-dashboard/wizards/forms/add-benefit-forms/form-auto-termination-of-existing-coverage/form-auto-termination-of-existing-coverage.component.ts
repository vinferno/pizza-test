import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef,
	OnDestroy,
} from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';

@Component({
	selector: 'hg-form-auto-termination-of-existing-coverage',
	templateUrl: './form-auto-termination-of-existing-coverage.component.html',
	styleUrls: ['./form-auto-termination-of-existing-coverage.component.scss'],
})
export class FormAutoTerminationOfExistingCoverageComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form;
	@Input()
	public selectedCategory;
	public benefits: any;
	public pageDisabled: boolean = true;
	public benefitGrid;
	public subscriptions = [];
	public settingsState;
	public settings;

	public displayedColumns = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
		{
			columnName: 'Termination Date',
			columnId: 'terminationDate',
		},
	];

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe( settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.getAvailableBenefits();
		this.setAllowContinue(true);
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	getAvailableBenefits(): void {
		this.service.getAutoTerm()
			.subscribe((benefits: any) => {
				this.benefits = benefits.items;
				this.loading = false;
			});
	}

	postForm() {
		this.service.postAutoTerm({ }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}
}
