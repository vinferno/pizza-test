import {
	Component,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
} from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';

@Component({
	selector: 'hg-form-primary-care-physician',
	templateUrl: './form.primary-care-physician.component.html',
	styleUrls: ['./form.primary-care-physician.component.scss'],
})
export class FormPrimaryCarePhysicianComponent extends FormContentBase implements OnInit, OnDestroy {
	public getResponse;
	public columnList = [{ columnName: 'Covered Member', columnId: 'coveredMemberName' }];

	public payload = {};

	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.service.getPcp().subscribe(pcp => { this.getResponse = pcp; });
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	postForm() {
		let payload = [];
		this.getResponse.pcpCards.forEach(card => {
			payload = payload.concat(card.coveredMembersForPcp);
		});
		this.service.postPcp({ PcpCriterias: payload }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public openTab(url) {
		window.open(url);
	}

}
