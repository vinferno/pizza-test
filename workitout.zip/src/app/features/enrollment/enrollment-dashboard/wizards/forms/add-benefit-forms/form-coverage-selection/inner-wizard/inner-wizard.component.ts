import {
	Component,
	EventEmitter,
	Input,
	OnChanges,
	OnInit,
	Output,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	OnDestroy,
}                                from '@angular/core';
import {
	FormBuilder,
	FormGroup,
}                                from '@angular/forms';
import { Router }                from '@angular/router';

import {
	BehaviorSubject,
	Observable,
	Subscription,
}                                from 'rxjs';
import { Store }                 from '@ngrx/store';

import { ApiService }            from 'app/infrastructure/core/api/api.service';
import {
	CoveragePayload,
	CoverageTab,
}                                from 'app/infrastructure/interfaces/coverage';
import { EnrollmentAddService }  from 'app/infrastructure/enrollment/enrollment-add.service';
import { EnrollmentState }       from 'app/infrastructure/store/reducers/enrollment/enrollment-state';
import { IError }                from 'app/infrastructure/interfaces/error';
import { Form }                  from 'app/infrastructure/interfaces/form';
import { FormDialogBase }        from 'app/infrastructure/core/classes/form-wizard';
import { FormPersistentService } from 'app/infrastructure/core/services/form-persistent.service';
import { NextPanel }             from 'app/infrastructure/interfaces/next-panel';
import { SettingsState }         from 'app/infrastructure/store/reducers/settings/settings-state';
import { stateActions } from '../../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector: 'hg-inner-wizard',
	templateUrl: './inner-wizard.component.html',
	styleUrls: ['./inner-wizard.component.scss'],
	changeDetection: ChangeDetectionStrategy.Default,
})
export class InnerWizardComponent extends FormDialogBase implements OnInit, OnChanges, OnDestroy {

	@Output() public emitDone: EventEmitter<any> = new EventEmitter();
	@Output() public emitSubmitCoverage: EventEmitter<any> = new EventEmitter();
	@Output() public emitGetCoverage: EventEmitter<any> = new EventEmitter();

	public payload: CoveragePayload = new CoveragePayload();
	public payloadDefaults: CoveragePayload = new CoveragePayload();
	public formGroup: FormGroup;
	public isReady: boolean = false;
	public nextPanel: string;
	public errorMessage: IError = new IError();
	@Input() public showHide;
	public finalResponse: NextPanel;
	public formWizardName: string = 'Add 2';
	public returnRoute: string = '/enrollment-dashboard';
	public formsInit: Form[] = [];
	public checked = true;
	public enrollment;
	public enrollmentState: Observable<EnrollmentState>;
	public settings: SettingsState;
	public settingsState: Observable<SettingsState>;
	public subscriptions: Subscription[] = [];
	public wizardType: string = 'add';

	constructor(
		public api: ApiService,
		public fb: FormBuilder,
		public formService: FormPersistentService,
		public router: Router,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(formService, router, api, cd, store);
	}

	public getCoverage() {
		this.emitGetCoverage.emit();
	}

	public ngOnInit(): void {
		this.formGroup = this.fb.group(new CoveragePayload());
		this.initializeState();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public ngOnChanges( change): void {
	}

	public submitCoverageSelection(): void {
		this.errorMessage = null;
		this.emitSubmitCoverage.emit(this.formGroup.value);
	}

	public cancelForm(): void {
		this.service.selectCategory(this.enrollment.selectedCategory);
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
			this.cd.detectChanges();
		});
		this.subscriptions.push(enrollmentSubscription);
	}

	private createFormGroup(): void {
		this.formGroup = this.fb.group(this.payloadDefaults);
	}
}
