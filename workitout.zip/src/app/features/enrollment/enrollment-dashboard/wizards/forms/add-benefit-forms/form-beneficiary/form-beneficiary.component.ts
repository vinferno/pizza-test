import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                                 from '@angular/core';

import {
	Observable,
	Subscription,
}                                 from 'rxjs';
import { Store }                  from '@ngrx/store';

import { ApiService }             from 'app/infrastructure/core/api/api.service';
import {
	BeneficiariesResponse,
	BenefitCardBeneficiariesForDisplay,
	BeneficiaryPayload,
}                                 from 'app/infrastructure/interfaces/beneficiary';
import { Form }                   from 'app/infrastructure/interfaces/form';
import { FormContentBase }        from 'app/infrastructure/core/classes/form-wizard';
import { EnrollmentAddService }   from 'app/infrastructure/enrollment//enrollment-add.service';
import { SettingsState }          from 'app/infrastructure/store/reducers/settings/settings-state';
@Component({
	selector        : 'hg-form-beneficiary',
	templateUrl     : './form-beneficiary.component.html',
	styleUrls       : ['./form-beneficiary.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FormBeneficiaryComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;

	public beneficiariesList: BenefitCardBeneficiariesForDisplay[];
	public buttonLabel: string = 'Submit';
	public instructionHTML: string = '';
	public settingsState$: Observable<SettingsState>;
	public subscriptions: Subscription[] = [];

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	public ngOnInit(): void {
		this.initializeState();
		this.getBeneficiaries();
	}

	public ngOnDestroy(): void {
		this.cd.detach();
	}

	public postForm(payload: BeneficiaryPayload): void {
		this.service.postBeneficiary(payload).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	private initializeState(): void {
		this.settingsState$ = this.store.select('settingsState');
	}

	private getBeneficiaries(): void {
		this.service.getBeneficiary().subscribe((beneficiariesResponse: BeneficiariesResponse) => {
			this.beneficiariesList = beneficiariesResponse.benefitBeneficiaryCards[0].beneficiariesForDisplay;
			this.instructionHTML = beneficiariesResponse.instructionHTML;
			this.cd.detectChanges();
		});
	}
}
