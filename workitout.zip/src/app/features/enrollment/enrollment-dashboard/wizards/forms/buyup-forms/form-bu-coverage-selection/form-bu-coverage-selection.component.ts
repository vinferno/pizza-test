import {
	Component,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
}                                 from '@angular/core';

import {
	BehaviorSubject,
	Observable,
	Subscription,
}                                 from 'rxjs';
import { Store }                  from '@ngrx/store';

import { ApiService }             from '../../../../../../../infrastructure/core/api/api.service';
import { CoverageTab }            from '../../../../../../../infrastructure/interfaces/coverage';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { FormContentBase }        from '../../../../../../../infrastructure/core/classes/form-wizard';
import { SettingsState }          from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { StepperState } from '../../../../../../../infrastructure/store/reducers/stepper/stepper-state';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';


@Component({
	selector    : 'hg-form-bu-coverage-selection',
	templateUrl : './form-bu-coverage-selection.component.html',
	styleUrls   : ['./form-bu-coverage-selection.component.scss'],
})
export class FormBuCoverageSelectionComponent extends FormContentBase implements OnInit, OnDestroy {
	public showHide: CoverageTab = new CoverageTab();
	public settingsState: Observable<SettingsState>;
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];

	constructor(
		public api: ApiService,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
		this.getCoverage();
		this.subscriptions.push(
			this.store.select('stepperState').subscribe((steppers: StepperState) => {
				if (steppers.type === stateActions.stepperActions.types.STEPPER_UPDATE_SECONDARY) {
					const stepperLength = steppers.secondaryStepper.length;
					if ( stepperLength < steppers.showHideArray.length) {
						this.changeIndex(steppers.showHideArray[stepperLength - 1].benefitNumber )
					}
				}
				if (steppers.type === stateActions.stepperActions.types.STEPPER_UPDATE_SHOWHIDE) {
					this.showHide = steppers.showHide;
				}
				this.cd.detectChanges();
			}),
		)

	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => sub.unsubscribe());
		this.store.dispatch(stateActions.stepperActions.updateShowHide(null));
		this.store.dispatch(stateActions.stepperActions.resetSecondary());
	}

	private getCoverage(): void {
		this.showHide = null;
		this.service.getCoverage().subscribe(coverage => {
			if (coverage) {
				this.store.dispatch(stateActions.stepperActions.updateShowHideArray(coverage.coverageTabs));
				this.store.dispatch(stateActions.stepperActions.updateShowHide(coverage.coverageTabs.slice(-1)[0]));
				this.store.dispatch(stateActions.stepperActions.updateSecondary(coverage.coverageTabs.slice(-1)[0].coverageTabName));
			}
		});
	}

	public finalizeInnerWizard(event: any): void {
		if (event.nextPanel.value !== 'coverageSummary') {
			this.changeForm(event.nextPanel.value);
		}

	}

	public submitCoverageSelection($event): void {
		this.service.submitCoverageSelections($event).subscribe(
			(response) => this.loadNext(response),
			(error) => {
				// this.payload = new CoveragePayload();
				// this.errorMessage = error;
			},
		);
	}

	public loadNext(response) {
		if (response.nextPanel.value.toLowerCase() === 'coverage') {
			this.getCoverage();
		} else {
			this.finalizeInnerWizard(response);
		}
	}

	public changeIndex(benefitNumber: number): void {
		this.service.postCoverageSelection( benefitNumber).subscribe(showHide => {
			this.getCoverage();
		});
	}
}
