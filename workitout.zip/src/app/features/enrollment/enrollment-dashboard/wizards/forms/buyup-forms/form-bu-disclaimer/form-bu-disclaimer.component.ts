import { Component, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';


@Component({
	selector: 'hg-form-bu-disclaimer',
	templateUrl: './form-bu-disclaimer.component.html',
	styleUrls: ['./form-bu-disclaimer.component.scss'],
})
export class FormBuDisclaimerComponent extends FormContentBase implements OnInit, OnDestroy {
	public getResponse;
	public agree = false;
	public loading: boolean = true;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.service.getDisclaimer().subscribe(disclaimer => { this.getResponse = disclaimer; this.loading = false; });
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	public toggleCheckbox(event: any): void {
		this.agree = event.value;
	}

	submitDisclaimerForm() {
		this.service.postDisclaimer(null).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}
}
