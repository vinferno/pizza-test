import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                               from '@angular/core';

import { Store }                from '@ngrx/store';
import {
	Observable,
	Subscription,
}                               from 'rxjs';

import { ApiService }           from '../../../../../../../infrastructure/core/api/api.service';
import { BenefitSummaryList }   from '../../../../../../../infrastructure/interfaces/benefit';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { Form }                 from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }      from '../../../../../../../infrastructure/core/classes/form-wizard';
import { SettingsState }        from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';
import { EndingBenefit } from '../../../../../../../infrastructure/store/reducers/ending-benefit/ending-benefit';

@Component({
	selector        : 'hg-form-summary',
	templateUrl     : './form-summary.component.html',
	styleUrls       : ['./form-summary.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FormSummaryComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public buttonLabel: string = 'Submit';
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];
	public summaryList: BenefitSummaryList;

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.getSummary();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public postForm(): void {
		this.service.postSummary(null).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
	}

	private getSummary(): void {
		const summarySub = this.service.getSummary().subscribe(summary => {
			this.summaryList = summary;
			this.cd.detectChanges();
		});
		this.subscriptions.push(summarySub);
		this.subscriptions.push(
			this.store.select('endingBenefitState').subscribe( (endingBenefits: EndingBenefit) => {
				if (endingBenefits && endingBenefits.session === 0) {
					this.buttonLabel = 'Continue';
				} else {
					this.buttonLabel = 'Submit';
				}
			}),
		)
	}
}
