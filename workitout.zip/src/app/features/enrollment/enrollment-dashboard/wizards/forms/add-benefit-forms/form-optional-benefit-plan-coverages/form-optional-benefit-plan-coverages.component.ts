import { Component, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { IAvailableBenefits } from '../../../../../../../infrastructure/interfaces/available-benefit';

@Component({
	selector: 'hg-form-optional-benefit-plan-coverages',
	templateUrl: './form-optional-benefit-plan-coverages.component.html',
	styleUrls: ['./form-optional-benefit-plan-coverages.component.scss'],
})
export class FormOptionalBenefitPlanCoveragesComponent extends FormContentBase implements OnInit, OnDestroy {
	public benefits: IAvailableBenefits[];
	public getResponse: any;
	public displayedColumns = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
		{
			columnName: 'Number',
			columnId: 'number',
		},
	];

	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.getAvailableBenefits();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	getAvailableBenefits(): void {
		this.service.getKitBenefits().subscribe(kitBenefits => {
			this.getResponse = kitBenefits.items;
			this.benefits = kitBenefits.items;
			this.loading = false;
		});
		this.setAllowContinue(true);
	}
}
