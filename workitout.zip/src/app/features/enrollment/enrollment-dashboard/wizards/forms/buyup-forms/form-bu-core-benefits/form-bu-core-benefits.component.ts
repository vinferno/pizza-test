import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef,
	OnDestroy,
}                                 from '@angular/core';

import { DxDataGridComponent }    from 'devextreme-angular';
import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                 from 'rxjs';

import { ApiService }             from '../../../../../../../infrastructure/core/api/api.service';
import {
	CoreBenefit,
	CoreBenefitCategory,
	CoreBenefitPayload,
	CoreBenefitMultiple,
}                                 from '../../../../../../../infrastructure/interfaces/core-benefit';
import { EnrollmentCategory }     from '../../../../../../../infrastructure/interfaces/enrollment-category';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { Form }                   from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }        from '../../../../../../../infrastructure/core/classes/form-wizard';
import { SettingsState }          from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from '../../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector    : 'hg-form-bu-core-benefits',
	templateUrl : './form-bu-core-benefits.component.html',
	styleUrls   : ['./form-bu-core-benefits.component.scss'],
})
export class FormBuCoreBenefitsComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;
	@Input() public selectedCategory: EnrollmentCategory;

	public benefitGrid: any;
	public benefitsList: CoreBenefitMultiple[] = [];
	public emptyGridMessage: string = 'No benefits currently available.';
	public isLoaded: boolean = false;
	public uniqueIds: string[] = [];

	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
	];

	public subscriptions: Subscription[] = [];
	public settings: SettingsState;

	private benefitCategory: CoreBenefitCategory[] = [];
	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		private service: EnrollmentBuyupService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit(): void {
		this.initializeState();
		this.getCoreBenefits();
		this.setAllowContinue(true);
	}

	ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.populateUniqueIDs();
		const payload: CoreBenefitPayload = {
			uniqueIDs: this.uniqueIds,
		};
		this.service.postCoreBenefits(payload).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public dataGridChange(grid: DxDataGridComponent, event: any, categoryID: number): void {
		this.benefitGrid = event.component;
		this.benefitCategory.forEach(category => {
			if (category.categoryID === categoryID) { this.benefitGrid.selectRows(category.indices); }
		});

		grid.selectedRowKeysChange.subscribe((rows: CoreBenefit[]) => {
			this.benefitCategory.forEach(category => {
				if (category.categoryID === categoryID) {
					category.uniqueIDs = rows.map(row => row.uniqueID);
				}
			});
			this.cd.detectChanges();
		});
	}

	public isEveryCategorySelected(): boolean {
		return this.benefitCategory.every(category => category.uniqueIDs.length === 1);
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private getCoreBenefits(): void {
		this.service.getCoreBenefits().subscribe((benefits) => {
			this.benefitsList = benefits.benefitCategories;
			this.setupBenefitCategoryList();
		});
	}

	private setupBenefitCategoryList() {
		this.benefitsList.forEach(benefitCategory => {
			const category: CoreBenefitCategory = new CoreBenefitCategory();
			category.categoryID = benefitCategory.categoryID;
			category.indices = benefitCategory.items.filter(benefit => benefit.isSelected);
			this.benefitCategory.push(category);
		});
		this.isLoaded = true;
	}

	private populateUniqueIDs(): void {
		this.uniqueIds = [];
		this.benefitCategory.forEach(category => {
			category.uniqueIDs.forEach(uniqueID => this.uniqueIds.push(uniqueID));
		});
	}
}
