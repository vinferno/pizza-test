import { Component, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';


@Component({
	selector: 'hg-form-domestic-partner-disclaimer',
	templateUrl: './form-domestic-partner-disclaimer.html',
	styleUrls: ['./form-domestic-partner-disclaimer.scss'],
})
export class FormDomesticPartnerDisclaimerComponent extends FormContentBase implements OnInit, OnDestroy {
	public getResponse;
	public agree = false;
	public loading: boolean = true;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.service.getDpDisclaimer().subscribe(dpDisclaimer => {
			this.getResponse = dpDisclaimer;
			this.loading = false;
		});
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	public toggleCheckbox(event: any): void {
		this.agree = event.value;
	}

	submitDomesticPartnerDisclaimer() {
		this.service.postDpDisclaimer(null).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}
}
