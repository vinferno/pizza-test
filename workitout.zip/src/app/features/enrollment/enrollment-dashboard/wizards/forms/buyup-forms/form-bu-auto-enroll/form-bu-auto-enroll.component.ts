import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	OnDestroy,
} from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';

@Component({
	selector: 'hg-form-bu-auto-enroll',
	templateUrl: './form-bu-auto-enroll.component.html',
	styleUrls: ['./form-bu-auto-enroll.component.scss'],
})
export class FormBuAutoEnrollComponent extends FormContentBase implements OnInit, OnDestroy {

	@Input()
	public form;
	@Input()
	public selectedCategory;
	public benefits: any;
	public multiSelect: boolean = false;
	public effectiveDate: Date = new Date();
	public pageDisabled: boolean = true;
	public getResponse;
	public selectMode;
	public uniqueIds = [];
	public selectedObject = {};
	public selectedRows = [];
	public benefitGrid;
	public selectedIndexes = [];
	public lastSelection = null;
	public currentSelection = [];

	public displayedColumns = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
	];
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentBuyupService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);

		this.getAvailableBenefits();
		this.setAllowContinue(true);
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	getAvailableBenefits(): void {
		this.service.getAutoEnroll()
			.subscribe((benefits: any) => {
				this.selectMode = benefits.isMultiSelect ? 'multiple' : 'single';
				this.benefits = benefits.items; this.loading = false;
				this.getResponse = benefits;
				this.benefits.forEach((benefit, index) => {
					this.selectedObject[benefit.uniqueID] = benefit.isSelected;
					if (benefit.isSelected) {
						this.selectedIndexes = benefit;
					}
				});
			});
	}

	postForm() {
		this.service.postAutoErnoll({ uniqueIds: this.uniqueIds }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	dataGridChange(grid, event) {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);

		grid.selectedRowKeysChange.subscribe((rows) => {
			if (rows.length === 1) { this.lastSelection = rows[0]; }
			if (rows.length === 2) {
				rows.splice(rows.indexOf(this.lastSelection), 1);
				this.benefitGrid.selectRows(rows);
			}
			if (rows.length > 2) { this.benefitGrid.selectRows([]); }

			this.uniqueIds = rows.map(row => { return row.uniqueID; });

			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}
}
