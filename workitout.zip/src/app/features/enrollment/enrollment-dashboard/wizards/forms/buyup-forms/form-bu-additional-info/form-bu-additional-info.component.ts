import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	OnInit,
}                                 from '@angular/core';
import {
	AbstractControl,
	FormBuilder,
	FormGroup,
	Validators,
}                                 from '@angular/forms';

import { Store }                  from '@ngrx/store';

import { ApiService }             from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import {
	EnrollmentModuleServiceType,
	EnrollModuleBase,
	EnrollModuleBeneficiaryPayload,
	EnrollModulePayload,
	EnrollModuleQuestionPayload,
	EnrollModuleQuestion,
}                                 from '../../../../../../../infrastructure/interfaces/enrollment-module';
import { FormContentBase }        from '../../../../../../../infrastructure/core/classes/form-wizard';
import { FormService }            from '../../../../../../../infrastructure/shared/controls/form/form.service';

@Component({
	selector        : 'hg-form-bu-additional-info',
	templateUrl     : './form-bu-additional-info.component.html',
	styleUrls       : ['./form-bu-additional-info.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FormBuAdditionalInfoComponent extends FormContentBase implements OnInit {
	public enrollModule: EnrollModuleBase = new EnrollModuleBase();
	public enrollModuleQuestionList: EnrollModuleQuestion[] = [];
	public enrollService: EnrollmentModuleServiceType = { enrollModuleService: 'enrollmentModuleBuyup' };

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		private fb: FormBuilder,
		public formService: FormService,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.getAdditionalInfo();
	}

	public postForm(): void {
		const payload: EnrollModulePayload = this.buildEnrollModulePayload();
		this.service.postAdditionalInfo(payload).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public postFormEM(): void {
		this.service.postAdditionalInfo(null).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public enrollModuleQuestions(): AbstractControl {
		return this.form.fg.get('enrollModuleQuestions');
	}

	private getAdditionalInfo(): void {
		this.service.getAdditionalInfo().subscribe(response => {
			this.enrollModule = response;
			if (response.enrollModule !== 'Aflac' && response.enrollModule !== 'TransamericaAccident17') { this.buildForm(); }
			this.cd.detectChanges();
		});
	}

	private buildForm(): void {
		if (this.form.fg.contains('enrollModuleQuestions')) { this.form.fg.removeControl('enrollModuleQuestions'); }
		this.form.fg.addControl('enrollModuleQuestions', new FormGroup({ }));

		this.enrollModuleQuestionList = this.enrollModule.enrollModuleQuestions.filter(question => {
			return question.isActive;
		})

		this.enrollModuleQuestionList.forEach(question => {
			this.formService.addFormControl(this.form.fg.get('enrollModuleQuestions'), question.name, [Validators.required]);
		});
	}

	private buildEnrollModulePayload(): EnrollModulePayload {
		const payload: EnrollModulePayload = new EnrollModulePayload();

		payload.enrollModule = this.enrollModule.enrollModule;
		if (this.form.fg.value && this.form.fg.value.enrollModuleBeneficiaries) {
			payload.enrollModuleBeneficiaries = this.buildEnrollModuleBeneficiariesPayload(this.form.fg.value.enrollModuleBeneficiaries);
		}
		this.enrollModuleQuestionList.forEach(question => {
			const enrollModuleQuestion: EnrollModuleQuestionPayload = new EnrollModuleQuestionPayload();
			enrollModuleQuestion.id = question.id;
			enrollModuleQuestion.questionResponse = this.enrollModuleQuestions().value[question.name];
			payload.enrollModuleQuestions.push(enrollModuleQuestion);
		});

		return payload;
	}

	private buildEnrollModuleBeneficiariesPayload(enrollModuleBeneficiaries: EnrollModuleBeneficiaryPayload[]): EnrollModuleBeneficiaryPayload[] {
		for (const property in enrollModuleBeneficiaries[1]) {
			if (enrollModuleBeneficiaries[1].hasOwnProperty(property) && enrollModuleBeneficiaries[1][property]) {
				return enrollModuleBeneficiaries;
			}
		}

		// Remove element [1] if empty
		return enrollModuleBeneficiaries.splice(0, 1);
	}
}
