import { Component, OnDestroy, OnInit, ChangeDetectorRef, EventEmitter, Output, Input } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService }           from '../../../../../../../infrastructure/core/api/api.service';
import { FormContentBase }      from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { Router }               from '@angular/router';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';


@Component({
	selector: 'hg-form-ending-benefit',
	templateUrl: './form-ending-benefit.component.html',
	styleUrls: ['./form-ending-benefit.component.scss'],
})
export class FormEndingBenefitComponent extends FormContentBase implements OnInit, OnDestroy {
	public getResponse;
	public agree = false;
	public loading: boolean = true;
	public subscriptions = [];
	public settingsState;
	public settings;
	public routerState;

	@Input()
	public form;
	@Input()
	public selectedCategory;

	@Input()
	public data;
	public benefits: any;
	public multiSelect: boolean = false;
	public pageDisabled: boolean = true;
	public selectMode;
	public uniqueIds = [];
	public selectedObject = {};
	public selectedRows = [];
	public benefitGrid;
	public selectedIndexes = [];
	public lastSelection = null;
	public currentSelection = [];
	public endingBenefit;

	public displayedColumns = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
		{
			columnName: 'Available On',
			columnId: 'availableOn',
		},

	];

	@Output()
	public endingBenefitEmitter = new EventEmitter();

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
		public router: Router,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		const routerSubscription = this.store.select('routerState').subscribe(routerState => {
			this.routerState = routerState;
		});
		this.subscriptions.push( routerSubscription);
		this.service.getFutureBenefits().subscribe((disclaimer: any) => {
			this.getResponse = disclaimer;
			this.store.dispatch(stateActions.enrollmentActions.updateSecondaryMode(this.getResponse.secondaryMode));
			this.loading = false;
			this.store.dispatch(stateActions.endingBenefitActions.updateSession(1));
			this.selectMode = disclaimer.isMultiSelect ? 'multiple' : 'single';
		});
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
		this.store.dispatch(stateActions.endingBenefitActions.updateSession(0));
	}

	public toggleCheckbox(event: any): void {
		this.agree = event.value;
	}

	submitDisclaimerForm() {
		this.endingBenefitEmitter.emit()
	}

	dataGridChange(grid, event) {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		grid.selectedRowKeysChange.subscribe((rows) => {
			if (this.selectMode === 'single') {
				if (rows.length === 1) {
					this.lastSelection = rows[0];
				}
				if (rows.length === 2) {
					rows.splice(rows.indexOf(this.lastSelection), 1);
					this.benefitGrid.selectRows(rows);
				}
				if (rows.length > 2) {

					this.benefitGrid.selectRows([]);
				}
			} else {
				this.benefitGrid.selectRows(rows.concat(this.selectedIndexes));
			}

			this.uniqueIds = rows.map(row => {
				return row.uniqueID;
			});

			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}

	postForm() {
		this.service.postFutureBenefitSelect({ uniqueIds: this.uniqueIds }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}
}
