import {
	Component,
	OnInit,
	Input,
	ChangeDetectorRef,
	OnDestroy,
}                               from '@angular/core';

import { DxDataGridComponent }  from 'devextreme-angular';
import { Store }                from '@ngrx/store';
import {
	Observable,
	Subscription,
}                               from 'rxjs';

import { ApiService }           from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCategory }   from '../../../../../../../infrastructure/interfaces/enrollment-category';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { Form }                 from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }      from '../../../../../../../infrastructure/core/classes/form-wizard';
import {
	KitBenefit,
	KitBenefitPayload,
}                               from '../../../../../../../infrastructure/interfaces/kit-benefit';
import { SettingsState }        from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }         from '../../../../../../../infrastructure/interfaces/table-columns';


@Component({
	selector    : 'hg-form-kit-benefits',
	templateUrl : './form-kit-benefits.component.html',
	styleUrls   : ['./form-kit-benefits.component.scss'],
})
export class FormKitBenefitsComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;
	@Input() public selectedCategory: EnrollmentCategory;

	public benefitGrid: any;
	public benefitsList: KitBenefit[] = [];
	public currentSelection: KitBenefit[] = [];
	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
	];
	public isLoaded: boolean = false;
	public lastSelection: KitBenefit = null;
	public selectMode = {
		mode           : '',
		allowSelectAll : false,
	};
	public selectFunction: Function;
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];
	public uniqueIds: string[] = [];

	private selectedIndexes: KitBenefit[] = [];
	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		private service: EnrollmentAddService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit(): void {
		this.initializeState();
		this.getKitBenefits();
	}

	ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		const payload: KitBenefitPayload = {
			uniqueIDs: this.uniqueIds,
		};
		this.service.postKitBenefits(payload).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	public dataGridChange(grid: DxDataGridComponent, event: any): void {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		this.selectFunction(grid);
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private getKitBenefits(): void {
		this.service.getKitBenefits().subscribe((benefits) => {
			this.selectMode = benefits.isMultiSelect
				? { mode: 'multiple', allowSelectAll: true }
				: { mode: 'multiple', allowSelectAll: false };
			(benefits.isMultiSelect)
				? this.selectFunction = this.selectMultipleRows
				: this.selectFunction = this.selectSingleRow;

			this.benefitsList = benefits.items;
			this.selectedIndexes = this.benefitsList.filter(benefit => benefit.isSelected);
			this.isLoaded = true;
		});
	}

	private selectSingleRow(grid: DxDataGridComponent): void {
		grid.selectedRowKeysChange.subscribe((rows) => {
			if (rows.length === 1) { this.lastSelection = rows[0]; }
			if (rows.length === 2) {
				rows.splice(rows.indexOf(this.lastSelection), 1);
				this.benefitGrid.selectRows(rows);
			}
			if (rows.length > 2) { this.benefitGrid.selectRows([]); }
			this.uniqueIds = rows.map(row => row.uniqueID);
			this.cd.detectChanges();
		});
	}

	private selectMultipleRows(grid: DxDataGridComponent): void {
		grid.selectedRowKeysChange.subscribe((rows) => {
			this.uniqueIds = rows.map(row => row.uniqueID);
			this.cd.detectChanges();
		});
	}
}
