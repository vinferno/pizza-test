import { Component, OnInit, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService }           from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormContentBase }      from '../../../../../../../infrastructure/core/classes/form-wizard';
import { stateActions }         from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector: 'hg-form-available-benefit',
	templateUrl: './form-available-benefit.component.html',
	styleUrls: ['./form-available-benefit.component.scss'],
})
export class FormAvailableBenefitComponent extends FormContentBase implements OnInit, OnDestroy {

	@Input() public form;

	public benefits: any;
	public multiSelect: boolean = false;
	public pageDisabled: boolean = true;
	public getResponse;
	public selectMode;
	public uniqueIds = [];
	public selectedObject = {};
	public selectedRows = [];
	public benefitGrid;
	public selectedIndexes = [];
	public lastSelection = null;
	public currentSelection = [];
	public endingBenefit;

	public displayedColumns = [
		{
			columnName: 'Benefit',
			columnId: 'enrollmentName',
		},
		{
			columnName: 'Available On',
			columnId: 'availableOn',
		},
		{
			columnName: 'Unavailable On',
			columnId: 'unavailableOn',
		},
	];
	public columnOptions = {
		showUnavailableColumn: [
			{
				columnName: 'Benefit',
				columnId: 'enrollmentName',
			},
			{
				columnName: 'Available On',
				columnId: 'availableOn',
			},
			{
				columnName: 'Unavailable On',
				columnId: 'unavailableOn',
			},
		],
		hideUnavailableColumn: [
			{
				columnName: 'Benefit',
				columnId: 'enrollmentName',
			},
			{
				columnName: 'Available On',
				columnId: 'availableOn',
			},
		],
	};
	public subscriptions = [];
	public settingsState;
	public settings;
	public enrollmentState;
	public enrollment;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
		});
		const benefitEndingSub = this.store.select('endingBenefitState').subscribe(endingBenefit => {
			this.endingBenefit = endingBenefit;
		});
		this.subscriptions.push(enrollmentSubscription);

		let payload = null;

		if (this.enrollment.wizard.name === 'Waive Benefit') {
			payload = this.enrollment.categoryOptions.waiveBenefitNumber;
		}

		if (this.endingBenefit.session === 0) {
			this.service.postInitialize(payload).subscribe((response: any) => {
				this.changeForm(response.nextPanel.value);
				this.getAvailableBenefits();
			});
		}

		if (this.endingBenefit.session === 1) {
			this.getAvailableBenefits();
		}
		this.setAllowContinue(true);
		this.store.dispatch(stateActions.endingBenefitActions.updateSession(0));
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	getAvailableBenefits(): void {
		this.service.getCategoryList()
			.subscribe((benefits: any) => {
				this.store.dispatch(stateActions.endingBenefitActions.updateDetectedEnding(benefits.futurePanelWarningMessage));
				this.selectMode = benefits.isMultiSelect ? 'multiple' : 'single';
				this.benefits = benefits.items; this.loading = false;

				this.getResponse = benefits;
				this.displayedColumns = benefits.showUnavailableColumn ? this.columnOptions.showUnavailableColumn : this.columnOptions.hideUnavailableColumn;
				this.benefits.forEach((benefit, index) => {
					this.selectedObject[benefit.uniqueID] = benefit.isSelected;
					if (benefit.isSelected) {
						this.selectedIndexes = benefit;
					}
				});
			});
	}

	postForm() {
		this.service.postBenefitSelect({ uniqueIds: this.uniqueIds }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
			// this.skipTo(response.nextPanel.value);
		});
	}

	dataGridChange(grid, event) {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		grid.selectedRowKeysChange.subscribe((rows) => {
			if (this.selectMode === 'single') {
				if (rows.length === 1) {
					this.lastSelection = rows[0];
				}
				if (rows.length === 2) {
					rows.splice(rows.indexOf(this.lastSelection), 1);
					this.benefitGrid.selectRows(rows);
				}
				if (rows.length > 2) {

					this.benefitGrid.selectRows([]);
				}
			} else {
				this.benefitGrid.selectRows(rows.concat(this.selectedIndexes));
			}

			this.uniqueIds = rows.map(row => {
				return row.uniqueID;
			});

			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}
}
