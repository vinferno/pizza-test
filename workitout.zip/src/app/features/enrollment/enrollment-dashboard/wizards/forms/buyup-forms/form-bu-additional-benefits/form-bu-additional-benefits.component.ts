import { Component, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';


@Component({
	selector: 'hg-form-bu-additional-benefits',
	templateUrl: './form-bu-additional-benefits.component.html',
	styleUrls: ['./form-bu-additional-benefits.component.scss'],
})
export class FormBuAdditionalBenefitsComponent extends FormContentBase implements OnInit, OnDestroy {
	public getResponse;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.service.getAdditionalInfo().subscribe(additionalInfo => { });

		this.setAllowContinue(true);
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}
}
