import { Component, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentAddService } from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';
import { BenefitDisclaimer } from '../../../../../../../infrastructure/interfaces/benefit';


@Component({
	selector: 'hg-form-future-benefits-disclaimer',
	templateUrl: './form-future-benefits-disclaimer.component.html',
	styleUrls: ['./form-future-benefits-disclaimer.component.scss'],
})
export class FormFutureBenefitsDisclaimerComponent extends FormContentBase implements OnInit, OnDestroy {
	public disclaimer: BenefitDisclaimer;
	public loading: boolean = true;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentAddService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.service.getFutureBenefitsDisclaimer().subscribe(response => {
			this.disclaimer = response;
			this.loading = false;
		});
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	submitDisclaimerForm() {
		this.store.dispatch(stateActions.endingBenefitActions.updateSession(1));
		this.service.postFutureBenefitsDisclaimer(null).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}
}
