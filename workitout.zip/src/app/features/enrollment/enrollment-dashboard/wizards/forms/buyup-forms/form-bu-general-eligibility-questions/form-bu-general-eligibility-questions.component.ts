import {
	Component,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
} from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import {
	Eligibility,
	EligibilityGrid,
	EligibilityPayload,
} from '../../../../../../../infrastructure/interfaces/eligibility';
import { EnrollmentBuyupService } from '../../../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { TableColumns } from '../../../../../../../infrastructure/interfaces/table-columns';


@Component({
	selector: 'hg-form-bu-general-eligibility-questions',
	templateUrl: './form-bu-general-eligibility-questions.component.html',
	styleUrls: ['./form-bu-general-eligibility-questions.component.scss'],
})
export class FormBuGeneralEligibilityQuestionsComponent extends FormContentBase implements OnInit, OnDestroy {
	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Covered Member',
			columnId: 'coveredMemberName',
		},
		{
			columnName: 'Relationship',
			columnId: 'relationship',
		},
	];
	public eligibilityGridList: EligibilityGrid[] = new Array<EligibilityGrid>();
	public isLoaded: boolean = false;
	public isComplete: boolean = false;

	private eligibility: Eligibility = new Eligibility();
	private gridTitles = {
		disabilityTitle: 'Spouse Or Child Currently Disabled',
		titleXIXTitle: 'Medicaid Coverage',
		spouseTitle: 'Spouse Coverage Exclusion',
		medicalTitle: 'Medical Coverage',
	};
	public payload: EligibilityPayload[] = new Array<EligibilityPayload>();

	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public service: EnrollmentBuyupService,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.getEligibility();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		});
	}

	public selectResponse(event: { event: any, cell: EligibilityPayload }): EligibilityPayload {
		this.payload.forEach(response => {
			if (response.knockoutDependentID === event.cell.knockoutDependentID) {
				response.isYesResponse = event.event.value;
				event.cell.isYesResponse = event.event.value;
			}
		});

		this.checkQuestions();

		return event.cell;
	}

	public submitEligibilityQuestions(): void {
		this.service.postEligibility({ selectedCoverageEligibilityKnockouts: this.payload }).subscribe(response => {
			this.changeForm(response.nextPanel.value);
		});
	}

	private getEligibility(): void {
		this.service.getEligibility().subscribe(eligibility => {
			this.eligibility = eligibility;
			this.buildGridList();
			this.isLoaded = true;
		});
	}

	private buildPayload(): void {
		this.eligibilityGridList.forEach(eligibilityGrid => {
			eligibilityGrid.collection.forEach(collection => {
				const eligibilityPayload: EligibilityPayload = new EligibilityPayload();
				eligibilityPayload.knockoutDependentID = collection.knockoutDependentID;
				eligibilityPayload.isYesResponse = null;
				this.payload.push(eligibilityPayload);
			});
		});
	}

	private buildGridList(): void {
		for (const property in this.eligibility) {
			if (this.eligibility.hasOwnProperty(property)) {
				if (property === 'showDisability' && this.eligibility[property]) {
					const gridItem = new EligibilityGrid();
					gridItem.title = this.gridTitles.disabilityTitle;
					gridItem.question = this.eligibility.disabilityQuestionForDisplay;
					gridItem.collection = this.eligibility.disabilityCollection;

					this.eligibilityGridList.push(gridItem);
				}
				if (property === 'showTitleXIX' && this.eligibility[property]) {
					const gridItem = new EligibilityGrid();
					gridItem.title = this.gridTitles.titleXIXTitle;
					gridItem.question = this.eligibility.titleXIXQuestionForDisplay;
					gridItem.collection = this.eligibility.titleXIXCollection;

					this.eligibilityGridList.push(gridItem);
				}
				if (property === 'showSpouseCoverage' && this.eligibility[property]) {
					const gridItem = new EligibilityGrid();
					gridItem.title = this.gridTitles.spouseTitle;
					gridItem.question = this.eligibility.spouseQuestionForDisplay;
					gridItem.collection = this.eligibility.spouseCoverageCollection;

					this.eligibilityGridList.push(gridItem);
				}
				if (property === 'showMedical' && this.eligibility[property]) {
					const gridItem = new EligibilityGrid();
					gridItem.title = this.gridTitles.medicalTitle;
					gridItem.question = this.eligibility.medicalQuestionForDisplay;
					gridItem.collection = this.eligibility.medicalCollection;

					this.eligibilityGridList.push(gridItem);
				}
			}
		}

		this.buildPayload();
	}

	private checkQuestions(): void {
		this.isComplete = this.payload.every(response => { return response.isYesResponse !== null; });
	}
}
