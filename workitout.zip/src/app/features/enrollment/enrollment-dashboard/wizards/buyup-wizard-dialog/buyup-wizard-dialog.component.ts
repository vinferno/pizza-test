import {
	ChangeDetectorRef,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
}                                  from '@angular/core';
import { FormBuilder }             from '@angular/forms';
import { Router }                  from '@angular/router';

import { Store }                   from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                  from 'rxjs';

import { animator }                from '../../../../../infrastructure/core/animations/animations';
import { ApiService }              from '../../../../../infrastructure/core/api/api.service';
import { EnrollmentBuyupService }  from '../../../../../infrastructure/enrollment/enrollment-buyup.service';
import { FormDialogBase }          from '../../../../../infrastructure/core/classes/form-wizard';
import { FormPersistentService }   from '../../../../../infrastructure/core/services/form-persistent.service';
import { IError }                  from '../../../../../infrastructure/interfaces/error';
import { SettingsState }           from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions } 		   from '../../../../../infrastructure/store/reducers/reducers-index';
import { StepperState } 		   from '../../../../../infrastructure/store/reducers/stepper/stepper-state';
import { EndingBenefit } 		   from '../../../../../infrastructure/store/reducers/ending-benefit/ending-benefit';

@Component({
	selector    : 'hg-buyup-wizard-dialog',
	templateUrl : './buyup-wizard-dialog.component.html',
	styleUrls   : ['./buyup-wizard-dialog.component.scss'],
	animations  : [animator.slide],
})
export class BuyupWizardDialogComponent extends FormDialogBase implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';
	public current = '';
	public steppers: StepperState;

	public errorMessage: IError = null;
	public formsInit = [
		{
			name: 'Available Benefits',
			fg: {
				uniqueID: '',
			},
		},
		{
			name: 'Benefit Plan Coverages',
			fg: {
				uniqueID: '',
			},
		},
		{
			name: 'Core Benefits',
			fg: { },
		},
		{
			name: 'Tobacco Usage',
			fg: { },
		},
		{
			name: 'Coverage Selection',
			fg: { },
		},
		{
			name: 'General Eligibility Questions',
			fg: { },
		},
		{
			name: 'Additional Info',
			fg: { },
		},
		{
			name: 'Primary Care Physician (PCP)',
			fg: { },
		},
		{
			name: 'Beneficiary',
			fg: { },
		},
		{
			name: 'Auto-Termination of Existing Coverage',
			fg: { },
		},
		{
			name: 'Domestic Partner Disclaimer',
			fg: { },
		},
		{
			name: 'Request Term',
			fg	: {},
		},
		{
			name: 'Disclaimer',
			fg: { },
		},
		{
			name: 'Summary',
			fg: { },
		},
		{
			name: 'Finalize',
			fg: { },
		},
	];
	public returnRoute: string = '/enrollment-dashboard';
	public minDate: Date;
	public maxDate: Date;
	public formWizardName: string = 'Add Benefit';
	public settings: SettingsState;
	public settingsState: Observable<SettingsState>;
	public subscriptions: Subscription[] = [];
	public endingBenefit: EndingBenefit;

	constructor(
		public api: ApiService,
		public fb: FormBuilder,
		public formService: FormPersistentService,
		public router: Router,
		public service: EnrollmentBuyupService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(formService, router, api, cd, store);
		this.alias = {
			Benefits         : 'Available Benefits',
			OptionalBenefits : 'Benefit Plan Coverages',
			CoreBenefits     : 'Core Benefits',
			Tobacco          : 'Tobacco Usage',
			Coverage         : 'Coverage Selection',
			Eligibility      : 'General Eligibility Questions',
			AdditionalInfo   : 'Additional Info',
			Pcp              : 'Primary Care Physician (PCP)',
			Beneficiary      : 'Beneficiary',
			AutoTerm         : 'Auto-Termination of Existing Coverage',
			DpDisclaimer     : 'Domestic Partner Disclaimer',
			Disclaimer       : 'Disclaimer',
			Summary          : 'Summary',
			Finalize         : 'Finalize',
			RequestTerm	  	 : 'Request Term',
		};
	}

	ngOnInit() {
		this.initializeState();
		super.ngOnInit();
		this.setErrorMessage();
		this.store.dispatch(stateActions.stepperActions.reset());
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Available Benefits', 'Buyup-Wizard-Dialog'));
		this.store.dispatch(stateActions.stepperActions.resetSecondary());
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => sub.unsubscribe());
		this.store.dispatch(stateActions.stepperActions.resetPrimary());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
		this.subscriptions.push(
			this.store.select('stepperState').subscribe( (steppers: StepperState) => {
				this.steppers = steppers;
				this.current = steppers.primaryStepper.slice(-1)[0];
			}),
		);
		this.subscriptions.push(
			this.store.select('endingBenefitState').subscribe( endingBenefit => {
				this.endingBenefit = endingBenefit;
			}),
		);
	}

	private setErrorMessage(): void {
		this.service.errorMessage$.subscribe((error) => {
			(error && error.error)
				? this.errorMessage = error.error
				: this.errorMessage = null;
		});
	}
}
