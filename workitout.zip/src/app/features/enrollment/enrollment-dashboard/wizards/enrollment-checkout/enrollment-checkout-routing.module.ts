import { CheckoutPCNADependentComponent }       from './checkout-forms/checkout-form-pcna-dependent/checkout-form-pcna-dependent.component';
import { CheckoutFormAutoEnrollComponent }      from './checkout-forms/checkout-form-auto-enroll/checkout-form-auto-enroll.component';
import { CheckoutFormCompleteComponent }        from './checkout-forms/checkout-form-complete/checkout-form-complete.component';
import { CheckoutFormDependentVerifyComponent } from './checkout-forms/checkout-form-dependent-verify/checkout-form-dependent-verify.component';
import { CheckoutFormDependentSSNComponent }    from './checkout-forms/checkout-form-dependent-ssn/checkout-form-dependent-ssn.component';
import { CheckoutFormFinalizeComponent }        from './checkout-forms/checkout-form-finalize/checkout-form-finalize.component';
import { CheckoutFormLiteratureComponent }      from './checkout-forms/checkout-form-literature/checkout-form-literature.component';
import { CheckoutForSmokerSurchargeComponent }  from './checkout-forms/checkout-form-smoker-surcharge/checkout-form-smoker-surcharge.component';
import { CheckoutFormSpouseExclusionComponent } from './checkout-forms/checkout-form-spouse-exclusion/checkout-form-spouse-exclusion.component';
import { CheckoutForSpouseSurchargeComponent }  from './checkout-forms/checkout-form-spouse-surcharge/checkout-form-spouse-surcharge.component';
import { CheckoutFormSummaryComponent }         from './checkout-forms/checkout-form-summary/checkout-form-summary.component';
import { CheckoutFormUSAePayComponent }         from './checkout-forms/checkout-form-usa-epay/checkout-form-usa-epay.component';
import { CheckoutFormYearRoundNoticeComponent } from './checkout-forms/checkout-form-year-round-notice/checkout-form-year-round-notice.component';
import { CheckoutFormIntroComponent }         from './checkout-forms/checkout-form-intro/checkout-form-intro.component';
import { CheckoutFormNewHireNoticeComponent } from './checkout-forms/checkout-form-new-hire-notice/checkout-form-new-hire-notice.component';
import { FormBeneficiariesComponent }         from './checkout-forms/form-beneficiaries/form-beneficiaries.component';

export const routedComponents = [
	CheckoutPCNADependentComponent,
	CheckoutFormAutoEnrollComponent,
	CheckoutFormCompleteComponent,
	CheckoutFormDependentVerifyComponent,
	CheckoutFormDependentSSNComponent,
	CheckoutFormFinalizeComponent,
	CheckoutFormLiteratureComponent,
	CheckoutForSmokerSurchargeComponent,
	CheckoutFormSpouseExclusionComponent,
	CheckoutForSpouseSurchargeComponent,
	CheckoutFormSummaryComponent,
	CheckoutFormUSAePayComponent,
	CheckoutFormYearRoundNoticeComponent,
	CheckoutFormNewHireNoticeComponent,
	CheckoutFormIntroComponent,
	FormBeneficiariesComponent,
];
