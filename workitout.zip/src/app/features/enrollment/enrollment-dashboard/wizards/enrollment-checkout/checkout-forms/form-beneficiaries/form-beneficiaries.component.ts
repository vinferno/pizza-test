import {
	ChangeDetectorRef,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                                    from '@angular/core';

import {
	Observable,
	Subscription,
}                                    from 'rxjs';
import { Store }                     from '@ngrx/store';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import {
	BenefitCardBeneficiariesForDisplay,
	BeneficiariesResponse,
	BeneficiaryPayload,
}                                    from '../../../../../../../infrastructure/interfaces/beneficiary';
import { BenefitSummary }            from 'app/infrastructure/interfaces/benefit';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { SettingsState }             from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector    : 'hg-form-beneficiaries',
	templateUrl : './form-beneficiaries.component.html',
	styleUrls   : ['./form-beneficiaries.component.scss'],
})
export class FormBeneficiariesComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;

	public beneficiariesList: BenefitCardBeneficiariesForDisplay[];
	public benefitSummary: BenefitSummary;
	public buttonLabel: string = 'Submit';
	public instructionHTML: string = '';
	public settingsState$: Observable<SettingsState>;
	public subscriptions: Subscription[] = [];

	constructor (
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	public ngOnInit(): void {
		this.initializeState();
		this.getBeneficiaries();
	}

	public ngOnDestroy(): void {
		this.cd.detach();
	}

	public postForm(payload: BeneficiaryPayload): void {
		this.service.setBeneficiaries(payload).subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'form-beneficiaries'));
		});
	}

	private initializeState(): void {
		this.settingsState$ = this.store.select('settingsState');
	}

	private getBeneficiaries(): void {
		this.service.getBeneficiaries().subscribe((beneficiariesResponse: BeneficiariesResponse) => {
			this.beneficiariesList = beneficiariesResponse.benefitBeneficiaryCards[0].beneficiariesForDisplay;
			this.benefitSummary = beneficiariesResponse.benefitBeneficiaryCards[0].genericBenefitSummaryModel;
			this.instructionHTML = beneficiariesResponse.instructionHTML;
			this.cd.detectChanges();
		});
	}
}
