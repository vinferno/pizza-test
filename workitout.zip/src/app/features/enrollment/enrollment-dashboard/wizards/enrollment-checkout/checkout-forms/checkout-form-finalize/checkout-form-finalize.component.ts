import {
	Component,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	AfterViewInit,
	OnInit,
	OnDestroy,
	ViewChildren,
	QueryList,
}                                    from '@angular/core';
import {
	AbstractControl,
	FormBuilder,
	FormControl,
	FormGroup,
	Validators,
}                                    from '@angular/forms';

import { Store }                     from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                    from 'rxjs';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import {
	CheckoutFinalize,
	ICheckoutOTPResponse,
}                                    from '../../../../../../../infrastructure/interfaces/checkout';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { MaskService }               from '../../../../../../../infrastructure/core/services/mask.service';
import { SessionState }              from '../../../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }             from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { SignatureFieldComponent }   from '../../../../../../../infrastructure/shared/controls/simple-controls/signature/signature-field.component';
import { stateActions }              from '../../../../../../../infrastructure/store/reducers/reducers-index';
import { ValidationEmail }           from '../../../../../../../infrastructure/core/validation/validation-email';
import { ValidationIsRequired }      from '../../../../../../../infrastructure/core/validation/validation-is-required';
import { ValidationPhone }           from '../../../../../../../infrastructure/core/validation/validation-phone';

@Component({
	selector        : 'hg-checkout-form-finalize',
	templateUrl     : './checkout-form-finalize.component.html',
	styleUrls       : ['./checkout-form-finalize.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormFinalizeComponent extends FormContentBase implements AfterViewInit, OnInit, OnDestroy {
	public signature: SignatureFieldComponent = new SignatureFieldComponent();
	public sigs: QueryList<SignatureFieldComponent>;

	@ViewChildren(SignatureFieldComponent) set list(signature: QueryList<SignatureFieldComponent>) { this.sigs = signature; }

	public agentVoiceSignatureInstructions: string = null;
	public buttonLabel: string = 'Submit';
	public checkoutFinalizeForm: FormGroup;
	public finalize: CheckoutFinalize = new CheckoutFinalize();
	public isFallback: boolean = false;
	public isSigUploaded: boolean = false;
	public otpForm: FormGroup;
	public otpComplete: boolean = false;
	public checkoutOTPResponse: ICheckoutOTPResponse;
	public session: SessionState;
	public sessionState: Observable<SessionState>;
	public settings: SettingsState;
	public settingsState: Observable<SettingsState>;
	public subscriptions: Subscription[] = [];
	public verifyOtpForm: FormGroup;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public fb: FormBuilder,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
		public mask: MaskService,
	) {
		super(api, cd, store);
		this.checkoutFinalizeForm = fb.group({
			signatureField1: new FormControl(),
		});
	}

	ngOnInit() {
		this.initializeState();
		this.getFinalize();
		this.store.dispatch(stateActions.formsActions.started(false));
		this.initializeForms();
		this.setUpConditionalValidators();

		if (this.session.agent) {
			this.agentVoiceSignatureInstructions = `I, ${this.session.agent.name}, agree that by entering my system password below I am certifying that I have supporting documentation and/or a voice recording that will corroborate that I have received authorization from ${this.session.selectedMember.memberName} to submit this enrollment session in its current state, I have verified their identity, I have verified their demographic information, I have reviewed all plans offered, and I have checked all benefits for accuracy. Entering my password below further acts as my electronic signature to be used on any applications generated from this process, and will complete the enrollment session for this employee.`
		}
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	ngAfterViewInit() {
		const sigsSubscription = this.sigs.changes.subscribe((sigs: QueryList <SignatureFieldComponent>) => {
			if (this.finalize && this.finalize.showSignature) {
				this.signature = sigs.first;
				this.beResponsive();
				this.setOptions();
				this.cd.detectChanges();
			}
		});

		this.subscriptions.push(sigsSubscription);
	}

	public saveConfirmation(): void {
		const payload = this.dataURItoBlob(this.signature.signature);
		this.service.uploadSignature(payload).subscribe(() => {
			this.isSigUploaded = true;
			this.setFinalize();
			this.cd.detectChanges();
		});
	}

	public setOtpCode(): void {
		const payload = { ...this.otpForm.value };
		this.service.getOtpCode(payload).subscribe(response => {
			this.verifyOtpForm.get('checkoutMethod').setValue(this.checkoutMethod.value);
			this.verifyOtpForm.get('userId').setValue(response.userId);
			this.checkoutOTPResponse = response;
			(response.isVerificationSent)
				? this.setUpVerification()
				: this.setUpFallbackVerification();
			this.cd.detectChanges();
		});
	}

	public verifyAgentPassword(): void {
		const payload = { ...this.otpForm.value };
		this.service.getOtpCode(payload).subscribe(() => {
			this.otpComplete = true;
			this.cd.detectChanges();
		});
	}

	public verifyExistingCode(): void {
		const payload = {
			checkoutMethod: this.checkoutMethod.value,
			code: this.otpForm.get('OTPCode').value,
		};
		this.verifyOtpCode(payload);
	}

	public verifyCode(): void {
		const payload = { ...this.verifyOtpForm.value };
		this.verifyOtpCode(payload);
	}

	public requiresRequestCode(): boolean {
		return this.checkoutMethod.value === 'AE' || this.checkoutMethod.value === 'AP' || this.checkoutMethod.value === 'AS';
	}

	public requestNewCode(): void {
		this.verifyOtpForm.get('userId').setValue('');
		this.cd.detectChanges();
	}

	public submitOtpComplete(): void {
		this.setFinalize();
	}

	public clearSignature(): void {
		this.signature.clear();
		this.cd.detectChanges();
	}

	public verifyByEmail(): void {
		this.checkoutMethod.setValue('AE');
		this.setOtpCode();
	}

	public return(): void {
		this.isFallback = false;
	}

	public get checkoutMethod(): AbstractControl {
		return this.otpForm.get('checkoutMethod');
	};

	private initializeState(): void {
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.sessionState.subscribe(session => {
			this.session = session;
			this.cd.detectChanges();
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private initializeForms(): void {
		this.otpForm = this.fb.group({
			checkoutMethod: ['', Validators.compose([Validators.required])],
			email: [''],
			phoneNumber: [''],
			OTPCode: [''],
			agentPassword: [''],
			callerID: [''],
		});

		this.verifyOtpForm = this.fb.group({
			checkoutMethod: [''],
			userId: ['', Validators.required],
			code: [''],
		});
	}

	private setUpConditionalValidators(): void {
		const otpFormSubscription = this.checkoutMethod.valueChanges.subscribe(value => {
			switch (value) {
				case 'AE':
					this.resetOtpFormControls();
					this.otpForm.get('email').setValidators([
						ValidationEmail.validEmail(true),
					]);
					this.otpForm.get('email').updateValueAndValidity();
					break;
				case 'AS':
					this.resetOtpFormControls();
					this.otpForm.get('phoneNumber').setValidators([
						ValidationPhone.validPhoneNumber(true),
					]);
					this.otpForm.get('phoneNumber').updateValueAndValidity();
					break;
				case 'AP':
					this.resetOtpFormControls();
					this.otpForm.get('phoneNumber').setValidators([
						ValidationPhone.validPhoneNumber(true),
					]);
					this.otpForm.get('phoneNumber').updateValueAndValidity();
					break;
				case 'AC':
					this.resetOtpFormControls();
					this.otpForm.get('OTPCode').setValidators([
						ValidationIsRequired.isRequired(),
					]);
					this.otpForm.get('OTPCode').updateValueAndValidity();
					break;
				case 'AN':
					this.resetOtpFormControls();
					this.otpForm.get('agentPassword').setValidators([
						ValidationIsRequired.isRequired('Password'),
					]);
					this.otpForm.get('agentPassword').updateValueAndValidity();
					this.otpForm.get('callerID').setValidators([]);
					this.otpForm.get('callerID').updateValueAndValidity();
					break;
			}
		});

		this.subscriptions.push(otpFormSubscription);
	}

	private resetOtpFormControls(): void {
		this.otpForm.get('email').setValidators([]);
		this.otpForm.get('email').updateValueAndValidity();
		this.otpForm.get('phoneNumber').setValidators([]);
		this.otpForm.get('phoneNumber').updateValueAndValidity();
		this.otpForm.get('OTPCode').setValidators([]);
		this.otpForm.get('OTPCode').updateValueAndValidity();
		this.otpForm.get('agentPassword').setValidators([]);
		this.otpForm.get('agentPassword').updateValueAndValidity();
		this.otpForm.get('callerID').setValidators([]);
		this.otpForm.get('callerID').updateValueAndValidity();
	}

	private beResponsive(): void {
		this.signature.signaturePad.set('canvasWidth', 700);
		this.signature.signaturePad.set('canvasHeight', 250);
	}

	private setOptions(): void {
		this.signature.signaturePad.set('backgroundColor', 'rgba(255,255,255, 0)');
		this.signature.signaturePad.clear();
	}

	private getFinalize(): void {
		this.service.getFinalize().subscribe(response => {
			this.finalize = response;
			if (response) {
				this.otpForm.get('phoneNumber').setValue(this.mask.phoneFormatInbound(response['memberPhone']));
				this.otpForm.get('email').setValue(response['homeEmail']);
			}
			this.cd.detectChanges();
		});
	}

	private verifyOtpCode(payload): void {
		this.service.verifyOtpCode(payload).subscribe(() => {
			this.otpComplete = true;
			this.cd.detectChanges();
		});
	}

	private dataURItoBlob(dataURI: string): Blob {
		const binary: string = atob(dataURI.split(',')[1]);
		const array: number[] = [];
		for (let i = 0; i < binary.length; i++) { array.push(binary.charCodeAt(i)); }

		return new Blob([new Uint8Array(array)], {type: 'image/png'});
	}

	private setFinalize(): void {
		this.service.setFinalize().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'CheckoutFormFinalize: setFinalize'));
		});
	}

	private setUpVerification(): void {
		this.isFallback = false;
	}

	private setUpFallbackVerification(): void {
		this.isFallback = true;
	}
}
