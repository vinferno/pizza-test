import {
	Component,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	HostBinding,
	OnDestroy,
	OnInit,
}                                      from '@angular/core';
import { FormBuilder }                 from '@angular/forms';
import { Router }                      from '@angular/router';

import { Store }                       from '@ngrx/store';

import { ApiService }                  from '../../../../../../infrastructure/core/api/api.service';
import { animator }                    from '../../../../../../infrastructure/core/animations/animations';
import { EnrollmentCategory }          from '../../../../../../infrastructure/interfaces/enrollment-category';
import { EnrollmentCheckoutService }   from '../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { EnrollmentWizardFormService } from '../../../../../../infrastructure/enrollment/enrollment-wizard-form.service';
import { FormDialogBase }              from '../../../../../../infrastructure/core/classes/form-wizard';
import { Form }                        from '../../../../../../infrastructure/interfaces/form';
import { FormPersistentService }       from '../../../../../../infrastructure/core/services/form-persistent.service';
import { StepperState } from '../../../../../../infrastructure/store/reducers/stepper/stepper-state';
import { stateActions } from '../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-enrollment-checkout-wizard-dialog',
	templateUrl     : './enrollment-checkout-wizard-dialog.component.html',
	styleUrls       : ['./enrollment-checkout-wizard-dialog.component.scss'],
	animations      : [animator.slide],
})
export class EnrollmentCheckoutWizardDialogComponent extends FormDialogBase implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	public formWizardName: string = 'Checkout';
	public isLoaded: boolean = false;
	public returnRoute: string = '/enrollment-dashboard';

	public formsInit: Form[] = [
		{
			name: 'Checkout Intro',
			fg: { },
		},
		{
			name: 'Dependent Affirmation',
			fg: { },
		},
		{
			name: 'Dependent SSN',
			fg: { },
		},
		{
			name: 'Dependent Verification',
			fg: { },
		},
		{
			name: 'USA ePay',
			fg: { },
		},
		{
			name: 'Required Disclosures',
			fg: { },
		},
		{
			name: 'Spouse Surcharge',
			fg: { },
		},
		{
			name: 'Spouse Exclusion',
			fg: { },
		},
		{
			name: 'Smoker Surcharge',
			fg: { },
		},
		{
			name: 'Additional Enrollment',
			fg: { },
		},
		{
			name: 'Notice',
			fg: { },
		},
		{
			name: 'Admin Event',
			fg: { },
		},
		{
			name: 'Beneficiaries',
			fg: { },
		},
		{
			name: 'Summary',
			fg: { },
		},
		{
			name: 'Finalize',
			fg: { },
		},
		{
			name: 'Enrollment Complete',
			fg: { },
		},
	];
	public requiredCategoryList;
	public enrollment;
	public enrollmentState;
	public settingsState;
	public settings;
	public shouldShowRequiredCategories: boolean = false;
	public subscriptions = [];
	public steppers: StepperState;
	public current = '';
	public ready = false;
	public start = 'Checkout Intro';

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public fb: FormBuilder,
		public formService: FormPersistentService,
		public router: Router,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
		public wizardFormService: EnrollmentWizardFormService,
	) {
		super(formService, router, api, cd, store);
		this.alias = {
			PolyConceptDependentAffirmation : 'Dependent Affirmation',
			DependentSSN                    : 'Dependent SSN',
			DependentVerify                 : 'Dependent Verification',
			USAePay                         : 'USA ePay',
			Documents                       : 'Required Disclosures',
			SpouseSurcharge                 : 'Spouse Surcharge',
			SpouseExclusion                 : 'Spouse Exclusion',
			SmokerSurcharge                 : 'Smoker Surcharge',
			AutoEnroll                      : 'Additional Enrollment',
			YearRoundNotice                 : 'Notice',
			AdminEvent                      : 'Admin Event',
			'Admin Event'                      : 'Admin Event',
			Beneficiaries                   : 'Beneficiaries',
			Summary                         : 'Summary',
			Finalize                        : 'Finalize',
			Complete                        : 'Enrollment Complete',
		};
	}

	ngOnInit() {
		super.ngOnInit();
		this.initializeState();
		this.isLoaded = true;
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Checkout Intro', 'Enrollment Checkout'));
		this.cd.detectChanges();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
		this.store.dispatch(stateActions.stepperActions.reset());
	}

	public trackById(index, item): number {
		return item.categoryID;
	}

	public selectNextRequired(): void {
		const category: EnrollmentCategory = this.requiredCategoryList[0];

		this.wizardFormService.selectCategory(category);
	}

	public selectCategory(category: EnrollmentCategory): void {
		this.wizardFormService.selectCategory(category);
	}

	private initializeState(): void {
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
			this.cd.detectChanges();
		});
		this.subscriptions.push(enrollmentSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(
			this.store.select('stepperState').subscribe( (steppers: StepperState) => {
				this.steppers = steppers;
				this.current = steppers.primaryStepper.slice(-1)[0];
				if (this.current === this.start) {
					this.ready = true;
				}
			}),
		);
		this.subscriptions.push(settingsSubscription);
		this.checkEnrollmentState();
	}

	private checkEnrollmentState(): void {
		if (!this.enrollment.companyCategories.isCheckoutEnabled) { this.buildRequiredCategoryList(); }

		this.cd.detectChanges();
	}

	private buildRequiredCategoryList() {
		this.shouldShowRequiredCategories = true;
		this.requiredCategoryList = this.enrollment.companyCategories.benefitCategories.filter(category => {
			return category.isRequired && !category.isCompleted;
		});
	}
}
