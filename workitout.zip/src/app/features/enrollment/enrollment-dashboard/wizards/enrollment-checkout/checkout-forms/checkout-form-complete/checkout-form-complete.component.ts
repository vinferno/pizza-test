import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { CheckoutComplete }          from '../../../../../../../infrastructure/interfaces/checkout';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';

@Component({
	selector        : 'hg-checkout-form-complete',
	templateUrl     : './checkout-form-complete.component.html',
	styleUrls       : ['./checkout-form-complete.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormCompleteComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public completed: CheckoutComplete;
	public isLoaded: boolean = false;
	public session;
	public sessionState;
	public settingsState;
	public settings;
	public subscriptions = [];

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.getComplete();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.settingsState.subscribe(session => {
			this.session = session;
			this.cd.detectChanges();
		});
		this.subscriptions.push(sessionSubscription);
	}

	private getComplete(): void {
		this.service.getComplete().subscribe(() => { this.isLoaded = true; });
	}
}
