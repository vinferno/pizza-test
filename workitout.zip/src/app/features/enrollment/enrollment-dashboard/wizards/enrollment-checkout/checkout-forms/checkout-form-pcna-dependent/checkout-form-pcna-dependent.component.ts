import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { DependentGridList }         from '../../../../../../../infrastructure/interfaces/dependent-grid';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { TableColumns }              from '../../../../../../../infrastructure/interfaces/table-columns';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-pcna-dependent',
	templateUrl     : './checkout-form-pcna-dependent.component.html',
	styleUrls       : ['./checkout-form-pcna-dependent.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutPCNADependentComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public dependentList: DependentGridList[] = new Array<DependentGridList>();
	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId: 'dependentName',
		},
		{
			columnName: 'SSN',
			columnId: 'dependentSsn',
		},
		{
			columnName: 'Date of Birth',
			columnId: 'dependentDateOfBirth',
		},
		{
			columnName: 'Age',
			columnId: 'dependentAge',
		},
		{
			columnName: 'Relationship',
			columnId: 'dependentRelationship',
		},
		{
			columnName: 'Gender',
			columnId: 'dependentGender',
		},
	];
	public isLoaded: boolean = false;
	public radioButtonChoices: string[] = [
		'I do not affirm',
		'I affirm',
	];
	public shouldContinue: boolean = false;
	public settings;
	public settingsState;
	public subscriptions = [];

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getDependentList();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public onValueChanged($event): void {
		$event.value === 'I affirm' ? this.shouldContinue = true : this.clearForm();
		this.cd.detectChanges();
	}

	public postForm(): void {
		this.service.setPCNADependents().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'PCNA'));
		});
	}

	private getDependentList(): void {
		this.service.getPCNADependents()
			.subscribe(dependentList => {
				this.dependentList = dependentList.dependents;
				this.isLoaded = true;
				this.cd.detectChanges();
		});
	}
}
