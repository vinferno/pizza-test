import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-new-hire-notice',
	templateUrl     : './checkout-form-new-hire-notice.component.html',
	styleUrls       : ['./checkout-form-new-hire-notice.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormNewHireNoticeComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public isLoaded: boolean = true;
	public agree = false;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			if (!this.cd['destroyed']) {
				this.cd.detectChanges();
			}
		});
		this.subscriptions.push(settingsSubscription);
		this.getNewHireNotice();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.service.setNewHireNotice().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary( response.nextPanel.value, 'New Hire'));
		});
	}

	private getNewHireNotice(): void {
		this.service.getNewHireNotice().subscribe(() => {
			this.isLoaded = true;
			if (!this.cd['destroyed']) {
				this.cd.detectChanges();
			}
		});
	}
}
