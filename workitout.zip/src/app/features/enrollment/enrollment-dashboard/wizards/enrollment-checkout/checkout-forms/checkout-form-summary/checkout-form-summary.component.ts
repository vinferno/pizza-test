import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                    from 'rxjs';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { BenefitSummaryList }        from '../../../../../../../infrastructure/interfaces/benefit';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { SettingsState }             from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-summary',
	templateUrl     : './checkout-form-summary.component.html',
	styleUrls       : ['./checkout-form-summary.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormSummaryComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public buttonLabel: string = 'Submit';
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];
	public summaryList: BenefitSummaryList;

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.getSummary();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public postForm(): void {
		this.service.setSummary().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'Summary'));
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
	}

	private getSummary(): void {
		this.service.getSummary().subscribe(summaryList => {
			this.summaryList = summaryList;
			this.cd.detectChanges();
		});
	}
}
