import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                                  from '@angular/core';
import { MatDialog } from "@angular/material/dialog";

import { Store }                                   from '@ngrx/store';

import { ApiService }                              from 'app/infrastructure/core/api/api.service';
import { DependentVerify }                         from 'app/infrastructure/interfaces/dependent-grid';
import { EnrollmentCheckoutService }               from 'app/infrastructure/enrollment/enrollment-checkout.service';
import { Form }                                    from 'app/infrastructure/interfaces/form';
import { FormContentBase }                         from 'app/infrastructure/core/classes/form-wizard';
import { ModalService }                            from 'app/infrastructure/core/services/modal.service';
import { TableColumns }                            from 'app/infrastructure/interfaces/table-columns';
import { UploadDependentDocumentsDialogComponent } from 'app/features/dependent-verification/upload-dependent-documents-dialog/upload-dependent-documents-dialog.component';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-dependent-verify',
	templateUrl     : './checkout-form-dependent-verify.component.html',
	styleUrls       : ['./checkout-form-dependent-verify.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormDependentVerifyComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public dependentList: DependentVerify[] = new Array<DependentVerify>();
	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId: 'dependentName',
		},
		{
			columnName: 'Relationship',
			columnId: 'dependentRelationship',
		},
		{
			columnName: 'Gender',
			columnId: 'dependentGender',
		},
	];
	public isLoaded: boolean = false;
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public dialog: MatDialog,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
		public modals: ModalService,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getDependentVerify();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public openDialog(dependent: DependentVerify): void {
		const dialogRef = this.dialog.open(UploadDependentDocumentsDialogComponent, { data: dependent });

		dialogRef.afterClosed()
			.subscribe(result => {
				this.getDependentVerify();
				this.cd.detectChanges();
			});
		this.modals.addModal(dialogRef);
	}

	public postForm(): void {
		this.service.setDependentVerify().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'checkout dependent-verify'));
		});
	}

	private getDependentVerify(): void {
		this.service.getDependentVerify().subscribe(dependentList => {
			this.dependentList = dependentList.dependents;
			this.isLoaded = true;
			this.cd.detectChanges();
		});
	}
}
