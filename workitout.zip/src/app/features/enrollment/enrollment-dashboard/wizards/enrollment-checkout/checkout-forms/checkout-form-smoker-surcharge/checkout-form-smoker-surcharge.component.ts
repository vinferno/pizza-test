import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';
import { Observable, Subscription }  from 'rxjs';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { CheckoutSurcharge }         from '../../../../../../../infrastructure/interfaces/checkout';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { SettingsState }             from 'app/infrastructure/store/reducers/settings/settings-state';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-smoker-surcharge',
	templateUrl     : './checkout-form-smoker-surcharge.component.html',
	styleUrls       : ['./checkout-form-smoker-surcharge.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutForSmokerSurchargeComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;
	public smokerCoverage: CheckoutSurcharge;
	public isLoaded: boolean = false;
	public radioButtonChoices: string[] = [];
	public payload: number;
	public subscriptions: Subscription[] = [];
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.getSmokerSurcharge();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public onValueChanged(event: any): void {
		this.smokerCoverage.coverageDetails.forEach((item, index) => {
			if (item.alternateDescription === event.value) { this.payload = this.smokerCoverage.coverageDetails[index].coverageID; }
		});
		this.cd.detectChanges();
	}

	public postForm(): void {
		this.service.setSmokerSurcharge(this.payload).subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'Smoker'));
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private getSmokerSurcharge(): void {
		this.service.getSmokerSurcharge().subscribe(response => {
			this.smokerCoverage = response;
			this.buildButtonGroup();
			this.isLoaded = true;
			this.cd.detectChanges();
		});
	}

	private buildButtonGroup(): void {
		this.smokerCoverage.coverageDetails.forEach(coverageDetail => { this.radioButtonChoices.push(coverageDetail.alternateDescription); });
	}
}
