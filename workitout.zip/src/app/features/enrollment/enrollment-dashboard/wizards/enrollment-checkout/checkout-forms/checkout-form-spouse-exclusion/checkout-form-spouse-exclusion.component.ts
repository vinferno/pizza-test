import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import {
	SpouseExclusion,
	SpouseExclusionMemberBenefit,
	SpouseExclusionPayload,
}                                    from '../../../../../../../infrastructure/interfaces/spouse-exclusion';
import { TableColumns }              from '../../../../../../../infrastructure/interfaces/table-columns';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-spouse-exclusion',
	templateUrl     : './checkout-form-spouse-exclusion.component.html',
	styleUrls       : ['./checkout-form-spouse-exclusion.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormSpouseExclusionComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public columnList: TableColumns[] = [
		{
			columnName: 'Benefit Name',
			columnId: 'benefitName',
		},
		{
			columnName: 'Effective On',
			columnId: 'effectiveOn',
		},
	];
	public isComplete: boolean = false;
	public isLoaded: boolean = false;
	public payload: SpouseExclusionPayload[] = new Array<SpouseExclusionPayload>();
	public radioButtonChoices: string[] = [
		'Yes',
		'No',
	];
	public spouseExclusion: SpouseExclusion = new SpouseExclusion();
	public terminateSpouseOptions = [
		{
			label : 'Yes',
			value : 'Y',
		},
		{
			label : 'No',
			value : 'N',
		},
	];

	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getSpousalExclusion();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public selectRadioOption(event: any, cell: SpouseExclusionMemberBenefit): SpouseExclusionMemberBenefit {
		this.payload.forEach(memberBenefit => {
			if (memberBenefit.memberBenefitID === cell.memberBenefitID) { memberBenefit.terminateSpouse = this.setTerminateSpouseValue(event.value); }
		});

		this.checkExclusions();
		this.cd.detectChanges();

		return cell;
	}

	public postForm(): void {
		this.service.setSpousalExclusion(this.payload).subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'Spouse'));
		});
	}

	private getSpousalExclusion(): void {
		this.service.getSpousalExclusion().subscribe(response => {
				this.spouseExclusion = response;
				this.isLoaded = true;
				this.buildPayload();
				this.cd.detectChanges();
		});
	}

	private buildPayload(): void {
		this.spouseExclusion.memberBenefits.forEach(memberBenefit => {
			const payloadItem: SpouseExclusionPayload = new SpouseExclusionPayload();
			payloadItem.memberBenefitID = memberBenefit.memberBenefitID;
			payloadItem.terminateSpouse = null;
			this.payload.push(payloadItem);
		});
	}

	private setTerminateSpouseValue(value: string): string {
		this.terminateSpouseOptions.forEach(option => {
			if (option.label === value) { value = option.value; }
		});

		return value;
	}

	private checkExclusions(): void {
		this.isComplete = this.payload.every(response => { return response.terminateSpouse !== null; });
	}
}
