import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                    from 'rxjs';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { Constants }                 from '../../../../../../../infrastructure/utils/constants';
import {
	DependentGridList,
	DependentSSNList,
	DependentSSN,
}                                    from '../../../../../../../infrastructure/interfaces/dependent-grid';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { IError }                    from '../../../../../../../infrastructure/interfaces/error';
import { SettingsState }             from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }              from '../../../../../../../infrastructure/interfaces/table-columns';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-dependent-ssn',
	templateUrl     : './checkout-form-dependent-ssn.component.html',
	styleUrls       : ['./checkout-form-dependent-ssn.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormDependentSSNComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input() public form: Form;

	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId: 'dependentName',
		},
		{
			columnName: 'Relationship',
			columnId: 'dependentRelationship',
		},
	];
	public dependentPayload: DependentSSNList = new DependentSSNList();
	public dependentList: DependentGridList[] = new Array<DependentGridList>();
	public isComplete: boolean = true;
	public isLoaded: boolean = false;
	public isPostInvalid: boolean = false;
	public ssnRules = {
		ssnPattern: Constants.patterns.FULL_SSN_REGEX_FORMATTED,
	};
	public postError: IError = new IError();
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		private service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.getDependentSSN();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public saveDependentSSNList(): void {
		this.isPostInvalid = false;
		this.dependentList.forEach(dependent => this.finalizePayload(dependent));
		this.service.setDependentSSN(this.dependentPayload).subscribe(response => {
				this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'DependentSsn'));
		},
		error => {
			this.postError = error;
			this.isPostInvalid = true;
			this.cd.detectChanges();
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private getDependentSSN(): void {
		this.service.getDependentSSN().subscribe(dependentList => {
			this.dependentList = dependentList.dependents;
			this.preparePayload();
			this.isLoaded = true;
			this.cd.detectChanges();
		});
	}

	private preparePayload(): void {
		this.dependentList.forEach(dependent => this.buildDependentSSN(dependent));
	}

	private buildDependentSSN(dependent: DependentGridList): void {
		const dependentSSN = new DependentSSN();

		dependentSSN.dependentID = dependent.dependentID;
		dependentSSN.ssn = dependent.dependentSsn;
		if (dependent.dependentRelationship === 'Spouse' || dependent.dependentRelationship === 'Domestic Partner') { this.setIsComplete(false); }
		if ((dependent.dependentRelationship === 'Spouse' || dependent.dependentRelationship === 'Domestic Partner') && dependent.dependentSsn) { this.setIsComplete(true); }
		this.dependentPayload.checkoutDependents.push(dependentSSN);
	}

	private finalizePayload(dependent: DependentGridList): void {
		this.dependentPayload.checkoutDependents.forEach(dependentSSN => {
			if (dependentSSN.dependentID === dependent.dependentID) {
				dependentSSN.dependentID = dependent.dependentID;
				dependentSSN.ssn = dependent.dependentSsn.replace(Constants.patterns.NON_DECIMAL_DIGITS, '');
			}
		});
	}

	private setIsComplete(value: boolean): boolean {
		return this.isComplete = value;
	}
}
