import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                        from '@angular/core';

import { Store }                         from '@ngrx/store';

import { ApiService }                    from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCheckoutService }     from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                          from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }               from '../../../../../../../infrastructure/core/classes/form-wizard';
import { ResourceLink }                  from '../../../../../../../infrastructure/interfaces/resource-link';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-literature',
	templateUrl     : './checkout-form-literature.component.html',
	styleUrls       : ['./checkout-form-literature.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormLiteratureComponent extends FormContentBase implements OnDestroy, OnInit {
	@Input()
	public form: Form;
	public agree: boolean = false;
	public documents: ResourceLink[] = new Array<ResourceLink>();
	public isLoaded: boolean = false;
	public settingsState;
	public settings;
	public subscriptions = [];

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getDocuments();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public toggleCheckbox(event: any): void {
		this.agree = event.value;
	}

	public postForm(): void {
		this.service.setDocuments().subscribe(response => {
			if (response.nextPanel.value === 'Documents') { return this.getDocuments(); }
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'Checkout-Literature'));
		});
	}

	private getDocuments(): void {
		this.service.getDocuments().subscribe(documents => {
				this.documents = documents.documents;
				this.isLoaded = true;
				this.cd.detectChanges();
		});
	}
}
