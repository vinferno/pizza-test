import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';

import { Store }                     from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                    from 'rxjs';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { CheckoutYearRound }         from '../../../../../../../infrastructure/interfaces/checkout';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }           from '../../../../../../../infrastructure/core/classes/form-wizard';
import { LifeEvent }                 from '../../../../../../../infrastructure/interfaces/life-events';
import { MyProfileService }          from '../../../../../../../infrastructure/core/services/myprofile.service';
import { SettingsState }             from '../../../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-year-round-notice',
	templateUrl     : './checkout-form-year-round-notice.component.html',
	styleUrls       : ['./checkout-form-year-round-notice.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormYearRoundNoticeComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;

	public lifeEventInstructions: string = `<p>Qualifying Life Events (QLE) allow you to make changes to certain benefit elections outside of annual open enrollment periods. If you have experienced a QLE, you may upload proper documentation of the event for review. If you uploaded documentation during a QLE enrollment session, you do not need to upload your documentation again. Examples of acceptable QLE documents include: birth certificates, marriage certificates, adoption documentation, loss or gain of coverage documents, etc.</p><p>Your Employer will review all uploaded documentation and complete the verification process. For questions regarding what documents are considered acceptable, please contact your HR department.</p>`;
	public lifeEventList: LifeEvent[] = [];
	public requiredDocumentList: string[] = [
		'Birth Certificates',
		'Finalized Adoption Paperwork',
		'Marriage Certificates',
		'Loss of Other Coverage Paperwork',
		'Death Certificate',
	];
	public settings: SettingsState;
	public subscriptions: Subscription[] = [];
	public yearRoundNotice: CheckoutYearRound;

	private settingsState: Observable<SettingsState>;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		private myProfileService: MyProfileService,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getYearroundNotice();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.service.setYearroundNotice().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'yearround'));
		});
	}

	private getYearroundNotice(): void {
		this.service.getYearroundNotice().subscribe(response => {
			this.yearRoundNotice = response;
			if (response.showQualifyingEventUpload) { this.buildTable(); }
			this.cd.detectChanges();
		});
	}

	private buildTable(): void {
		this.myProfileService.getMemberDocumentsQualifyingEvents().subscribe(response => {
			this.lifeEventList = response;
			this.cd.detectChanges();
		});
	}
}
