import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
}                                    from '@angular/core';
import {
	FormBuilder,
	FormGroup,
	Validators,
}                                    from '@angular/forms';

import { Store }                     from '@ngrx/store';

import { ApiService }                from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                      from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }          from '../../../../../../../infrastructure/core/classes/form-wizard';
import { IError }                   from '../../../../../../../infrastructure/interfaces/error';
import { USAePay, USAePayPayload }  from '../../../../../../../infrastructure/interfaces/usa-epay';
import { ValidationService }        from '../../../../../../../infrastructure/core/validation/validation.service';
import { ValidationZipcode }        from '../../../../../../../infrastructure/core/validation/validation-zipcode';
import { MaskService }              from '../../../../../../../infrastructure/core/services/mask.service';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-usa-epay',
	templateUrl     : './checkout-form-usa-epay.component.html',
	styleUrls       : ['./checkout-form-usa-epay.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormUSAePayComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;

	public cardDetailForm: FormGroup;
	public ePayForm: FormGroup;
	public getResponse: USAePay = new USAePay();
	public isLoaded: boolean = false;
	public isPostInvalid: boolean = false;
	public payload: USAePayPayload = new USAePayPayload();
	public postError: IError = new IError();
	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		private fb: FormBuilder,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
		private valid: ValidationService,
		public maskService: MaskService,
	) {
		super(api, cd, store);
		this.buildCardForm();
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getUSAePay();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.buildPayload();
		this.isPostInvalid = false;

		this.service.setUSAePay(this.payload).subscribe(response => {
				this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'Usa'));
		},
		error => {
			this.postError = error;
			this.isPostInvalid = true;
			this.cd.detectChanges();
		});
	}

	public toggleCheckbox(event: any): void {
		this.payload.sendReceipt = event.value;
		this.cd.detectChanges();
	}

	private getUSAePay(): void {
		this.service.getUSAePay().subscribe(response => {
			this.getResponse = response;
			this.buildEPayForm(this.getResponse);
			this.isLoaded = true;
			this.cd.detectChanges();
		});
	}

	private buildEPayForm(response: USAePay): void {
		this.ePayForm = this.fb.group({
			firstName: [response.firstName, Validators.compose([Validators.required])],
			lastName: [response.lastName, Validators.compose([Validators.required])],
			homeAddressLine1: [response.homeAddressLine1, Validators.compose([Validators.required])],
			homeAddressLine2: [response.homeAddressLine2, Validators.compose([])],
			homeCity: [response.homeCity, Validators.compose([Validators.required])],
			homeState: [response.homeState, Validators.compose([Validators.required])],
			homeZipCode: [response.homeZipCode, Validators.compose([ValidationZipcode.validZipcode(true)])],
			homeEmail: [response.homeEmail],
		});
	}

	private buildCardForm(): void {
		this.cardDetailForm = this.fb.group({
			cardNumber     : ['', Validators.compose([this.valid.numeric.numbersOnly, Validators.required])],
			cardExpiration : ['', Validators.compose([ Validators.required])],
		});
	}

	private buildPayload(): void {
		for (const property in this.payload) {
			if (this.payload.hasOwnProperty(property)) {
				if (this.ePayForm.controls[property]) { this.payload[property] = this.ePayForm.controls[property].value; }
				if (this.cardDetailForm.controls[property]) { this.payload[property] = this.cardDetailForm.controls[property].value; }
				if (property === 'cardExpiration') {
					this.payload[property] = this.cardDetailForm.controls[property].value.replace(/[^0-9]+/g, '').substring(0, 4);
				}
			}
		}
	}

	public maskExp(event) {
		const original = event.target.value;
		const justNumbers = original.replace(/[^0-9/]+/g, '');
		const split = justNumbers.split('');
		if (split.length > 2 && split[2] !== '/') {
			split.splice(2, 0, '/');
		}

		event.target.value = split.join('').substring(0, 5);
		this.cd.detectChanges();
	}
}
