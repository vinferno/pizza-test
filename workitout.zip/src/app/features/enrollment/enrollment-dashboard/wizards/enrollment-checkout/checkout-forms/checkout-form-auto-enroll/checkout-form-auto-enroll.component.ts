import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
} from '@angular/core';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../../../infrastructure/core/api/api.service';
import { CheckoutAutoEnroll } from '../../../../../../../infrastructure/interfaces/checkout';
import { Constants } from '../../../../../../../infrastructure/utils/constants';
import { EnrollmentCheckoutService } from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form } from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase } from '../../../../../../../infrastructure/core/classes/form-wizard';
import { TableColumns } from '../../../../../../../infrastructure/interfaces/table-columns';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector: 'hg-checkout-form-auto-enroll',
	templateUrl: './checkout-form-auto-enroll.component.html',
	styleUrls: ['./checkout-form-auto-enroll.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormAutoEnrollComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	public currencyFormat = Constants.currencyFormat;
	public enrollmentSummary: CheckoutAutoEnroll = new CheckoutAutoEnroll();
	public isLoaded: boolean = false;
	public columnList: TableColumns[] = [
		{
			columnName: 'Benefit',
			columnId: 'benefit',
		},
		{
			columnName: 'Tier',
			columnId: 'tier',
		},
		{
			columnName: 'Frequency',
			columnId: 'frequency',
		},
		{
			columnName: 'Summary',
			columnId: 'summary',
		},
	];

	public subscriptions = [];
	public settingsState;
	public settings;

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.getAutoEnroll();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.service.setAutoEnroll().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(response.nextPanel.value, 'Checkout-auto-enroll'))
		});
	}

	private getAutoEnroll(): void {
		this.service.getAutoEnroll().subscribe(response => {
			this.enrollmentSummary = response;
			this.isLoaded = true;
			this.cd.detectChanges();
		});
	}
}
