import {
	Component,
	Input,
	OnInit,
	OnDestroy,
	ChangeDetectorRef,
	ChangeDetectionStrategy, EventEmitter, Output,
} from '@angular/core';

import { BehaviorSubject }             from 'rxjs';
import { Store }                       from '@ngrx/store';

import { ApiService }                  from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentCheckoutService }   from '../../../../../../../infrastructure/enrollment/enrollment-checkout.service';
import { Form }                        from '../../../../../../../infrastructure/interfaces/form';
import { FormContentBase }             from '../../../../../../../infrastructure/core/classes/form-wizard';
import { NextPanelValue }              from '../../../../../../../infrastructure/interfaces/next-panel';
import { stateActions } from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-form-intro',
	templateUrl     : './checkout-form-intro.component.html',
	styleUrls       : ['./checkout-form-intro.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutFormIntroComponent extends FormContentBase implements OnInit, OnDestroy {
	@Input()
	public form: Form;
	@Input() public alias;
	public isLoaded: boolean = false;
	public settings;
	public settingsState;
	public subscriptions = [];
	public nextPanelSource = new BehaviorSubject(null);
	public nextPanel: NextPanelValue;
	@Output() public emitNextPanel: EventEmitter<any> = new EventEmitter();

	constructor(
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit() {
		this.initializeState();
		this.initializeCheckout();
		this.cd.detectChanges();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.isLoaded = true;
	}

	public postForm(): void {
		if (!this.nextPanel) { return; }
		this.store.dispatch(stateActions.stepperActions.updatePrimary(this.alias[this.nextPanel.value], 'Checkout Intro'));
	}

	private initializeCheckout(): void {
		this.subscriptions.push(
			this.service.initialize().subscribe(response => {
				this.nextPanel = response.nextPanel;
				this.isLoaded = true;
				this.emitNextPanel.emit(response.nextPanel.value);
				if (!this.cd['destroyed']) {
					this.cd.detectChanges();
				}
			}),
		);
	}
}
