import { Component, OnDestroy, OnInit, ChangeDetectorRef, HostBinding } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

import { Store } from '@ngrx/store';

import { ApiService } from '../../../../../infrastructure/core/api/api.service';
import { EnrollmentCancelService } from '../../../../../infrastructure/enrollment/enrollment-cancel.service';
import { FormDialogBase } from '../../../../../infrastructure/core/classes/form-wizard';
import { Form } from '../../../../../infrastructure/interfaces/form';
import { FormPersistentService } from '../../../../../infrastructure/core/services/form-persistent.service';
import { animator } from '../../../../../infrastructure/core/animations/animations';
import { StepperState } from '../../../../../infrastructure/store/reducers/stepper/stepper-state';
import { stateActions } from '../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector: 'hg-cancel-wizard-dialog',
	templateUrl: './cancel-wizard-dialog.component.html',
	styleUrls: ['./cancel-wizard-dialog.component.scss'],
	animations: [animator.slide],
})
export class CancelWizardDialogComponent extends FormDialogBase implements OnDestroy, OnInit {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public formWizardName: string = 'Cancel Request';
	public isLoaded: boolean = false;
	public formsInit: Form[] = [
		{
			name: 'Requests to Terminate',
			fg: {},
		},
		{
			name: 'Summary',
			fg: {},
		},
		{
			name: 'Finalize',
			fg: {},
		},
	];
	public settings;
	public settingsState;
	public subscriptions = [];
	public steppers: StepperState;
	public current = '';

	constructor(
		public api: ApiService,
		public service: EnrollmentCancelService,
		public fb: FormBuilder,
		public formService: FormPersistentService,
		public router: Router,
		public store: Store<any>,
		public cd: ChangeDetectorRef,
	) {
		super(formService, router, api, cd, store);
		this.alias = {
			Requests: 'Requests to Terminate',
			Summary: 'Summary',
			Finalize: 'Finalize',
		};
	}

	ngOnInit() {
		super.ngOnInit();
		this.initializeState();
		this.initializeWizard();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
		this.store.dispatch(stateActions.stepperActions.reset());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
		this.subscriptions.push(
			this.store.select('stepperState').subscribe( (steppers: StepperState) => {
				this.steppers = steppers;
				this.current = steppers.primaryStepper.slice(-1)[0];
			}),
		);
	}

	private initializeWizard(): void {
		this.store.dispatch(stateActions.stepperActions.reset());
		this.service.initialize().subscribe(response => {
			this.store.dispatch(stateActions.stepperActions.updatePrimary(this.alias[response.nextPanel.value], 'Cancel Wizard'));
			this.isLoaded = true;
		});
	}
}
