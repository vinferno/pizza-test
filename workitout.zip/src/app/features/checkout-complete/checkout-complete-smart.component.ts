import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
}                                    from '@angular/core';
import { FormGroup, FormBuilder }    from '@angular/forms';
import { Router }                    from '@angular/router';

import { Store }                     from '@ngrx/store';
import { Observable }                from 'rxjs';

import { EnrollmentCheckoutService } from '../../infrastructure/enrollment/enrollment-checkout.service';
import { ICheckoutState }            from 'app/infrastructure/store/reducers/checkout/checkout-state';
import { IEnrollmentModeSelection }  from '../../infrastructure/interfaces/enroll-mode-selection';
import { SettingsState }             from 'app/infrastructure/store/reducers/settings/settings-state';
import { stateActions }              from '../../infrastructure/store/reducers/reducers-index';

@Component({
	selector        : 'hg-checkout-complete',
	templateUrl     : './checkout-complete-smart.component.html',
	styleUrls       : ['./checkout-complete-smart.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutCompleteSmartComponent implements OnInit {
	public checkoutCompleteForm: FormGroup;
	public checkoutState$: Observable<ICheckoutState>;
	public selectedEnrollment: IEnrollmentModeSelection;
	public noEnrollment: string = 'RETURN TO DASHBOARD';
	public openEnrollment: string = 'OPENENROLLMENT';
	public settingsState$: Observable<SettingsState>;

	constructor(
		private fb: FormBuilder,
		private router: Router,
		public service: EnrollmentCheckoutService,
		public store: Store<any>,
	) {
		this.checkoutCompleteForm = fb.group({
			mode: [''],
		});
	}

	ngOnInit() {
		this.initializeState();
	}

	public postForm(mode: string): void {
		this.service.setComplete(mode).subscribe(() => this.reloadMembership(mode));
	}

	public selectEnrollment(enrollment: IEnrollmentModeSelection): void {
		(this.checkoutCompleteForm.get('mode').value === enrollment.mode)
			? this.checkoutCompleteForm.get('mode').setValue(null)
			: this.checkoutCompleteForm.get('mode').setValue(enrollment.mode);
			this.selectedEnrollment = enrollment;
	}

	private initializeState(): void {
		this.checkoutState$ = this.store.select('checkoutState');
		this.settingsState$ = this.store.select('settingsState');
	}

	private reloadMembership(mode: string): void {
		if (mode === this.noEnrollment) { this.router.navigate(['/dashboard']); }
		if (mode === this.openEnrollment) {
			this.router.navigate(['/enrollment-dashboard']);
			this.store.dispatch(stateActions.sessionActions.updateIsEnrollmentReady({isEnrollmentReady: true}));
		}
	}
}
