import {
	Component,
	ChangeDetectionStrategy,
	EventEmitter,
	Input,
	Output,
}                                    from '@angular/core';
import { FormGroup }                 from '@angular/forms';

import { ICheckoutState }            from 'app/infrastructure/store/reducers/checkout/checkout-state';
import { IEnrollmentModeSelection }  from '../../infrastructure/interfaces/enroll-mode-selection';
import { SettingsState }             from 'app/infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-checkout-complete-presentation',
	templateUrl     : './checkout-complete-presentation.component.html',
	styleUrls       : ['./checkout-complete-presentation.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CheckoutCompletePresentationComponent {
	@Input() public checkoutCompleteForm: FormGroup;
	@Input() public noEnrollment: string = 'RETURN TO DASHBOARD';
	@Input() public openEnrollment: string = 'OPENENROLLMENT';
	@Input() public selectedEnrollment: IEnrollmentModeSelection;
	@Input() public checkout: ICheckoutState;
	@Input() public settings: SettingsState;

	@Output() public emitPostForm = new EventEmitter<string>();
	@Output() public emitSelectEnrollment = new EventEmitter<IEnrollmentModeSelection>();

	public postForm(mode: string): void {
		this.emitPostForm.emit(mode);
	}

	public selectEnrollment(enrollment: IEnrollmentModeSelection): void {
		this.emitSelectEnrollment.emit(enrollment);
	}
}
