import { Injectable }        from '@angular/core';
import {
	ActivatedRouteSnapshot,
	CanActivate,
	CanActivateChild,
	Router,
	RouterStateSnapshot,
}                            from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { Store }             from '@ngrx/store';
import {
	Observable,
	of as observableOf,
}                            from 'rxjs';
import {
	catchError,
	map,
	take,
}                            from 'rxjs/operators';

import { AuthService }       from 'app/infrastructure/auth/auth.service';
import { SessionState }      from 'app/infrastructure/store/reducers/session/session-state';


@Injectable()
export class AgentDashboardGuard implements CanActivate, CanActivateChild {
	constructor(
		private authService: AuthService,
		private router: Router,
		private store: Store<SessionState>,
	) { }

	public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
		return this.store.select('sessionState').pipe(
			map((session: SessionState) => (session.agent && session.agent.name && this.checkValidation()) ? true : false),
			take(1),
		);
	}

	public canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
		return this.canActivate(route, state);
	}

	private checkValidation(): Observable<boolean> {
		return this.authService.validate().pipe(
			map(() => true),
			catchError((error: HttpErrorResponse) => {
				this.router.navigateByUrl('/');
				return observableOf(false);
			}),
		);
	}
}
