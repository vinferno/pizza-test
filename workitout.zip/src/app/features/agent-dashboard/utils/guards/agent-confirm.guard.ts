import { Injectable }             from '@angular/core';
import { FormGroup }              from '@angular/forms';
import {
	ActivatedRouteSnapshot,
	CanActivate,
	Router,
	RouterStateSnapshot,
}                                 from '@angular/router';

import {
	Observable,
	of as observableOf,
}                                 from 'rxjs';

import { AgentsDashboardService } from '../agent-dashboard.service';
import { AgentSearchResult }      from 'app/infrastructure/interfaces/agent';


@Injectable()
export class AgentConfirmGuard implements CanActivate {
	constructor(
		private agentDashboardService: AgentsDashboardService,
		private router: Router,
	) { }

	public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
		const agentDashboardForm = this.agentDashboardService.agentDashboardForm;
		const selectedMember: AgentSearchResult =  agentDashboardForm.value.selectedMember;
		const emailForm = agentDashboardForm.get('emailForm') as FormGroup;
		if (!selectedMember || !emailForm) {
			this.router.navigateByUrl('/counselor/dashboard');
			return observableOf(false);
		} else {
			emailForm.controls.email.setValue(selectedMember.homeEmail);
			return observableOf(true);
		}
	}
}
