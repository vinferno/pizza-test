import { resolverList as agentDashboardResolvers } from './agent-dashboard/agent-dashboard-resolvers';

export const resolvers = [
	agentDashboardResolvers,
];
