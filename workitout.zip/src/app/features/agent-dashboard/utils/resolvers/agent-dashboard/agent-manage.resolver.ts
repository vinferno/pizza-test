import { Injectable }              from '@angular/core';
import {
	ActivatedRouteSnapshot,
	Resolve,
	RouterStateSnapshot,
}                                  from '@angular/router';

import { Observable }              from 'rxjs';
import { map, take }               from 'rxjs/operators';

import { AgentCompanyCallLogList } from '../../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService }        from '../../agents-crm.service';

@Injectable()
export class AgentManageResolver implements Resolve<AgentCompanyCallLogList> {
	constructor(
		private agentsCRMService: AgentsCRMService,
	) { }

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<AgentCompanyCallLogList> {
		return this.agentsCRMService.getCallLog().pipe(
			take(1),
			map(callLog => callLog),
		);
	}
}
