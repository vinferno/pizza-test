import { Injectable }        from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import {
	ActivatedRouteSnapshot,
	Resolve,
	Router,
	RouterStateSnapshot,
}                            from '@angular/router';

import {
	Observable,
	throwError as observableThrowError,
}                            from 'rxjs';
import {
	catchError,
	map,
	take,
}                            from 'rxjs/operators';
import { Store }             from '@ngrx/store';

import { AgentsCRMService }  from '../../agents-crm.service';
import {
	MemberActivityLog,
	MemberActivityLogID,
}                            from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }      from '../../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class MemberActivityLogDetailResolver implements Resolve<MemberActivityLog> {
	public session: SessionState;

	constructor(
		private agentsCRMService: AgentsCRMService,
		private router: Router,
		private store: Store<any>,
	) {
		this.initializeState();
	}

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<MemberActivityLog> {
		let payload: MemberActivityLogID;
		(this.session && this.session.agent && this.session.agent.memberActivityLog)
			? payload = { memberActivityLogID: this.session.agent.memberActivityLog.activityLogID }
			: payload = new MemberActivityLogID();

		return this.agentsCRMService.getActivityLogByID(payload).pipe(
			take(1),
			map(memberActivityLog => memberActivityLog),
			catchError((error: HttpErrorResponse) => {
				this.navigateOnFail();
				return observableThrowError(error);
			}),
		);
	}

	private initializeState(): void {
		this.store.select('sessionState').subscribe(session => { this.session = session; });
	}

	private navigateOnFail(): void {
		this.router.navigate(['counselor/customer-relations/member-activity-log']);
	}
}
