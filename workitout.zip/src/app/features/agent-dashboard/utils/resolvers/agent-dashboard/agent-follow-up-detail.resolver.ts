import { Injectable }        from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import {
	ActivatedRouteSnapshot,
	Resolve,
	Router,
	RouterStateSnapshot,
}                            from '@angular/router';

import {
	Observable,
	throwError as observableThrowError,
}                           from 'rxjs';
import {
	catchError,
	map,
	take,
}                           from 'rxjs/operators';
import { Store }             from '@ngrx/store';

import { AgentsCRMService }  from '../../agents-crm.service';
import { Constants }         from '../../../../../infrastructure/utils/constants';
import { ScheduledEvent }    from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }      from '../../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class AgentFollowUpDetailResolver implements Resolve<ScheduledEvent> {
	public session: SessionState;

	constructor(
		private agentsCRMService: AgentsCRMService,
		private router: Router,
		private store: Store<any>,
	) {
		this.initializeState();
	}

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<ScheduledEvent> {
		if (this.session && this.session.agent && this.session.agent.scheduledEvent) {
			return this.agentsCRMService.getScheduledEventByID({scheduledEventID: this.session.agent.scheduledEvent.scheduledEventID}).pipe(
				take(1),
				map(scheduledEvent => scheduledEvent),
				catchError((error: HttpErrorResponse) => {
					this.navigateOnFail();
					return observableThrowError(error);
				}),
			);
		} else {
			this.navigateOnFail();
			return null;
		}
	}

	private initializeState(): void {
		this.store.select('sessionState').subscribe(session => { this.session = session; });
	}

	private navigateOnFail(): void {
		(this.session.selectedMember && this.session.selectedMember.systemNumber)
			? this.router.navigate(['counselor/customer-relations/member-follow-up'])
			: this.router.navigate(['counselor/follow-ups']);
	}
}
