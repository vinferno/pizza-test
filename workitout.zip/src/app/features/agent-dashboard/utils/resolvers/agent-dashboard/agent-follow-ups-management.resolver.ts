import { Injectable }          from '@angular/core';
import {
	ActivatedRouteSnapshot,
	Resolve,
	Router,
	RouterStateSnapshot,
}                              from '@angular/router';

import { Observable }          from 'rxjs';
import { map, take }           from 'rxjs/operators';
import { Store }               from '@ngrx/store';

import { AgentsCRMService }    from '../../agents-crm.service';
import { ScheduledEventsList } from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }        from '../../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class AgentFollowUpManagementResolver implements Resolve<ScheduledEventsList> {
	private session: SessionState;

	constructor(
		private agentsCRMService: AgentsCRMService,
		private router: Router,
		private store: Store<any>,
	) { }

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<ScheduledEventsList> {
		this.store.select('sessionState').subscribe(session => { this.session = session });

		if (this.session.agent && this.session.agent.agentID && this.session.agent.isSupervisor) {
			return this.agentsCRMService.getDefaultScheduledEventsSpecification().pipe(
				take(1),
				map(scheduledEventList => scheduledEventList),
			);
		}

		this.router.navigate(['counselor/follow-ups']);
		return null;
	}
}
