import { AgentCallLogResolver }              from './agent-call-log.resolver';
import { AgentCallLogDetailResolver }        from './agent-call-log-detail.resolver';
import { AgentCompletedFollowUpsResolver }   from './agent-completed-follow-ups.resolver';
import { AgentFollowUpsResolver }            from './agent-follow-ups.resolver';
import { AgentFollowUpManagementResolver }   from './agent-follow-ups-management.resolver';
import { AgentFollowUpDetailResolver }       from './agent-follow-up-detail.resolver';
import { AgentSearchHistoryResolver }        from './agent-search-history.resolver';
import { CustomerRelationsResolver }         from './customer-relations.resolver';
import { MemberActivityLogResolver }         from './member-activity-log.resolver';
import { MemberActivityLogDetailResolver }   from './member-activity-log-detail.resolver';
import { MemberCompletedFollowUpsResolver }  from './member-completed-follow-ups.resolver';
import { MemberFollowUpsResolver }           from './member-follow-ups.resolver';
import { MemberFollowUpManagementResolver }  from './member-follow-ups-management.resolver';

export const resolverList = [
	AgentCallLogResolver,
	AgentCallLogDetailResolver,
	AgentCompletedFollowUpsResolver,
	AgentFollowUpsResolver,
	AgentFollowUpManagementResolver,
	AgentFollowUpDetailResolver,
	AgentSearchHistoryResolver,
	CustomerRelationsResolver,
	MemberActivityLogResolver,
	MemberActivityLogDetailResolver,
	MemberCompletedFollowUpsResolver,
	MemberFollowUpsResolver,
	MemberFollowUpManagementResolver,
];

export const agentDashboardResolvers = {
	AgentCallLogResolver,
	AgentCallLogDetailResolver,
	AgentCompletedFollowUpsResolver,
	AgentFollowUpsResolver,
	AgentFollowUpManagementResolver,
	AgentFollowUpDetailResolver,
	AgentSearchHistoryResolver,
	CustomerRelationsResolver,
	MemberActivityLogResolver,
	MemberActivityLogDetailResolver,
	MemberCompletedFollowUpsResolver,
	MemberFollowUpsResolver,
	MemberFollowUpManagementResolver,
};

