import { Injectable }             from '@angular/core';
import {
	ActivatedRouteSnapshot,
	Resolve,
	RouterStateSnapshot,
}                                 from '@angular/router';

import { Observable }             from 'rxjs';

import { AgentsDashboardService } from '../../agent-dashboard.service';
import { AgentSearchResult }      from '../../../../../infrastructure/interfaces/agent';

@Injectable()
export class AgentSearchHistoryResolver implements Resolve<any> {
	constructor(
		private agentsDashboardService: AgentsDashboardService,
	) { }

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<AgentSearchResult[]> {
		const observer = this.agentsDashboardService.getMemberSearchHistory();
		observer.subscribe();

		return observer;
	}
}
