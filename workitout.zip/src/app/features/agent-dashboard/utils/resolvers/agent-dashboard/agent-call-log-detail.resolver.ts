import { Injectable }        from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import {
	ActivatedRouteSnapshot,
	Resolve,
	Router,
	RouterStateSnapshot,
}                            from '@angular/router';

import {
	Observable,
	throwError as observableThrowError,
}                            from 'rxjs';
import {
	catchError,
	map,
	take,
}                            from 'rxjs/operators';
import { Store }             from '@ngrx/store';

import {
	AgentCompanyCallLog,
	AgentCompanyCallLogID,
}                            from '../../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService }  from '../../agents-crm.service';
import { SessionState }      from '../../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class AgentCallLogDetailResolver implements Resolve<AgentCompanyCallLog> {
	public session: SessionState;

	constructor(
		private agentsCRMService: AgentsCRMService,
		private router: Router,
		private store: Store<any>,
	) {
		this.initializeState();
	}

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<AgentCompanyCallLog> {
		let payload: AgentCompanyCallLogID;
		(this.session && this.session.agent && this.session.agent.agentCallLog)
			? payload = { callLogID: this.session.agent.agentCallLog.callLogID }
			: payload = new AgentCompanyCallLogID();

		return this.agentsCRMService.getCallLogByID(payload).pipe(
			take(1),
			map(agentCallLog => agentCallLog),
			catchError((error: HttpErrorResponse) => {
				this.navigateOnFail();
				return observableThrowError(error);
			}),
		);
	}

	private initializeState(): void {
		this.store.select('sessionState').subscribe(session => { this.session = session; });
	}

	private navigateOnFail(): void {
		this.router.navigate(['counselor/call-log']);
	}
}
