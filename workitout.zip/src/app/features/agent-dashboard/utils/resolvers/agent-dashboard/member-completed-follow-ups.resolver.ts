import { Injectable }       from '@angular/core';
import {
	ActivatedRouteSnapshot,
	Resolve,
	Router,
	RouterStateSnapshot,
}                           from '@angular/router';

import {
	Observable,
	throwError as observableThrowError,
}                           from 'rxjs';
import {
	catchError,
	map,
	take,
}                           from 'rxjs/operators';
import { Store }            from '@ngrx/store';

import { AgentsCRMService } from '../../agents-crm.service';
import {
	AgentFilterPayload,
	ScheduledEventsList,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class MemberCompletedFollowUpsResolver implements Resolve<ScheduledEventsList> {
	private session: SessionState;

	constructor(
		private agentsCRMService: AgentsCRMService,
		private router: Router,
		private store: Store<any>,
	) { }

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<ScheduledEventsList> {
		this.store.select('sessionState').subscribe(session => { this.session = session });

		if (this.session.agent && this.session.agent.agentID && this.session.selectedMember && this.session.selectedMember.systemNumber) {
			const payload: AgentFilterPayload = {
				agentID      : this.session.agent.agentID,
				systemNumber : this.session.selectedMember.systemNumber,
			};

			return this.agentsCRMService.getCompletedMemberScheduledEvents(payload).pipe(
				take(1),
				map(activityLog => activityLog),
				catchError(error => this.handleError(error)),
			);
		}

		 this.router.navigate(['/dashboard']);
		 return null;
	}

	private handleError(error: Error): Observable<never> {
		this.router.navigate(['/dashboard']);
		return observableThrowError(error);
	}
}
