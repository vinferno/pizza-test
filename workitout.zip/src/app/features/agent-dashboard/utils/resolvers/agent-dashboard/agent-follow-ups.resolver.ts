import { Injectable }       from '@angular/core';
import {
	ActivatedRouteSnapshot,
	Resolve,
	RouterStateSnapshot,
}                           from '@angular/router';

import { Observable }       from 'rxjs';
import { map, take }        from 'rxjs/operators';
import { Store }            from '@ngrx/store';

import { AgentsCRMService } from '../../agents-crm.service';
import {
	AgentFilterPayload,
	ScheduledEventsList,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';

@Injectable()
export class AgentFollowUpsResolver implements Resolve<ScheduledEventsList> {
	private session: SessionState;

	constructor(
		private agentsCRMService: AgentsCRMService,
		private store: Store<any>,
	) { }

	resolve(route: ActivatedRouteSnapshot, stateSnap: RouterStateSnapshot): Observable<ScheduledEventsList> {
		this.store.select('sessionState').subscribe(session => { this.session = session });

		if (this.session.agent && this.session.agent.agentID) {
			const payload: AgentFilterPayload = {
				agentID      : this.session.agent.agentID,
				systemNumber : null,
			};
			return this.agentsCRMService.getScheduledEvents(payload).pipe(
				take(1),
				map(scheduledEventList => scheduledEventList),
			);
		}

		return null;
	}
}
