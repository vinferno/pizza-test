import { AgentCallLogSpecificationPresentationComponent } from './agent-call-log-specification/agent-call-log-specification-presentation.component';
import { AgentCallLogSpecificationSmartComponent }        from './agent-call-log-specification/agent-call-log-specification-smart.component';
import { AgentCompanyFilterComponent }                    from './agent-company-filter/agent-company-filter.component';
import { FollowUpSpecificationPresentationComponent }     from './follow-up-specification/follow-up-specification-presentation.component';
import { FollowUpSpecificationSmartComponent } from './follow-up-specification/follow-up-specification-smart.component';
import { FollowUpStatusControlComponent }      from './follow-up-status-control/follow-up-status-control.component';
import { ScheduledEventRemindersComponent }    from './scheduled-event-reminders/scheduled-event-reminders.component';
import { ScheduledEventTypesComponent }        from './scheduled-event-types/scheduled-event-types.component';
import { SupervisedAgentsComponent }           from './supervised-agents/supervised-agents.component';
import { DXSupervisedAgentsComponent }         from './dx-supervised-agents/dx-supervised-agents-component';
import { BrokerSelectComponent }               from './broker-select/broker-select.component';

export const Controls = [
	AgentCallLogSpecificationPresentationComponent,
	AgentCallLogSpecificationSmartComponent,
	AgentCompanyFilterComponent,
	BrokerSelectComponent,
	FollowUpSpecificationPresentationComponent,
	FollowUpSpecificationSmartComponent,
	FollowUpStatusControlComponent,
	ScheduledEventRemindersComponent,
	ScheduledEventTypesComponent,
	SupervisedAgentsComponent,
	DXSupervisedAgentsComponent,
];
