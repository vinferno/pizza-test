import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
}                               from '@angular/core';
import {
	AbstractControl,
	FormGroup,
}                               from '@angular/forms';

import { classWidths }          from '../../../../../infrastructure/utils/constants';
import { ListItem }             from '../../../../../infrastructure/interfaces/list-item';
import { LookupService }        from '../../../../../infrastructure/core/services/lookup.service';
import { Utils }                from '../../../../../infrastructure/utils/utils';
import { ValidationIsRequired } from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-scheduled-event-reminders',
	templateUrl     : './scheduled-event-reminders.component.html',
	styleUrls       : ['./scheduled-event-reminders.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class ScheduledEventRemindersComponent implements OnInit, OnDestroy {
	@Input() public classRule: classWidths;
	@Input() public form: FormGroup;
	@Input() public isRequired: boolean = false;
	@Input() public language: string = 'en';
	@Input() public nameForControl: string;
	@Input() public dxPlaceholder: string = 'Reminder';
	@Input() public placeholder: string = 'Reminder';

	public scheduledEventReminders: ListItem[] = [];

	constructor(
		public cd: ChangeDetectorRef,
		private lookup: LookupService,
	) { }

	ngOnInit(): void {
		this.getScheduledEventReminders();
		if (this.isRequired) { this.initializeValidation(); }
		this.dxPlaceholder = this.updatePlaceholder(this.placeholder);
	}

	ngOnDestroy(): void {
		this.cd.detach();
	}

	public get formControl(): AbstractControl {
		return this.form.get(this.nameForControl);
	}

	public setClass(className: classWidths): string {
		return Utils.setClasses(className);
	}

	private initializeValidation(): void {
		this.formControl.setValidators(ValidationIsRequired.isRequiredEmpty(this.placeholder));
		this.formControl.updateValueAndValidity();
	}

	private getScheduledEventReminders(): void {
		this.lookup.getAgentScheduledEventReminders().subscribe(scheduledEventReminder => {
			this.scheduledEventReminders = scheduledEventReminder.items;
			this.cd.detectChanges();
		});
	}

	private updatePlaceholder(placeholder: string): string {
		return (this.isRequired) ? `${placeholder} *` : placeholder;
	}
}

