import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
}                               from '@angular/core';
import {
	FormGroup,
	AbstractControl,
}            					from '@angular/forms';

import { classWidths }          from '../../../../../infrastructure/utils/constants';
import { ListItem }             from '../../../../../infrastructure/interfaces/list-item';
import { LookupService }        from '../../../../../infrastructure/core/services/lookup.service';
import { Utils }                from '../../../../../infrastructure/utils/utils';
import { ValidationIsRequired } from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-scheduled-event-types',
	templateUrl     : './scheduled-event-types.component.html',
	styleUrls       : ['./scheduled-event-types.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class ScheduledEventTypesComponent implements OnInit, OnDestroy {
	@Input() public classRule: classWidths;
	@Input() public form: FormGroup;
	@Input() public isRequired: boolean = false;
	@Input() public language: string = 'en';
	@Input() public nameForControl: string;
	@Input() public dxPlaceholder: string = 'Select Event Type';
	@Input() public placeholder: string = 'Event Type';

	public scheduledEventTypes: ListItem[] = [];

	constructor(
		public cd: ChangeDetectorRef,
		private lookup: LookupService,
	) { }

	ngOnInit(): void {
		this.getScheduledEventTypeList();
		this.dxPlaceholder = this.updatePlaceholder(this.placeholder);
		if (this.isRequired) { this.initializeValidation(); }
	}

	ngOnDestroy(): void {
		this.cd.detach();
	}

	public get formControl(): AbstractControl {
		return this.form.get(this.nameForControl);
	}

	public setClass(className: classWidths): string {
		return Utils.setClasses(className);
	}

	private initializeValidation(): void {
		this.form.get(this.nameForControl).setValidators(ValidationIsRequired.isRequiredEmpty(this.placeholder));
		this.form.get(this.nameForControl).updateValueAndValidity();
	}

	private getScheduledEventTypeList(): void {
		this.lookup.getAgentScheduledEventTypes().subscribe(scheduledEventType => {
			this.scheduledEventTypes = scheduledEventType.items;
			this.cd.detectChanges();
		});
	}

	private updatePlaceholder(placeholder: string): string {
		return (this.isRequired) ? `${placeholder} *` : placeholder;
	}
}

