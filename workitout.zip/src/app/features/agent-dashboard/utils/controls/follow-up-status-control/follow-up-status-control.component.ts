import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
}                               from '@angular/core';
import { FormGroup }            from '@angular/forms';

import { classWidths }          from '../../../../../infrastructure/utils/constants';
import { Utils }                from '../../../../../infrastructure/utils/utils';
import { ValidationIsRequired } from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-follow-up-status-control',
	templateUrl     : './follow-up-status-control.component.html',
	styleUrls       : ['./follow-up-status-control.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpStatusControlComponent implements OnInit, OnDestroy {
	@Input() public classRule: classWidths;
	@Input() public form: FormGroup;
	@Input() public isRequired: boolean = false;
	@Input() public language: string = 'en';
	@Input() public nameForControl: string;
	@Input() public placeholder: string = 'Follow Up Status';

	public options: {
		text: string;
		value: string;
	}[] = [
		{
			text: 'All',
			value: '',
		},
		{
			text: 'Open',
			value: '0',
		},
		{
			text: 'Complete',
			value: '1',
		},
	];

	constructor(
		public cd: ChangeDetectorRef,
	) { }

	ngOnInit(): void {
		if (this.isRequired) { this.initializeValidation(); }
	}

	ngOnDestroy(): void {
		this.cd.detach();
	}

	public setClass(className: classWidths): string {
		return Utils.setClasses(className);
	}

	private initializeValidation(): void {
		this.form.get(this.nameForControl).setValidators(ValidationIsRequired.isRequired(this.placeholder));
		this.form.get(this.nameForControl).updateValueAndValidity();
	}
}

