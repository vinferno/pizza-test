import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	Output,
}                              from '@angular/core';
import { FormGroup }           from '@angular/forms';

import { AgentCompany }        from '../../../../../infrastructure/interfaces/agent';
import { SettingsState }       from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }        from '../../../../../infrastructure/store/reducers/session/session-state';

@Component({
	selector        : 'hg-call-log-specification-presentation',
	templateUrl     : './agent-call-log-specification-presentation.component.html',
	styleUrls       : ['./agent-call-log-specification-presentation.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCallLogSpecificationPresentationComponent {
	@Input() public form: FormGroup;
	@Input() public isQueryValid: boolean = false;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitClear = new EventEmitter<void>();
	@Output() public emitSearch = new EventEmitter<FormGroup>();
	@Output() public emitSelectCompany: EventEmitter<AgentCompany> = new EventEmitter();

	public clear(): void {
		this.emitClear.emit();
	}

	public setSelectedCompany(company: AgentCompany): void {
		this.emitSelectCompany.emit(company);
	}

	public search(): void {
		this.emitSearch.emit(this.form);
	}
}
