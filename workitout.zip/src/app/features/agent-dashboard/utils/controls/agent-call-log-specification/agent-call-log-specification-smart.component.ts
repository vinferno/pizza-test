import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	OnInit,
	Output,
}                           from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                           from '@angular/forms';

import { AgentCompany }     from '../../../../../infrastructure/interfaces/agent';
import {
	AgentCompanyCallLogList,
	AgentCompanyCallLogSpecificationPayload,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService } from '../../agents-crm.service';
import { Constants }        from '../../../../../infrastructure/utils/constants';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }    from '../../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-call-log-specification',
	templateUrl     : './agent-call-log-specification-smart.component.html',
	styleUrls       : ['./agent-call-log-specification-smart.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCallLogSpecificationSmartComponent implements OnInit {
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitClear = new EventEmitter<void>();
	@Output() public emitQuery = new EventEmitter<AgentCompanyCallLogList>();

	public form: FormGroup;

	private company: AgentCompany = null;

	constructor (
		private agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
		private fb: FormBuilder,
	) { }

	ngOnInit() {
		this.form = this.buildForm();
	}

	public selectCompany(company: AgentCompany): void {
		if (company) {
			this.company = company;
		} else {
			this.form.get('companyID').setValue(null);
			this.company = null;
		}
	}

	public search(): void {
		const payload = this.buildPayload();
		this.getCallLogSpecification(payload);
	}

	public clear(): void {
		const callLogSpecification: AgentCompanyCallLogSpecificationPayload = new AgentCompanyCallLogSpecificationPayload();
		for (const property in callLogSpecification) {
			if (callLogSpecification.hasOwnProperty(property) && property !== 'agentID') {
				this.form.get(property).setValue(callLogSpecification[property]);
			}
		}

		this.emitClear.emit();
	}

	public isQueryValid(): boolean {
		return !!(
			this.form.get('companyID').value ||
			this.form.get('callerFirstNameQ').value ||
			this.form.get('callerLastNameQ').value ||
			this.form.get('callNumberQ').value ||
			this.form.get('startDateQ').value ||
			this.form.get('endDateQ').value
		);
	}

	private buildForm(): FormGroup {
		const callLogSpecification: AgentCompanyCallLogSpecificationPayload = new AgentCompanyCallLogSpecificationPayload();
		const form: FormGroup = this.fb.group({
			companyID: new FormControl (callLogSpecification.companyID),
			callerFirstNameQ: new FormControl (callLogSpecification.callerFirstNameQ),
			callerLastNameQ: new FormControl (callLogSpecification.callerLastNameQ),
			callNumberQ: new FormControl (callLogSpecification.callNumberQ),
			startDateQ: new FormControl (callLogSpecification.startDateQ),
			endDateQ: new FormControl (callLogSpecification.endDateQ),
		});

		return form;
	}

	private buildPayload(): AgentCompanyCallLogSpecificationPayload {
		const payload: AgentCompanyCallLogSpecificationPayload = new AgentCompanyCallLogSpecificationPayload();
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				switch (property) {
					case 'companyID':
						payload[property] = (this.company) ? this.company.companyID : Constants.emptyInt;
						break;
					case 'agentID':
						payload[property] = this.session.agent.agentID
						break;
					case 'callNumberQ':
						payload[property] = this.form.controls[property].value.replace(Constants.patterns.NON_DECIMAL_DIGITS, '');
						break;
					default:
						payload[property] = this.form.controls[property].value;
						break;
				}
			}
		}

		return payload;
	}

	private getCallLogSpecification(payload: AgentCompanyCallLogSpecificationPayload): void {
		this.agentsCRMService.getCallLogSpecification(payload).subscribe(response => {
			this.emitQuery.emit(response);
		});
	}
}
