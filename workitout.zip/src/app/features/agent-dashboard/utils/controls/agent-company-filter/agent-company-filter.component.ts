import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
	Output,
	EventEmitter,
}                                       from '@angular/core';
import { FormGroup }                    from '@angular/forms';
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";

import { Observable ,  Subscription }   from 'rxjs';
import {
	distinctUntilChanged,
	filter,
	map,
	startWith,
}                                       from 'rxjs/operators';
import { Store }                        from '@ngrx/store';

import { AgentCompany }                 from '../../../../../infrastructure/interfaces/agent';
import { AgentsDashboardService }       from '../../agent-dashboard.service';
import { classWidths }                  from '../../../../../infrastructure/utils/constants';
import { SessionState }                 from '../../../../../infrastructure/store/reducers/session/session-state';
import { stateActions }                 from '../../../../../infrastructure/store/reducers/reducers-index';
import { Utils }                        from '../../../../../infrastructure/utils/utils';
import { ValidationIsRequired }         from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-agent-company-filter',
	templateUrl     : './agent-company-filter.component.html',
	styleUrls       : ['./agent-company-filter.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCompanyFilterComponent implements OnInit, OnDestroy {
	@Input() public classRule: classWidths = 'form-width-full';
	@Input() public form: FormGroup;
	@Input() public nameForControl: string;
	@Input() public isRequired: boolean = false;
	@Input() public language: string = 'en';
	@Input() public session: SessionState;
	@Input() public customPlaceholder = '';

	@Output() public emitSelectedCompany: EventEmitter<AgentCompany> = new EventEmitter();

	public agentCompanies: AgentCompany[] = [];
	public filteredAgentCompanies$: Observable<AgentCompany[]>;
	public selectedCompany: AgentCompany = new AgentCompany();
	public toHighlight: string = '';

	private subscriptions: Subscription[] = [];

	constructor(
		private agentsDashboardService: AgentsDashboardService,
		private store: Store<any>,
	) { }

	ngOnInit(): void {
		this.initializeAgentSubscriptions();
		if (this.isRequired) { this.initializeValidation(); }
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public setClass(className: classWidths): string {
		return Utils.setClasses(className);
	}

	public displayFn(val: any): boolean {
		return val ? val.companyName : val;
	}

	public onSelectionChanged(event: MatAutocompleteSelectedEvent): void {
		if (this.selectedCompany !== event.option.value) {
			this.selectedCompany = event.option.value;
			this.emitSelectedCompany.emit(this.selectedCompany);
		}
	}

	public trackById(index: number, item: AgentCompany): number {
		return item.companyID;
	}

	private initializeState(): void {
		const agentCompaniesAvailable: boolean = !!(this.session && this.session.agent && this.session.agent.agentCompanies);
		this.agentCompanies = agentCompaniesAvailable ? this.session.agent.agentCompanies : [];
		this.filteredAgentCompanies$ = this.form.get(this.nameForControl).valueChanges.pipe(
			startWith(''),
			filter(value => typeof value === 'string'),
			distinctUntilChanged(),
			map(searchTerm => this.findCompany(searchTerm)),
		);
	}

	private initializeAgentSubscriptions(): void {
		const agentEnabledCompaniesSubscription = this.agentsDashboardService.getAgentEnabledCompanies().subscribe(agentCompanies => {
			this.store.dispatch(stateActions.sessionActions.updateAgent({ agentCompanies }));
			this.initializeState();
		});
		this.subscriptions.push(agentEnabledCompaniesSubscription);
	}

	private initializeValidation(): void {
		this.form.get(this.nameForControl).setValidators(ValidationIsRequired.isRequired('Company'));
		this.form.get(this.nameForControl).updateValueAndValidity();
	}

	private findCompany(companyName: string): AgentCompany[] {
		this.toHighlight = companyName;
		if (!companyName) {
			this.toHighlight = '';
			this.emitSelectedCompany.emit(null);
			return this.agentCompanies = this.session.agent.agentCompanies;
		}
		const filterValue = companyName.toLowerCase();
		return this.agentCompanies = this.session.agent.agentCompanies.filter(company => company.companyName.toLowerCase().startsWith(filterValue));
	}
}
