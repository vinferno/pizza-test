import { CommonModule }           from '@angular/common';
import { NgModule }               from '@angular/core';
import {
	FormsModule,
	ReactiveFormsModule,
}                                 from '@angular/forms';

import { ControlsModule }         from '../../../../infrastructure/shared/controls/controls.module';
import { CovalentModule }         from '../../../../infrastructure/utils/covalent.module';
import { DevExtremeModule }       from '../../../../infrastructure/utils/devextreme.module';
import { MaterialModule }         from '../../../../infrastructure/utils/material.module';
import { Controls }               from './controls';
import { SharedModule }           from 'app/infrastructure/shared/shared.module';
import { BrokerSelectComponent } from './broker-select/broker-select.component';

@NgModule({
	imports: [
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		SharedModule,
		ControlsModule,
		DevExtremeModule,
		MaterialModule,
		CovalentModule,
	],
	declarations: [Controls, BrokerSelectComponent],
	exports: [Controls],
})
export class AgentControlsModule {
	static forRoot() {
		return {
			ngModule: AgentControlsModule,
		};
	}
}
