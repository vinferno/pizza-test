import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	Output,
}                        from '@angular/core';
import { FormGroup }     from '@angular/forms';

import { SessionState }  from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState } from '../../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-follow-up-specification-presentation',
	templateUrl     : './follow-up-specification-presentation.component.html',
	styleUrls       : ['./follow-up-specification-presentation.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpSpecificationPresentationComponent {
	@Input() public form: FormGroup;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitClear = new EventEmitter<void>();
	@Output() public emitSearch = new EventEmitter<void>();

	public clear(): void {
		this.emitClear.emit();
	}

	public search(): void {
		this.emitSearch.emit();
	}
}
