import {
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
	ChangeDetectorRef,
	Output,
	EventEmitter,
} from '@angular/core';
import {
	AbstractControl,
	FormGroup,
}            from '@angular/forms';

import { AgentsCRMService }     from '../../agents-crm.service';
import {
	AgentFilterPayload,
	SupervisedAgent,
}                               from '../../../../../infrastructure/interfaces/agent-crm';
import { classWidths }          from '../../../../../infrastructure/utils/constants';
import { SessionState }         from '../../../../../infrastructure/store/reducers/session/session-state';
import { Utils }                from '../../../../../infrastructure/utils/utils';
import { ValidationIsRequired } from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-dx-supervised-agents',
	templateUrl     : './dx-supervised-agents-component.html',
	styleUrls       : ['./dx-supervised-agents-component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class DXSupervisedAgentsComponent implements OnInit, OnDestroy {
	@Input() public classRule: classWidths;
	@Input() public form: FormGroup;
	@Input() public isRequired: boolean = false;
	@Input() public hideIncludeDisabled: boolean = true;
	@Input() public language: string = 'en';
	@Input() public nameForControl: string;
	@Input() public dxPlaceholder: string = 'Select or Type Agent\'s Name to refine your search';
	@Input() public placeholder: string = 'Assigned To';
	@Input() public session: SessionState;
	@Input() public readonly: boolean = false;
	@Output() public emitSelection = new EventEmitter();
	public includeDisabled = false;
	public supervisedAgents: SupervisedAgent[];

	searchModeOption: string = 'contains';
    searchExprOption: any = 'name';
    searchTimeoutOption: number = 200;
    minSearchLengthOption: number = 0;
	constructor(
		private agentsCrm: AgentsCRMService,
		public cd: ChangeDetectorRef,
	) { }

	ngOnInit(): void {
		this.getSupervisedAgents();
		this.dxPlaceholder = this.updatePlaceholder(this.placeholder);
		if (this.isRequired) { this.initializeValidation(); }
	}

	ngOnDestroy(): void {
		this.cd.detach();
	}

	public get formControl(): AbstractControl {
		return this.form.get(this.nameForControl);
	}

	public setClass(className: classWidths): string {
		return Utils.setClasses(className);
	}

	public trackById(index: number, item: SupervisedAgent): number {
		return item.agentID;
	}

	private initializeValidation(): void {
		this.form.get(this.nameForControl).setValidators(ValidationIsRequired.isRequiredEmpty(this.placeholder));
		this.form.get(this.nameForControl).updateValueAndValidity();
	}

	public getSupervisedAgents(): void {
		this.supervisedAgents = null;
		const payload: AgentFilterPayload = {
			includeDisabled: this.includeDisabled,
			agentID      : this.session.agent.agentID,
			systemNumber : (this.session.selectedMember && this.session.selectedMember.systemNumber) ? this.session.selectedMember.systemNumber : null,
		};
		this.agentsCrm.supervisedAgents(payload).subscribe(response => {
			if (response && response.supervisedAgents) {
				this.supervisedAgents = response.supervisedAgents;
			}
			this.cd.detectChanges();
		});
	}
	public selectAgent(event) {
		this.emitSelection.emit(event);
	}
	private updatePlaceholder(placeholder: string): string {
		return (this.isRequired) ? `${placeholder} *` : placeholder;
	}
}
