import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { classWidths }                                                              from '../../../../../infrastructure/utils/constants';
import { Utils }                                                                    from '../../../../../infrastructure/utils/utils';
import { FormGroup }                                                                from '@angular/forms';
import { SessionState }                                                             from '../../../../../infrastructure/store/reducers/session/session-state';
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { distinctUntilChanged, filter, map, startWith }                             from 'rxjs/operators';

@Component({
	selector   : 'hg-broker-select',
	templateUrl: './broker-select.component.html',
	styleUrls  : ['./broker-select.component.scss'],
})
export class BrokerSelectComponent implements OnInit, OnChanges {
	public toHighlight: string = '';
	@Input() public classRule: classWidths;
	@Input() public form: FormGroup;
	@Input() public isRequired: boolean = false;
	@Input() public language: string = 'en';
	@Input() public nameForControl: string;
	@Input() public placeholder: string = 'Assigned To';
	@Input() public session: SessionState;
	@Input() public brokers;
	public filteredBrokers = [];
	@Output() public emitSelectedBroker = new EventEmitter();
	private selectedBroker: any;

	constructor () { }

	ngOnInit (): void {
		this.setClass('form-width-half');
		this.initializeState();
	}

	ngOnChanges (changes: SimpleChanges): void {
		if (this.selectedBroker) return;
		this.findBroker('');
		this.findDefault();
	}

	public trackById (index: number, item): number {
		return item.name;
	}

	public setClass (className: classWidths): string {
		return Utils.setClasses(className);
	}

	public onSelectionChanged (event: MatAutocompleteSelectedEvent): void {
		if (this.selectedBroker !== event.option.value) {
			this.selectedBroker = event.option.value;
			this.emitSelectedBroker.emit(this.selectedBroker);
		}
	}

	public displayFn (val: any): boolean {
		return val ? val.name : val;
	}

	private initializeState (): void {
		this.filteredBrokers = this.brokers;
		this.form.get(this.nameForControl).valueChanges.pipe(
			startWith(''),
			filter(value => typeof value === 'string'),
			distinctUntilChanged(),
			map(searchTerm => this.findBroker(searchTerm)),
		).subscribe();

	}

	private findBroker (brokerName: string) {
		this.toHighlight = brokerName;
		if (!brokerName) {
			this.toHighlight = '';
			return this.filteredBrokers = this.brokers;
		}
		const filterValue = brokerName.toLowerCase();
		this.filteredBrokers = this.brokers.filter(broker => broker.name.toLowerCase().startsWith(filterValue.toLowerCase()));
		return this.filteredBrokers;
	}

	private findDefault() {
		this.filteredBrokers.forEach( broker => {
			if (broker.id === this.session.agent.brokerID) {
				this.form.get(this.nameForControl).setValue(broker);
				this.selectedBroker = broker;
				this.emitSelectedBroker.emit(this.selectedBroker);
			}
		});
	}
}

