import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokerSelectComponent } from './broker-select.component';

describe('BrokerSelectComponent', () => {
  let component: BrokerSelectComponent;
  let fixture: ComponentFixture<BrokerSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokerSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokerSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
