import { Injectable }      from '@angular/core';
import { catchError, map } from 'rxjs/operators';

import { ApiService }                              from '../../../infrastructure/core/api/api.service';
import { MessageService }                          from '../../../infrastructure/shared/controls/message/message.service';
import { IToast }                                  from '../../../infrastructure/interfaces/toast';
import { TranslateService }                        from '../../../infrastructure/core/services/translate.service';
import { HttpErrorResponse }                       from '@angular/common/http';
import { ResponseErrorHandlerService }             from '../../../infrastructure/core/services/response-error-handler.service';
import { AgentFilterPayload, SupervisedAgentList } from '../../../infrastructure/interfaces/agent-crm';
import { Observable }                              from 'rxjs';

@Injectable()
export class AgentsManageService {

	constructor (
		private api: ApiService,
		private messageService: MessageService,
		private translate: TranslateService,
		private errors: ResponseErrorHandlerService
	) {
	}

	public getAgents ({ includeDisabled }) {
		return this.api.agentsManage.getAgents.post({ includeDisabled });
	}

	public getAgentCarriers ({ includeDisabled }) {
		return this.api.agentsManage.getAgentCarriers.post({ includeDisabled });
	}

	public getAgentCarrierInfo ({carrierID, includeDisabled, companyID }) {
		const payload = { carrierID, includeDisabled, companyID };
		if (!companyID) {
			delete payload.companyID;
		}
		return this.api.agentsManage.getAgentCarrierInfo.post(payload);
	}

	public updateAgentsDisabled (ids) {
		const message: IToast = {
			header     : 'Success',
			description: 'Agents Enabled/Disabled selections saved.',
		};
		return this.api.agentsManage.updateAgentsDisabled.post(ids).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}))

	}

	public editAgentProfile (agent) {
		const message: IToast = {
			header     : 'Success',
			description: 'Agent profile saved.',
		};
		return this.api.agentsManage.editAgentProfile.post(agent).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		)
	}

	public editAgentResetPassword (agent) {
		const message: IToast = {
			header     : 'Success',
			description: 'Agent will be required to change password on next login.',
		};
		return this.api.agentsManage.editAgentResetPassword.post(agent).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		)
	}

	public saveAgentCarrierInfo (agent) {
		const message: IToast = {
			header     : 'Success',
			description: 'Agent Carrier Info Saved.',
		};
		return this.api.agentsManage.saveAgentCarrierInfo.post(agent).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		)
	}

	public agentCreateAgent (agent) {
		const message: IToast = {
			header     : 'Success',
			description: 'New Agent Created.',
		};
		return this.api.agentsManage.agentCreateAgent.post(agent).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		)
	}

	public getCompaniesForAgent (agentID) {
		return this.api.agentsManage.getCompaniesForAgent.post({ agentID });
	}

	public getCompaniesForAgentUnassigned (agentID) {
		return this.api.agentsManage.getCompaniesForAgentUnassigned.post({ agentID });
	}

	public getAgentsAssignedToCompany (companyID) {
		return this.api.agentsManage.getAgentsAssignedToCompany.post({ companyID });
	}

	public getAgentsNotAssignedToCompany (companyID) {
		return this.api.agentsManage.getAgentsNotAssignedToCompany.post({ companyID });
	}
	public assignAgentsToCompany (companyID, agentIDs) {
		const message: IToast = {
			header     : 'Success',
			description: 'Assigned Agents to company.',
		};
		return this.api.agentsManage.assignAgentsToCompany.post({ companyID, agentIDs }).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public unAssignAgentsFromCompany (companyID, agentIDs) {
		const message: IToast = {
			header     : 'Success',
			description: 'UnAssigned Agents from company.',
		};
		return this.api.agentsManage.unAssignAgentsToCompany.post({ companyID, agentIDs }).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}


	public assignCompaniesToAgent (agentID, companyIDs ) {
		const message: IToast = {
			header     : 'Success',
			description: 'Assigned Companies to Agent.',
		};
		return this.api.agentsManage.assignCompaniesToAgent.post({ companyIDs, agentID }).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public UnAssignCompaniesFromAgent (agentID, companyIDs ) {
		const message: IToast = {
			header     : 'Success',
			description: 'UnAssigned Companies from Agent.',
		};
		return this.api.agentsManage.unAssignCompaniesFromAgent.post({ companyIDs, agentID }).pipe(
			map(() => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getBrokers() {
		return this.api.agentsManage.getBrokers.get();
	}
	public updateWorkingBroker(value) {
		return this.api.agentsManage.updateWorkingBroker.post(value);
	}
	public supervisedAgents(payload: AgentFilterPayload): Observable<SupervisedAgentList> {
		return this.api.agentsManage.supervisedAgents.post(payload).pipe(
			map((response: SupervisedAgentList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}
}
