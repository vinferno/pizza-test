import { Injectable }                  from '@angular/core';
import { HttpErrorResponse }           from '@angular/common/http';

import {
	FormBuilder,
	Validators,
	FormGroup,
}                                      from '@angular/forms';

import { BehaviorSubject, Observable } from 'rxjs';
import { catchError, map }             from 'rxjs/operators';
import { Store }                       from '@ngrx/store';

import { ApiService }                  from '../../../infrastructure/core/api/api.service';
import { MessageService }              from '../../../infrastructure/shared/controls/message/message.service';
import {
	AgentCompany,
	AgentCompanyList,
	AgentCreateMemberModel,
	AgentCreateMemberModelPayload,
	AgentCreateMemberPayload,
	AgentCreateMemberResponse,
	AgentSearchResult,
	AgentSearchResultList,
}                                      from '../../../infrastructure/interfaces/agent';
import { IToast }                      from '../../../infrastructure/interfaces/toast';
import { ResponseErrorHandlerService } from '../../../infrastructure/core/services/response-error-handler.service';
import { stateActions }                from '../../../infrastructure/store/reducers/reducers-index';
import { TranslateService }            from '../../../infrastructure/core/services/translate.service';
import { UpdatePassword }              from '../../profile/member/update-password-dialog/update-password';
import { ValidationNumericService }    from '../../../infrastructure/core/validation/validation-numeric.service';

@Injectable()
export class AgentsDashboardService {
	public agentDashboardForm: FormGroup;
	public memberSearchFormState: BehaviorSubject<FormGroup> = new BehaviorSubject(null);

	constructor (
		private api: ApiService,
		private errors: ResponseErrorHandlerService,
		private fb: FormBuilder,
		private messageService: MessageService,
		private translate: TranslateService,
		private store: Store<any>,
	) {
		this.agentDashboardForm = this.fb.group({
			selectedMember    : null,
			agentConfirmMember: null,
			memberSearch      : null,
		});
		this.resetSearchForm();
	}

	public getReports() {
		return this.api.agentsCrm.reports.get();
	}
	public runReport(payload) {
		return this.api.agentsCrm.report.post(payload);
	}
	public getReportHistory(): Observable<any> {
		return this.api.agentsCrm.reportHistory.get();
	}

	public getRecentReports(): Observable<any> {
		return this.api.agentsCrm.recentReports.get();
	}

	public deleteReports(report): Observable<any> {
		return this.api.agentsCrm.deleteReport.post(report);
	}


	public resetSearchForm(): void {
		this.memberSearchFormState.next(this.fb.group({
			FirstNameQ    : '',
			LastNameQ     : '',
			Last4SSNQ     : '',
			SSNQ          : '',
			EmployeeIDQ   : '',
			SystemNumberQ : [null, Validators.compose([ValidationNumericService.systemNumber()])],
			PayrollNumberQ: '',
			PhoneQ        : '',
			IsPrimaryQ    : true,
			EmailQ        : '',
			IsTestQ       : false,
		}));
	}

	public clearForm(formList: FormGroup[]): void {
		if (!formList) { return; }
		formList.forEach(form => {
			const controls = Object.keys(form.controls).map(controlName => {
				return { name: controlName, control: form.controls[controlName] }
			});

			controls.forEach(control => {
				if (control.control && typeof control.control.value === 'string') {
					control.control.setValue('');
				}
			})
		});
	}

	public createMember(payload: AgentCreateMemberPayload): Observable<AgentCreateMemberResponse> {
		const message: IToast = {
			header     : 'Success',
			description: 'Member Created. Logging in as new member.',
		};

		return this.api.agents.createMember.post(payload).pipe(
			map((response: AgentCreateMemberResponse) => {
				this.translate.translateError(message)
					.subscribe(translatedMessage => { this.messageService.showToastSuccess(translatedMessage); });
				return response;
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public createMemberModel(payload: AgentCreateMemberModelPayload): Observable<AgentCreateMemberModel> {
		return this.api.agents.createMemberModel.post(payload).pipe(
			map((response: AgentCreateMemberModel) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getAgentEnabledCompanies(): Observable<AgentCompany[]> {
		return this.api.agents.enabledCompanies.get().pipe(
			map((response: AgentCompanyList) => response.agentCompanies),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getAgentEnabledCompaniesToCreateMembers(): Observable<AgentCompany[]> {
		return this.api.agents.enabledCompanies.getEnabledCompaniesToCreateMembers().pipe(
			map((response: AgentCompanyList) => response.agentCompanies),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getMemberSearchHistory(): Observable<AgentSearchResult[]> {
		return this.api.agents.memberSearchHistory.get().pipe(
			map((response: AgentSearchResultList) => response.matchingMembers),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public updatePassword(password: UpdatePassword): Observable<void> {
		const message: IToast = {
			header     : 'Success',
			description: 'Password updated.',
		};

		return this.api.agents.updateAgentPassword.post(password).pipe(
			map(() => {
				this.translate.translateError(message)
					.subscribe(translatedMessage => { this.messageService.showToastSuccess(translatedMessage); });
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}
}
