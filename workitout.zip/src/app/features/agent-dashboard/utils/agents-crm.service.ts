
import { Injectable }                  from '@angular/core';
import { HttpErrorResponse }           from '@angular/common/http';

import { Observable }                  from 'rxjs';
import { catchError, map }             from 'rxjs/operators';

import { ApiService }                  from '../../../infrastructure/core/api/api.service';
import {
	AgentCompanyAppendCallLogPayload,
	AgentCompanyCallLog,
	AgentCompanyCallLogID,
	AgentCompanyCallLogList,
	AgentCompanyCallLogPayload,
	AgentCompanyCallLogSpecificationPayload,
	AgentCompanyResources,
	AgentFilterPayload,
	MemberActivityLog,
	MemberActivityLogID,
	MemberActivityLogList,
	MemberActivityLogPayload,
	MemberAppendActivityLogPayload,
	ScheduledEvent,
	ScheduledEventAppendPayload,
	ScheduledEventCompletePayload,
	ScheduledEventID,
	ScheduledEventOverridePayload,
	ScheduledEventPayload,
	ScheduledEventsList,
	ScheduledEventSpecificationPayload,
	SupervisedAgentList,
	ReassignScheduledEventListPayload,
}                                      from '../../../infrastructure/interfaces/agent-crm';
import { MessageService }              from '../../../infrastructure/shared/controls/message/message.service';
import { ResponseErrorHandlerService } from '../../../infrastructure/core/services/response-error-handler.service';
import { TranslateService }            from '../../../infrastructure/core/services/translate.service';
import { Constants }                   from '../../../infrastructure/utils/constants';
import { IToast }					   from '../../../infrastructure/interfaces/toast';

@Injectable()
export class AgentsCRMService {
	constructor (
		private api: ApiService,
		private errors: ResponseErrorHandlerService,
		private messageService: MessageService,
		private translate: TranslateService,
	) { }

	public getCompanyResourcesByID(payload: { companyID: number }): Observable<AgentCompanyResources> {
		return this.api.agentsCrm.companyResources.post(payload).pipe(
			map((response: AgentCompanyResources) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	//#region Scheduled Events
	public getScheduledEvents(payload: AgentFilterPayload): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.scheduledEvents.post(this.guardFollowUpPayload(payload)).pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getCompletedScheduledEvents(payload: AgentFilterPayload): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.completedScheduledEvents.post(this.guardFollowUpPayload(payload)).pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getScheduledEventByID(payload: ScheduledEventID): Observable<ScheduledEvent> {
		return this.api.agentsCrm.scheduledEvent.post(payload).pipe(
			map((response: ScheduledEvent) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getMemberScheduledEvents(payload: AgentFilterPayload): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.scheduledEventsMember.post(this.guardFollowUpPayload(payload)).pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getCompletedMemberScheduledEvents(payload: AgentFilterPayload): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.completedScheduledEventsMember.post(this.guardFollowUpPayload(payload)).pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public newScheduledEvent(payload: ScheduledEventPayload): Observable<void> {
		return this.api.agentsCrm.newScheduledEvent.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public modifyScheduledEvent(payload: ScheduledEventOverridePayload): Observable<void> {
		return this.api.agentsCrm.modifyScheduledEvent.put(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public appendScheduledEventNote(payload: ScheduledEventAppendPayload): Observable<void> {
		return this.api.agentsCrm.appendScheduledEventNote.put(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public supervisedAgents(payload: AgentFilterPayload): Observable<SupervisedAgentList> {
		return this.api.agentsCrm.supervisedAgents.post(this.guardFollowUpPayload(payload)).pipe(
			map((response: SupervisedAgentList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public completeEvent(payload: ScheduledEventCompletePayload): Observable<void> {
		const message: IToast = {
			header     : 'Success',
			description: 'Event marked as complete.',
		};
		return this.api.agentsCrm.completeScheduledEvent.post(payload).pipe(
			map((response: never) => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));

				return response;
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public markEventAsOpen(payload: ScheduledEventCompletePayload): Observable<void> {
		const message: IToast = {
			header     : 'Success',
			description: 'Event marked as open.',
		};
		return this.api.agentsCrm.setScheduledEventAsIncomplete.post(payload).pipe(
			map((response: never) => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));

				return response;
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getDefaultScheduledEventsSpecification(): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.scheduledEventsSpecification.get().pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getScheduledEventsSpecification(payload: ScheduledEventSpecificationPayload): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.scheduledEventsSpecification.post(this.guardFollowUpPayload(payload)).pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getDefaultScheduledEventsMemberSpecification(): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.scheduledEventsMemberSpecification.get().pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getScheduledEventsMemberSpecification(payload: ScheduledEventSpecificationPayload): Observable<ScheduledEventsList> {
		return this.api.agentsCrm.scheduledEventsMemberSpecification.post(payload).pipe(
			map((response: ScheduledEventsList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public reassignScheduledEventList(payload: ReassignScheduledEventListPayload): Observable<ScheduledEventsList> {
		const message: IToast = {
			header     : 'Success',
			description: `Event reassigned.`,
		};
		return this.api.agentsCrm.reassignAgentAssignedToScheduledEventList.post(payload).pipe(
			map((response: ScheduledEventsList) => {
				this.translate.translateError(message).subscribe(translatedMessage => this.messageService.showToastSuccess(translatedMessage));

				return response;
			}),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public guardFollowUpPayload(payload) {
		const fixedPayload = {...payload};
		if (fixedPayload.agentAssignedTo && fixedPayload.agentAssignedTo.agentID) {
			fixedPayload.agentAssignedTo = fixedPayload.agentAssignedTo.agentID;
		}
		fixedPayload.agentAssignedTo = parseInt(fixedPayload.agentAssignedTo);
		if (!fixedPayload.agentAssignedTo) {
			fixedPayload.agentAssignedTo = Constants.emptyInt;
		}
		if (!fixedPayload.agentID) {
			fixedPayload.agentID = Constants.emptyInt;
		}
		return fixedPayload;
	}

	//#endregion

	//#region Company CallLog
	public createCallLog(payload: AgentCompanyCallLogPayload): Observable<void> {
		return this.api.agentsCrm.callLog.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public appendCallLog(payload: Partial<AgentCompanyAppendCallLogPayload>): Observable<void> {
		return this.api.agentsCrm.callLog.put(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getCallLog(): Observable<AgentCompanyCallLogList> {
		return this.api.agentsCrm.callLog.get().pipe(
			map((response: AgentCompanyCallLogList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getCallLogByID(payload: AgentCompanyCallLogID): Observable<AgentCompanyCallLog> {
		return this.api.agentsCrm.callLogByID.post(payload).pipe(
			map((response: AgentCompanyCallLog) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getCallLogSpecification(payload: AgentCompanyCallLogSpecificationPayload): Observable<AgentCompanyCallLogList> {
		return this.api.agentsCrm.callLogSpecification.post(payload).pipe(
			map((response: AgentCompanyCallLogList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	//#endregion

	//#region Member Activity Log
	public createActivityLog(payload: MemberActivityLogPayload): Observable<void> {
		return this.api.agentsCrm.memberActivityLog.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public appendActivityLog(payload: Partial<MemberAppendActivityLogPayload>): Observable<void> {
		return this.api.agentsCrm.memberActivityLog.put(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getActivityLog(payload: AgentFilterPayload): Observable<MemberActivityLogList> {
		return this.api.agentsCrm.memberActivityLogList.post(payload).pipe(
			map((response: MemberActivityLogList) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getActivityLogByID(payload: MemberActivityLogID): Observable<MemberActivityLog> {
		return this.api.agentsCrm.memberActivityLogByID.post(payload).pipe(
			map((response: MemberActivityLog) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	//#endregion

	//#region Reports
	public company(payload): Observable<void> {
		return this.api.agentsCrm.company.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getParameter(): Observable<void> {
		return this.api.agentsCrm.getParameter.get().pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public postParameter(payload): Observable<void> {
		return this.api.agentsCrm.getParameter.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public postParameterById(payload): Observable<void> {
		return this.api.agentsCrm.parameterById.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getReportSelectOpenEnrollments(payload): Observable<void> {
		return this.api.agentsCrm.reportSelectOpenEnrollment.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getReportParams(payload): Observable<void> {
		return this.api.agentsCrm.reportParams.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public initializeReport(payload): Observable<void> {
		return this.api.agentsCrm.initializeReport.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getDetail(): Observable<void> {
		return this.api.agentsCrm.getDetail.get().pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public postDetail(payload): Observable<void> {
		return this.api.agentsCrm.getDetail.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getSummary(): Observable<void> {
		return this.api.agentsCrm.getSummary.get().pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public postSummary(): Observable<boolean> {
		return this.api.agentsCrm.getSummary.post(null).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public getTemplates(): Observable<void> {
		return this.api.agentsCrm.getTemplates.get().pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	public postTemplates(payload): Observable<void> {
		return this.api.agentsCrm.getTemplates.post(payload).pipe(
			map((response: never) => response),
			catchError((error: HttpErrorResponse) => this.errors.handleError(error)),
		);
	}

	//#endregion
}
