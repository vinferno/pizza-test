import { NgModule }                                   from '@angular/core';
import { RouterModule, Routes }                       from '@angular/router';

import { AgentCaseOverviewSmartComponent }            from './routed-views/agent-case-overview/agent-case-overview-smart.component';
import { AgentCaseOverviewPresentationComponent }     from './routed-views/agent-case-overview/agent-case-overview-presentation.component';
import { AgentCreateMemberSmartComponent }            from './routed-views/agent-create-member/agent-create-member-smart.component';
import { AgentCreateMemberPresentationComponent }     from './routed-views/agent-create-member/agent-create-member-presentation.component';
import { AgentDashboardComponent }                    from './agent-dashboard.component';
import { AgentDashboardGuard }                        from './utils/guards/agent-dashboard.guard';
import { AgentReportComponents }                      from './routed-views/agent-reports/execute-report-modal/components/agent-report-components';
import { AgentReportsSmartComponent }                 from './routed-views/agent-reports/agent-reports-smart.component';
import { AgentReportStepperSmartComponent }           from './routed-views/agent-reports/execute-report-modal/components/agent-report-stepper/agent-report-stepper-smart.component';
import { ExecuteReportModalSmartComponent }           from './routed-views/agent-reports/execute-report-modal/execute-report-modal-smart.component';
import { routes as customerRelationsRoutes }          from './routed-views/customer-relations/customer-relations-routing.module';
import { TitleResolver }                              from '../../infrastructure/core/resolvers/title.resolver';
import { AgentTodaysReportsComponent }                from './routed-views/agent-reports/todays-reports/todays-reports.component'
import { AgentReportHistoryComponent }                from './routed-views/agent-reports/history/history.component'


const routes: Routes = [
	{
		path     : '',
		component: AgentDashboardComponent,
		resolve  : {
			title: TitleResolver,
		},
		children : [
			{
				path     : 'create-member',
				component: AgentCreateMemberSmartComponent,
				canActivate: [AgentDashboardGuard],
			},
			{
				path     : 'reports',
				component: AgentReportsSmartComponent,
				canActivate: [AgentDashboardGuard],
			},
			{
				path     : 'reports/todays-reports',
				component: AgentTodaysReportsComponent,
			},
			{
				path     : 'reports/history',
				component: AgentReportHistoryComponent,
            },
			{
				path     : 'reports/report-builder/:reportID',
				component: AgentReportStepperSmartComponent,
				canActivate: [AgentDashboardGuard],
			},
			{
				path     : 'case-overview',
				component: AgentCaseOverviewSmartComponent,
				canActivate: [AgentDashboardGuard],
			},
			{
				path    : 'customer-relations',
				children: customerRelationsRoutes,
				data    : { title: 'Customer Relations' },
				resolve : {
					title: TitleResolver,
				},
			},
		],
	},
];

@NgModule({
	imports: [
		RouterModule.forChild(routes),
	],
	exports: [RouterModule],
})
export class AgentDashboardRoutingModule {
}

export const routedComponents = [
	AgentCaseOverviewPresentationComponent,
	AgentCaseOverviewSmartComponent,
	AgentDashboardComponent,
	AgentCreateMemberPresentationComponent,
	AgentCreateMemberSmartComponent,
	AgentReportComponents,
	AgentReportsSmartComponent,
	AgentReportHistoryComponent,
	AgentReportStepperSmartComponent,
	AgentTodaysReportsComponent,
	ExecuteReportModalSmartComponent,
];
