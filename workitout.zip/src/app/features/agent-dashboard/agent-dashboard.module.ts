import { CommonModule }                             from '@angular/common';
import { NgModule }                                 from '@angular/core';
import { FormsModule, ReactiveFormsModule }         from '@angular/forms';

//#region Components
import {
	AgentDashboardRoutingModule,
	routedComponents,
}                                                   from './agent-dashboard-routing.module';
import {
	AgentManageNotAssignedToCompanyComponent,
} 													from './routed-views/agent-manage-smart/agent-manage-company-assign/agent-manage-not-assigned-to-company/agent-manage-not-assigned-to-company.component';
import { AgentManageUnassignedCompaniesComponent }  from './routed-views/agent-manage-smart/agent-manage-agent-assign/agent-manage-unassigned-companies/agent-manage-unassigned-companies.component';
import { NewAgentModalComponent }                   from './routed-views/agent-manage-smart/agent-manage-agent/new-agent-modal/new-agent-modal.component';
//#endregion

//#region Services
import { AgentsCRMService }                         from './utils/agents-crm.service';
import { AgentsDashboardService }                   from './utils/agent-dashboard.service';
import { AgentsManageService }                      from './utils/agents-manage.service';
//#endregion

//#region Guards
import { AgentConfirmGuard }                        from './utils/guards/agent-confirm.guard';
import { AgentDashboardGuard }                      from './utils/guards/agent-dashboard.guard';
//#endregion

//#region Modules
import { AgentControlsModule }                      from './utils/controls/agent-controls.module';
import { AgentCallLogModule }                       from './routed-views/agent-call-log/agent-call-log.module';
import { AgentManageModule }						from './routed-views/agent-manage-smart/agent-manage.module';
import { AgentFollowUpsModule }                     from './routed-views/agent-follow-ups/agent-follow-ups.module';
import { AgentCompanyResourcesModule }				from './routed-views/agent-company-resources/agent-company-resources-module';
import { CustomerRelationsModule }                  from './routed-views/customer-relations/customer-relations.module';
import { ControlsModule }                           from '../../infrastructure/shared/controls/controls.module';
import { CovalentModule }                           from '../../infrastructure/utils/covalent.module';
import { DevExtremeModule }                         from '../../infrastructure/utils/devextreme.module';
import { MaterialModule }                           from '../../infrastructure/utils/material.module';
import { MemberSearchModule }                       from './member-search/member-search.module';
import { SharedModule }                             from 'app/infrastructure/shared/shared.module';
//#endregion

import { resolvers }                                from './utils/resolvers/resolvers';

@NgModule({
	imports        : [
		CommonModule,
		MaterialModule,
		FormsModule,
		ReactiveFormsModule,
		SharedModule,
		AgentControlsModule,
		ControlsModule,
		CovalentModule,
		DevExtremeModule,
		MemberSearchModule,
		AgentCallLogModule,
		AgentManageModule,
		AgentFollowUpsModule,
		AgentCompanyResourcesModule,
		CustomerRelationsModule,
		AgentDashboardRoutingModule,
	],
	entryComponents: [
		NewAgentModalComponent,
		AgentManageUnassignedCompaniesComponent,
		AgentManageNotAssignedToCompanyComponent,
	],
	declarations   : [
		routedComponents,
		NewAgentModalComponent,
	],
	providers      : [
		AgentsCRMService,
		AgentsManageService,
		AgentsDashboardService,
		AgentConfirmGuard,
		AgentDashboardGuard,
		resolvers,
	],
})
export class AgentDashboardModule {}
