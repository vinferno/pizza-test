import {
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
 }                       from '@angular/core';

import { Store }         from '@ngrx/store';
import {
	Observable,
	Subscription,
}                        from 'rxjs';

import { animator }      from '../../../infrastructure/core/animations/animations';
import { INavigation }   from 'app/infrastructure/interfaces/navigation';
import { SettingsState } from '../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector    : 'hg-member-search',
	templateUrl : './member-search.component.html',
	styleUrls   : ['./member-search.component.scss'],
	animations  : [animator.slide],
})
export class MemberSearchComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public navLinks: INavigation[] = [
		{
			label : 'Member Lookup',
			link  : '/counselor/member-lookup',
		},
		{
			label : 'Lookup History',
			link  : '/counselor/lookup-history',
		},
		{
			label : 'Test Members',
			link  : '/counselor/test-members',
		},
	];
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public trackByLink(index: number, item): number {
		return (item) ? item.link : null;
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
	}
}
