import { NgModule }                              from '@angular/core';
import { RouterModule, Routes }                  from '@angular/router';

import { AgentConfirmGuard }                     from '../utils/guards/agent-confirm.guard';
import { AgentDashboardGuard }                   from '../utils/guards/agent-dashboard.guard';
import { agentDashboardResolvers }               from '../utils/resolvers/agent-dashboard/agent-dashboard-resolvers';
import { MemberSearchComponent }                 from './member-search.component';
import { AgentConfirmPresentationComponent }     from '../routed-views/agent-confirm/agent-confirm-presentation.component';
import { AgentConfirmSmartComponent }            from '../routed-views/agent-confirm/agent-confirm-smart.component';
import { AgentHistoryPresentationComponent }     from '../routed-views/agent-history/agent-history-presentation.component';
import { AgentHistorySmartComponent }            from '../routed-views/agent-history/agent-history-smart.component';
import { AgentSearchPresentationComponent }      from '../routed-views/agent-search/agent-search-presentation.component';
import { AgentSearchSmartComponent }             from '../routed-views/agent-search/agent-search-smart.component';
import { AgentTestMembersSmartComponent }        from '../routed-views/agent-test-members/agent-test-members-smart.component';
import { AgentTestMembersPresentationComponent } from '../routed-views/agent-test-members/agent-test-members-presentation.component';
import { TitleResolver }                         from '../../../infrastructure/core/resolvers/title.resolver';

const routes: Routes = [
	{
		path       : '',
		component  : MemberSearchComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path       : '',
				redirectTo : 'member-lookup',
				pathMatch  : 'full',
			},
			{
				path     : 'member-lookup',
				component: AgentSearchSmartComponent,
			},
			{
				path     : 'lookup-history',
				component: AgentHistorySmartComponent,
				resolve  : {
					history: agentDashboardResolvers.AgentSearchHistoryResolver,
				},
			},
			{
				path     : 'test-members',
				component: AgentTestMembersSmartComponent,
			},
			{
				path        : 'member-confirm',
				component   : AgentConfirmSmartComponent,
				canActivate : [AgentConfirmGuard],
			},
			{
				path: 'dashboard',
				redirectTo: 'member-lookup',
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class MemberSearchRoutingModule { }

export const routedComponents = [
	MemberSearchComponent,
	AgentHistoryPresentationComponent,
	AgentHistorySmartComponent,
	AgentConfirmPresentationComponent,
	AgentConfirmSmartComponent,
	AgentSearchPresentationComponent,
	AgentSearchSmartComponent,
	AgentTestMembersSmartComponent,
	AgentTestMembersPresentationComponent,
];
