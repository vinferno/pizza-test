import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
}                                 from '@angular/core';
import { FormGroup }              from '@angular/forms';
import { Router }                 from '@angular/router';

import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                 from 'rxjs';
import { mergeMap, tap }          from 'rxjs/operators';

import { animator }               from '../../../../infrastructure/core/animations/animations';
import { AgentsDashboardService } from '../../utils/agent-dashboard.service';
import {
	AgentConfirmMember,
	AgentMemberLogin,
	AgentSearchResult,
}                                 from '../../../../infrastructure/interfaces/agent';
import { AgentAuthService }       from 'app/infrastructure/auth/agent-auth.service';
import { ICompanyMembership }     from '../../../../infrastructure/interfaces/company-membership';
import { MembersService }         from '../../../../infrastructure/core/services/members.service';
import { SessionState }           from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }          from '../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }           from '../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns }           from 'app/infrastructure/interfaces/table-columns';
import { ListItem } 			  from 'app/infrastructure/interfaces/list-item';

@Component({
	selector        : 'hg-confirm-smart',
	template        :
		`<hg-confirm-presentation
			*ngIf="selectedMember && agentConfirmMember"
			[agentConfirmMember]="agentConfirmMember"
			[columnList]="columnList"
			[emailForm]="emailForm"
			[loggingIn]="loggingIn"
			[selectedMemberGridView]="selectedMemberGridView"
			[session]="session"
			[settings]="(settingsState$ | async)"
			[agentConfirmMemberCompanyDetail]="agentConfirmMemberCompanyDetail"
			(emitConfirmMember)="confirmMember()"
		></hg-confirm-presentation>`,
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentConfirmSmartComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public agentDashboardForm: FormGroup;
	public columnList: TableColumns[] = [
		{
			columnName: 'SSN',
			columnId  : 'ssn',
		},
		{
			columnName: 'Name',
			columnId  : 'memberName',
		},
		{
			columnName: 'Company',
			columnId  : 'companyName',
		},
		{
			columnName: 'Birth Date',
			columnId  : 'birthDate',
		},
	];
	public selectedMember: AgentSearchResult;
	public selectedMemberGridView: AgentSearchResult[] = [];
	public agentConfirmMember: AgentConfirmMember;
	public agentConfirmMemberCompanyDetail: ListItem[] = [];
	public emailForm: FormGroup;
	public loggingIn: boolean = false;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private agentDashboardService: AgentsDashboardService,
		private agentAuthService: AgentAuthService,
		private membersService: MembersService,
		private router: Router,
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
		this.agentDashboardForm = this.agentDashboardService.agentDashboardForm;
		this.selectedMember = this.agentDashboardForm.value.selectedMember;
		this.selectedMemberGridView.push(this.selectedMember);
		if (this.selectedMemberGridView.length) {
			this.addPayrollNumberToGrid(this.selectedMemberGridView);
		}
		this.agentConfirmMember = this.agentDashboardForm.value.agentConfirmMember;
		this.emailForm = this.agentDashboardForm.get('emailForm') as FormGroup;
		this.buildMemberCompanyDetailList();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public confirmMember(): void {
		if (this.emailForm) {
			this.selectedMember.homeEmail = this.emailForm.get('email').value;
			if (this.emailForm.get('callerID')) {
				const callerID = this.emailForm.get('callerID').value;
				this.store.dispatch(stateActions.sessionActions.updateAgent({ callerID }));
			}
		} else {
			this.selectedMember.homeEmail = '';
		}
		const payload: AgentMemberLogin = {
			systemNumber: this.selectedMember.systemNumber,
			homeEmail   : this.selectedMember.homeEmail,
			agentID     : this.session.agent.agentID,
		};
		this.loggingIn = true;

		this.membersService.confirm(payload)
		.pipe(
			mergeMap(() => this.agentAuthService.setMembership(this.selectedMember.systemNumber)),
			tap(() => {
				this.agentDashboardService.clearForm([this.agentDashboardForm, this.agentDashboardService.memberSearchFormState.value, this.emailForm]);
				this.loggingIn = false;
				const selectedMember: ICompanyMembership = {
					systemNumber      : this.selectedMember.systemNumber,
					memberName        : this.selectedMember.memberName,
					companyName       : this.selectedMember.companyName,
					isVerified        : this.selectedMember.isVerified,
				};
				this.store.dispatch(stateActions.sessionActions.updateSelectedMember({ selectedMember }));
				this.router.navigateByUrl('/dashboard');
				this.store.dispatch(stateActions.sessionActions.updateMemberList({ memberList: [selectedMember] }));
			}),
		)
		.subscribe(() => { }, error => { this.loggingIn = false; });
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
	}

	private addPayrollNumberToGrid(selectedMemberGridView: AgentSearchResult[]): void {
		if (selectedMemberGridView.some(selectedMember => Boolean(selectedMember.payrollNumber))) {
			const payrollNumber: TableColumns = {
				columnName: 'Payroll Number',
				columnId  : 'payrollNumber',
			};
			this.columnList.push(payrollNumber);
		}
	}

	private buildMemberCompanyDetailList(): void {
		if (this.agentConfirmMember.divisionCaption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.divisionCaption,
				value: this.agentConfirmMember.division,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.locationCaption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.locationCaption,
				value: this.agentConfirmMember.location,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.employmentStatus !== '') {
			const newListItem: ListItem = {
				text: 'Employment Status',
				value: this.agentConfirmMember.employmentStatus,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.eeClass1Caption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.eeClass1Caption,
				value: this.agentConfirmMember.eeClass1,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.eeClass2Caption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.eeClass2Caption,
				value: this.agentConfirmMember.eeClass2,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.eeClass3Caption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.eeClass3Caption,
				value: this.agentConfirmMember.eeClass3,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.eeClass4Caption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.eeClass4Caption,
				value: this.agentConfirmMember.eeClass4,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
		if (this.agentConfirmMember.eeClass5Caption !== '') {
			const newListItem: ListItem = {
				text: this.agentConfirmMember.eeClass5Caption,
				value: this.agentConfirmMember.eeClass5,
			}
			this.agentConfirmMemberCompanyDetail.push(newListItem);
		}
	}
}
