import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                        from '@angular/core';
import { Location }      from '@angular/common';
import { FormGroup }     from '@angular/forms';

import {
	AgentConfirmMember,
	AgentSearchResult,
}                        from 'app/infrastructure/interfaces/agent';
import { animator }      from '../../../../infrastructure/core/animations/animations';
import { SessionState }  from 'app/infrastructure/store/reducers/session/session-state';
import { SettingsState } from 'app/infrastructure/store/reducers/settings/settings-state';
import { TableColumns }  from 'app/infrastructure/interfaces/table-columns';
import { ListItem } 	 from 'app/infrastructure/interfaces/list-item';

@Component({
	selector        : 'hg-confirm-presentation',
	templateUrl     : './agent-confirm-presentation.component.html',
	styleUrls       : ['./agent-confirm-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentConfirmPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public agentConfirmMember: AgentConfirmMember;
	@Input() public columnList: TableColumns[];
	@Input() public emailForm: FormGroup;
	@Input() public loggingIn: boolean;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;
	@Input() public selectedMemberGridView: AgentSearchResult[];
	@Input() public agentConfirmMemberCompanyDetail: ListItem[];
	@Output() public emitConfirmMember: EventEmitter<void> = new EventEmitter();

	constructor (private _location: Location) { }

	public confirmMember(): void {
		this.emitConfirmMember.emit();
	}

	public back(): void {
		this._location.back();
	}
}
