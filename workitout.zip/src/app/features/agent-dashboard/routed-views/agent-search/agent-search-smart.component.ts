import {
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                 from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                                 from '@angular/forms';
import { Router }                 from '@angular/router';

import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subject,
	Subscription,
}                                 from 'rxjs';
import {
	debounceTime,
	exhaustMap,
	map,
	mergeMap,
	tap,
}                                 from 'rxjs/operators';

import {
	AgentCompany,
	AgentConfirmMember,
	AgentSearchPayload,
	AgentSearchResult,
}                                 from '../../../../infrastructure/interfaces/agent';
import { AgentsDashboardService } from '../../utils/agent-dashboard.service';
import { animator }               from '../../../../infrastructure/core/animations/animations';
import { Constants }              from '../../../../infrastructure/utils/constants';
import { FormControlMap }         from '../../../../infrastructure/interfaces/form';
import { FormService }            from '../../../../infrastructure/shared/controls/form/form.service';
import { MembersService }         from '../../../../infrastructure/core/services/members.service';
import { stateActions }           from '../../../../infrastructure/store/reducers/reducers-index';
import { SessionState }           from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }          from '../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from '../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-search-smart',
	template        :
		`<hg-search-presentation
			[session]="session"
			[settings]="settingsState$ | async"
			[columnList]="columnList"
			[emptyGridMessage]="emptyGridMessage"
			[companySelectForm]="companySelectForm"
			[memberSearchForm]="memberSearchForm"
			[agentSearchResults]="agentSearchResults"
			[disableInput]="disableInput()"
			(emitStartSearch)="startSearch($event)"
			(emitAddMember)="subject$.next($event)"
		></hg-search-presentation>`,
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentSearchSmartComponent implements OnInit, OnDestroy {
	public agentConfirmMember: AgentConfirmMember;
	public agentSearchResults: AgentSearchResult[] = [];
	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId  : 'memberName',
		},
		{
			columnName: 'Company',
			columnId  : 'companyName',
		},
		{
			columnName: 'Last 4 SSN',
			columnId  : 'ssn',
			width     : 100,
		},
	];
	public customHelp: string = `
		Counselors, search for a Member below using the autocomplete text box by typing the SSN, name, or other Member information.
		Select the Member from the returned result set. You will have the chance to confirm the Member on the next panel.
	`;
	public emptyGridMessage: string = 'No search results.';
	public genericError: string;
	public companySelectForm: FormGroup;
	public memberSearchForm: FormGroup;
	public selectedCompany: AgentCompany = new AgentCompany();
	public selectedMember: AgentSearchResult = null;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;
	public subject$ = new Subject<AgentSearchResult>();

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private agentDashboardService: AgentsDashboardService,
		private fb: FormBuilder,
		private formService: FormService,
		private membersService: MembersService,
		private router: Router,
		private store: Store<any>,
	) {
		this.initializeForms();
	}

	public ngOnInit(): void {
		this.clearForm();
		this.initializeState();
		this.addMemberListener();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public startSearch(selectedCompany: AgentCompany): void {
		this.selectedCompany = selectedCompany;
		this.agentSearchResults = [];
		if (this.disableInput()) {
			const payload = {
				...this.memberSearchForm.value,
				agentID: this.session.agent.agentID,
			};
			(this.selectedCompany && this.selectedCompany.companyID)
				? payload.companyID = this.selectedCompany.companyID
				: payload.companyID = 0;
			(!payload.SystemNumberQ)
				? payload.SystemNumberQ = 0
				: payload.SystemNumberQ = Number(payload.SystemNumberQ)
					? Number(payload.SystemNumberQ)
					: 0;
			payload.SSNQ = payload.SSNQ.replace(Constants.patterns.NON_DECIMAL_DIGITS, '');
			this.searchMember(payload);
		}
	}

	private addMemberListener(): void {
		const addMemberSubscription = this.subject$
			.pipe(
				tap(member => {
					this.selectedMember = member;
					this.agentDashboardService.agentDashboardForm.get('selectedMember').setValue(member);
				}),
				exhaustMap(() => this.membersService.getMemberConfirm(this.selectedMember.systemNumber)),
			)
			.subscribe((response) => {
				this.store.dispatch(stateActions.sessionActions.updateAgent({ callerID: null }));
				this.agentConfirmMember = response;
				this.agentDashboardService.agentDashboardForm.get('agentConfirmMember').setValue(response);
				this.agentDashboardService.agentDashboardForm.addControl('emailForm', this.buildForm());
				this.confirmMember();
			});
		this.subscriptions.push(addMemberSubscription);
	}

	public disableInput(): boolean {
		if (!this.memberSearchForm.valid) { return false; }
		for (const property in this.memberSearchForm.value) {
			if (this.memberSearchForm.value.hasOwnProperty(property)) {
				if (property !== 'IsPrimaryQ' && this.memberSearchForm.value[property]) { return true; }
			}
		}
		return false;
	}

	public confirmMember(): void {
		this.router.navigateByUrl('/counselor/member-confirm');
	}

	public isUniqueFilled(): void {
		const nameFields: string[]  = ['FirstNameQ', 'LastNameQ'];
		const nameControls: FormControlMap[] = [];
		const uniqueControls: FormControlMap[]  = [];
		const controls: FormControlMap[] = Object.keys(this.memberSearchForm.controls).map(controlName => {
			return {
				name   : controlName,
				control: this.memberSearchForm.controls[controlName],
			}
		});

		controls.forEach(control => {
			(nameFields.includes(control.name))
				? nameControls.push(control)
				: uniqueControls.push(control);
		});

		nameControls.forEach(control => this.pushToControlArray(control, uniqueControls));
		uniqueControls.forEach(control => this.pushToControlArray(control, nameControls));
	}

	private pushToControlArray(control: FormControlMap, controlList: FormControlMap[]): void {
		const controlSubscription = control.control.valueChanges
			.pipe(debounceTime(100))
			.subscribe((value) => {
				if (value) {
					controlList.forEach(unique => {
						const ctrlValue = unique.control.value;
						if (ctrlValue && typeof ctrlValue === 'string') { unique.control.setValue(''); }
					})
				}
			});
		this.subscriptions.push(controlSubscription);
	}

	private clearForm(): void {
		if (this.memberSearchForm) {
			this.agentDashboardService.clearForm([this.memberSearchForm]);
		}
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');

		if (this.memberSearchForm && (this.memberSearchForm.controls.FirstNameQ.value || this.memberSearchForm.controls.LastNameQ.value)) {
			this.selectedCompany.companyID = this.agentDashboardService.agentDashboardForm.value.companyID;
			this.startSearch(this.agentDashboardService.agentDashboardForm.value);
		} else if (this.memberSearchForm) {
			this.clearForm();
		}
	}

	private initializeForms(): void {
		const memberSearchFormSubscription = this.agentDashboardService.memberSearchFormState
			.pipe(
				map(memberSearchForm => { return this.memberSearchForm = memberSearchForm; }),
				mergeMap((memberSearchForm) => memberSearchForm.valueChanges.pipe(tap(() => this.isUniqueFilled()))))
			.subscribe();
		this.subscriptions.push(memberSearchFormSubscription);
		this.companySelectForm = this.fb.group({
			companyID: new FormControl (null),
		});
	}

	private buildForm(): FormGroup {
		const emailForm = this.fb.group({
			email: [''],
		});

		this.buildDynamicField(emailForm);

		return emailForm;
	}

	private buildDynamicField(form: FormGroup): FormGroup {
		if (this.agentConfirmMember.showCallerID) { this.formService.addFormControl(form, 'callerID', []); }

		return form;
	}

	private searchMember(payload: AgentSearchPayload): void {
		this.membersService.specify(payload).subscribe(response => {
			this.agentSearchResults = response;
		});
	}
}
