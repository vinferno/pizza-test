import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                        from '@angular/core';
import { FormGroup }     from '@angular/forms';

import {
	AgentCompany,
	AgentSearchResult,
}                        from '../../../../infrastructure/interfaces/agent';
import { animator }      from '../../../../infrastructure/core/animations/animations';
import { SessionState }  from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState } from '../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }  from '../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-test-members-presentation',
	templateUrl     : './agent-test-members-presentation.component.html',
	styleUrls       : ['./agent-test-members-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentTestMembersPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public agentSearchResults: AgentSearchResult[] = [];
	@Input() public columnList: TableColumns;
	@Input() public companySelectForm: FormGroup;
	@Input() public emptyGridMessage: string;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitStartSearch: EventEmitter<AgentCompany> = new EventEmitter();
	@Output() public emitAddMember: EventEmitter<AgentSearchResult> = new EventEmitter();

	public selectedCompany: AgentCompany;

	public startSearch(): void {
		this.emitStartSearch.emit(this.selectedCompany);
	}

	public addMember(member: AgentSearchResult): void {
		this.emitAddMember.emit(member);
	}

	public setSelectedCompany(company: AgentCompany): void {
		this.selectedCompany = company;
		this.startSearch();
	}
}
