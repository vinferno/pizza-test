import {
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                 from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                                 from '@angular/forms';
import { Router }                 from '@angular/router';

import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subject,
	Subscription,
}                                 from 'rxjs';
import { exhaustMap, tap }        from 'rxjs/operators';

import {
	AgentCompany,
	AgentConfirmMember,
	AgentSearchPayload,
	AgentSearchResult,
}                                 from '../../../../infrastructure/interfaces/agent';
import { AgentsDashboardService } from '../../utils/agent-dashboard.service';
import { animator }               from '../../../../infrastructure/core/animations/animations';
import { FormService }            from '../../../../infrastructure/shared/controls/form/form.service';
import { MembersService }         from '../../../../infrastructure/core/services/members.service';
import { stateActions }           from '../../../../infrastructure/store/reducers/reducers-index';
import { SessionState }           from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }          from '../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from '../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-test-members-smart',
	template        :
		`<hg-test-members-presentation
			[session]="session"
			[settings]="(settingsState$ | async)"
			[columnList]="columnList"
			[emptyGridMessage]="emptyGridMessage"
			[companySelectForm]="companySelectForm"
			[agentSearchResults]="agentSearchResults"
			(emitStartSearch)="startSearch($event)"
			(emitAddMember)="subject$.next($event)"
		></hg-test-members-presentation>`,
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentTestMembersSmartComponent implements OnInit, OnDestroy {
	public agentConfirmMember: AgentConfirmMember;
	public agentSearchResults: AgentSearchResult[] = [];
	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId  : 'memberName',
		},
		{
			columnName: 'Company',
			columnId  : 'companyName',
		},
		{
			columnName: 'System Number',
			columnId  : 'systemNumber',
		},
	];

	public companySelectForm: FormGroup;
	public emptyGridMessage: string = 'No search results.';
	public selectedCompany: AgentCompany = new AgentCompany();
	public selectedMember: AgentSearchResult = null;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;
	public subject$ = new Subject<AgentSearchResult>();

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private agentDashboardService: AgentsDashboardService,
		private fb: FormBuilder,
		private formService: FormService,
		private membersService: MembersService,
		private router: Router,
		private store: Store<any>,
	) {
		this.initializeForms();
	}

	public ngOnInit(): void {
		this.initializeState();
		this.addMemberListener();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public startSearch(selectedCompany: AgentCompany): void {
		const payload: AgentSearchPayload = new AgentSearchPayload();
		this.selectedCompany = selectedCompany;
		this.agentSearchResults = [];
		(this.selectedCompany && this.selectedCompany.companyID)
			? payload.companyID = this.selectedCompany.companyID
			: payload.companyID = 0;
		payload.agentID = this.session.agent.agentID;
		this.searchMember(payload);
	}

	private addMemberListener(): void {
		const addMemberSubscription = this.subject$
			.pipe(
				tap(member => {
					this.selectedMember = member;
					this.agentDashboardService.agentDashboardForm.get('selectedMember').setValue(member);
				}),
				exhaustMap(() => this.membersService.getMemberConfirm(this.selectedMember.systemNumber)),
			)
			.subscribe((response) => {
				this.store.dispatch(stateActions.sessionActions.updateAgent({ callerID: null }));
				this.agentConfirmMember = response;
				this.agentDashboardService.agentDashboardForm.get('agentConfirmMember').setValue(response);
				this.agentDashboardService.agentDashboardForm.addControl('emailForm', this.buildForm());
				this.confirmMember();
			});
		this.subscriptions.push(addMemberSubscription);
	}

	public confirmMember(): void {
		this.router.navigateByUrl('/counselor/member-confirm');
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
	}

	private initializeForms(): void {
		this.companySelectForm = this.fb.group({
			companyID: new FormControl (null),
		});
	}

	private buildForm(): FormGroup {
		const emailForm = this.fb.group({
			email: [''],
		});

		this.buildDynamicField(emailForm);

		return emailForm;
	}

	private buildDynamicField(form: FormGroup): FormGroup {
		if (this.agentConfirmMember.showCallerID) { this.formService.addFormControl(form, 'callerID', []); }

		return form;
	}

	private searchMember(payload: AgentSearchPayload): void {
		this.membersService.testMembers(payload).subscribe(response => {
			this.agentSearchResults = response;
		});
	}
}
