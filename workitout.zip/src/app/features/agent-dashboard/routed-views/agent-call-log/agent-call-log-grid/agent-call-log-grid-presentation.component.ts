import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
	Output,
	EventEmitter,
}                        from '@angular/core';

import {
	AgentCompanyCallLog,
	AgentCompanyCallLogList,
}                        from '../../../../../infrastructure/interfaces/agent-crm';
import { animator }      from '../../../../../infrastructure/core/animations/animations';
import { SettingsState } from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }  from '../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }  from '../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-call-log-grid-presentation',
	templateUrl     : './agent-call-log-grid-presentation.component.html',
	styleUrls       : ['./agent-call-log-grid-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCallLogGridPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public callLog: AgentCompanyCallLogList;
	@Input() public columnList: TableColumns[] = [];
	@Input() public editButtonLabel: string = 'Append to Note';
	@Input() public emptyGridMessage: string;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitClear = new EventEmitter<void>();
	@Output() public emitSelect = new EventEmitter<AgentCompanyCallLog>();
	@Output() public emitSpecification = new EventEmitter<AgentCompanyCallLogList>();

	public newLog: AgentCompanyCallLog = new AgentCompanyCallLog();

	constructor () { }

	public clear(): void {
		this.emitClear.emit();
	}
	public selectCell(log: AgentCompanyCallLog): void {
		this.emitSelect.emit(log);
	}

	public specifyCallLog(callLog: AgentCompanyCallLogList): void {
		this.emitSpecification.emit(callLog);
	}
}
