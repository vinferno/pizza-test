import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
}                           from '@angular/core';
import {
	ActivatedRoute,
	Router,
}                           from '@angular/router';

import { Store }            from '@ngrx/store';
import { Observable }       from 'rxjs';

import {
	AgentCompanyCallLog,
	AgentCompanyCallLogList,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService } from '../../../utils/agents-crm.service';
import { MaskService }      from '../../../../../infrastructure/core/services/mask.service';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }    from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }     from '../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns }     from '../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-call-log-grid',
	template        :
		`<div class="page">
			<hg-call-log-grid-presentation
				[callLog]="callLog"
				[columnList]="columnList"
				[editButtonLabel]="editButtonLabel"
				[emptyGridMessage]="emptyGridMessage"
				[session]="(sessionState$ | async)"
				[settings]="(settingsState$ | async)"
				(emitClear)="clearSearchFilter()"
				(emitSelect)="navigateToDetailPage($event)"
				(emitSpecification)="updateCallLogGrid($event)"
			></hg-call-log-grid-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCallLogGridSmartComponent implements OnInit {
	public callLog: AgentCompanyCallLogList;
	public columnList: TableColumns[] = [
		{
			columnName : 'Company',
			columnId   : 'companyName',
		},
		{
			columnName : 'Call Type',
			columnId   : 'callType',
		},
		{
			columnName : 'Caller First Name',
			columnId   : 'callerFirstName',
		},
		{
			columnName : 'Caller Last Name',
			columnId   : 'callerLastName',
		},
		{
			columnName : 'Phone Number',
			columnId   : 'callNumber',
			width      : 120,
		},
		{
			columnName : 'Last Updated',
			columnId   : 'lastUpdated',
			width      : 120,
		},
		{
			columnName : 'Counselor Name',
			columnId   : 'agentName',
		},
	];
	public editButtonLabel: string = 'Append to Note';
	public emptyGridMessage: string = 'No call log currently available.';
	public sessionState$: Observable<SessionState>;
	public settingsState$: Observable<SettingsState>;

	constructor (
		private agentsCRMService: AgentsCRMService,
		public maskService: MaskService,
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		this.formatCallNumber(this.route.snapshot.data['callLog']);
	}

	ngOnInit() {
		this.initializeState();
	}

	public navigateToDetailPage(cell: AgentCompanyCallLog) {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ agentCallLog: cell }));
		this.router.navigate(['counselor/call-log-detail']);
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		this.settingsState$ = this.store.select('settingsState');
	}

	private formatCallNumber(callLogList: AgentCompanyCallLogList): AgentCompanyCallLogList {
		callLogList.companyCallLog.forEach((log: AgentCompanyCallLog) => {
			log.callNumber = this.maskService.phoneFormatInbound(log.callNumber);
		});

		return this.callLog = callLogList;
	}

	public updateCallLogGrid(callLog: AgentCompanyCallLogList): void {
		this.formatCallNumber(callLog);
	}

	public clearSearchFilter(): void {
		this.agentsCRMService.getCallLog().subscribe(response => this.formatCallNumber(response));
	}
}
