import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                              from '@angular/core';
import { FormGroup }           from '@angular/forms';

import { AgentCompany }        from '../../../../../infrastructure/interfaces/agent';
import { AgentCompanyCallLog } from '../../../../../infrastructure/interfaces/agent-crm';
import { animator }            from '../../../../../infrastructure/core/animations/animations';
import { SettingsState }       from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }        from '../../../../../infrastructure/store/reducers/session/session-state';

@Component({
	selector        : 'hg-call-log-detail-presentation',
	templateUrl     : './agent-call-log-detail-presentation.component.html',
	styleUrls       : ['./agent-call-log-detail-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCallLogDetailPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public callLog: AgentCompanyCallLog;
	@Input() public form: FormGroup;
	@Input() public hasCallLogID: boolean = false;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitSelectCompany: EventEmitter<AgentCompany> = new EventEmitter();
	@Output() public emitSave = new EventEmitter<FormGroup>();

	public setSelectedCompany(company: AgentCompany): void {
		this.emitSelectCompany.emit(company);
	}

	public save(): void {
		this.emitSave.emit(this.form);
	}
}
