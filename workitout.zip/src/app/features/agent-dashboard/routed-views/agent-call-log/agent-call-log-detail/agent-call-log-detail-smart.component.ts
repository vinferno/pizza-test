import {
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                               from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
	Validators,
}                               from '@angular/forms';
import {
	ActivatedRoute,
	Router,
}                               from '@angular/router';

import { Store }                from '@ngrx/store';
import { Observable }           from 'rxjs';

import { AgentCompany }         from '../../../../../infrastructure/interfaces/agent';
import {
	AgentCompanyAppendCallLogPayload,
	AgentCompanyCallLog,
	AgentCompanyCallLogPayload,
}                               from '../../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService }     from '../../../utils/agents-crm.service';
import { Constants }            from '../../../../../infrastructure/utils/constants';
import { MaskService }          from '../../../../../infrastructure/core/services/mask.service';
import { SessionState }         from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }        from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }         from '../../../../../infrastructure/store/reducers/reducers-index';
import { ValidationIsRequired } from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-call-log-detail',
	template        :
		`<div class="page">
			<hg-call-log-detail-presentation
				[callLog]="callLog"
				[form]="form"
				[hasCallLogID]="hasCallLogID()"
				[session]="(sessionState$ | async)"
				[settings]="(settingsState$ | async)"
				(emitSelectCompany)="selectCompany($event)"
				(emitSave)="save()"
			></hg-call-log-detail-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCallLogDetailSmartComponent implements OnInit, OnDestroy {
	public callLog: AgentCompanyCallLog;
	public form: FormGroup;
	public sessionState$: Observable<SessionState>;
	public settingsState$: Observable<SettingsState>;

	private company: AgentCompany = null;
	private payload: AgentCompanyAppendCallLogPayload | AgentCompanyCallLogPayload;

	constructor (
		private agentsCRMService: AgentsCRMService,
		private fb: FormBuilder,
		public maskService: MaskService,
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		this.callLog = this.route.snapshot.data['callLog'];
	}

	public ngOnInit(): void {
		this.initializeState();
		this.form = this.buildForm();
	}

	public ngOnDestroy(): void {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ agentCallLog: null }));
	}

	public selectCompany(company: AgentCompany): void {
		if (company) {
			this.company = company;
		} else {
			this.form.get('companyID').setValue(null);
			this.company = null;
		}
	}

	public save(): void {
		if (this.hasCallLogID()) {
			this.payload = new AgentCompanyAppendCallLogPayload();
			this.buildPayload(this.payload);
			this.appendCallLog();
		} else {
			this.payload = new AgentCompanyCallLogPayload();
			this.buildPayload(this.payload);
			this.createCallLog();
		}
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		this.settingsState$ = this.store.select('settingsState');
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			companyID: new FormControl ({value: this.callLog.companyName, disabled: this.hasCallLogID()},  Validators.compose([Validators.required])),
			callType: new FormControl ({value: this.callLog.callType, disabled: this.hasCallLogID()}),
			callNote: new FormControl ({value: this.callLog.callNote, disabled: this.hasCallLogID()}, ValidationIsRequired.isRequired('Note')),
			callerFirstName: new FormControl ({value: this.callLog.callerFirstName, disabled: this.hasCallLogID()}),
			callerLastName: new FormControl ({value: this.callLog.callerLastName, disabled: this.hasCallLogID()}),
			callNumber: new FormControl ({value: this.maskService.phoneFormatInbound(this.callLog.callNumber), disabled: this.hasCallLogID()}),
		});

		if (this.hasCallLogID()) {
			form.addControl('callLogID', new FormControl(this.callLog.callLogID));
			form.addControl('appendCallNote', new FormControl('', ValidationIsRequired.isRequired('Appended Note')));
		}

		return form;
	}

	private buildPayload(payload: AgentCompanyCallLogPayload | AgentCompanyAppendCallLogPayload): AgentCompanyCallLogPayload | AgentCompanyAppendCallLogPayload {
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				switch (property) {
					case 'companyID':
						payload[property] = (this.company) ? this.company.companyID : Constants.emptyInt;
						break;
					case 'callNumber':
						payload[property] = this.form.controls[property].value.replace(Constants.patterns.NON_DECIMAL_DIGITS, '');
						break;
					default:
						payload[property] = this.form.controls[property].value;
						break;
				}
			}
		}

		return payload;
	}

	private createCallLog(): void {
		this.agentsCRMService.createCallLog(<AgentCompanyCallLogPayload>this.payload)
			.subscribe(() => this.router.navigate(['counselor/call-log']));
	}

	private appendCallLog(): void {
		this.agentsCRMService.appendCallLog(<AgentCompanyAppendCallLogPayload>this.payload)
			.subscribe(() => this.router.navigate(['counselor/call-log']));
	}

	public hasCallLogID(): boolean {
		return this.callLog.callLogID && this.callLog.callLogID !== Constants.emptyInt;
	}
}
