import { NgModule }                                from '@angular/core';
import { RouterModule, Routes }                    from '@angular/router';

import { AgentDashboardGuard }                     from '../../utils/guards/agent-dashboard.guard';
import { agentDashboardResolvers }                 from '../../utils/resolvers/agent-dashboard/agent-dashboard-resolvers';
import { AgentCallLogComponent }                   from './agent-call-log.component';
import { AgentCallLogGridPresentationComponent }   from './agent-call-log-grid/agent-call-log-grid-presentation.component';
import { AgentCallLogGridSmartComponent }          from './agent-call-log-grid/agent-call-log-grid-smart.component';
import { AgentCallLogDetailPresentationComponent } from './agent-call-log-detail/agent-call-log-detail-presentation.component';
import { AgentCallLogDetailSmartComponent }        from './agent-call-log-detail/agent-call-log-detail-smart.component';
import { TitleResolver }                           from '../../../../infrastructure/core/resolvers/title.resolver';

const routes: Routes = [
	{
		path       : '',
		component  : AgentCallLogComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path     : 'call-log',
				component: AgentCallLogGridSmartComponent,
				resolve  : {
					callLog: agentDashboardResolvers.AgentCallLogResolver,
				},
			},
			{
				path     : 'call-log-detail',
				component: AgentCallLogDetailSmartComponent,
				resolve  : {
					callLog: agentDashboardResolvers.AgentCallLogDetailResolver,
				},
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class AgentCallLogRoutingModule { }

export const routedComponents = [
	AgentCallLogComponent,
	AgentCallLogGridPresentationComponent,
	AgentCallLogGridSmartComponent,
	AgentCallLogDetailPresentationComponent,
	AgentCallLogDetailSmartComponent,
];
