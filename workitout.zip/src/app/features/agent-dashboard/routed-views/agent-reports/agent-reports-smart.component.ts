import {
	ChangeDetectorRef,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
}									from '@angular/core';
import {
	DomSanitizer,
	SafeResourceUrl,
} 									from '@angular/platform-browser';
import { ActivatedRoute, Router } 	from '@angular/router';
import { MatDialog } 			  	from '@angular/material/dialog';
import { Store }                  	from '@ngrx/store';

import { stateActions }           	from '../../../../infrastructure/store/reducers/reducers-index';
import { animator }               	from '../../../../infrastructure/core/animations/animations';
import { ModalService }           	from '../../../../infrastructure/core/services/modal.service';
import { TableColumns }				from '../../../../infrastructure/interfaces/table-columns';

import { AgentsDashboardService } 	from '../../utils/agent-dashboard.service';
import { environment }              from 'environments/environment';


@Component({
	selector   : 'hg-reports',
	templateUrl: './agent-reports-smart.component.html',
	styleUrls  : ['./agent-reports-smart.component.scss'],
	animations : [animator.slide],
})
export class AgentReportsSmartComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public session;
	public sessionState;
	public settings;
	public reports;
	public reportHistory;
	public recentReports;
	public reportsState;
	public subscriptions = [];

	// Refactor naming conventions
	public downloadUrl: SafeResourceUrl = null;
	public selectedReport;
	public selectedDivision;
	public selectedSelect;
	public displayedColumns: TableColumns[] = [
		{
			columnName: 'File Name',
			columnId  : 'name',
		},
		{
			columnName: 'Category',
			columnId  : 'category',
		},
		{
			columnName: 'Date Created',
			columnId  : 'createdDate',
		},

	];

	constructor (
		private agentsDashboardService: AgentsDashboardService,
		private cd: ChangeDetectorRef,
		private store: Store<any>,
		public dialog: MatDialog,
		public modals: ModalService,
		public router: Router,
		public route: ActivatedRoute,
	) {
	}

	ngOnInit() {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSub);
		this.agentsDashboardService.getReports().subscribe(reports => this.reports = this.unpackReports(reports));
		const reportStateSub = this.store.select('reportsState').subscribe(reportsState => {
			this.reportsState = reportsState;
		});
		this.subscriptions.push(reportStateSub);
	}

	ngOnDestroy() {
		this.store.dispatch(stateActions.reportsActions.updateOptions(null));
		this.subscriptions.forEach(sub => sub.unsubscribe())
	}

	unpackReports(value: any, args: any[] = null): any {
		if (!value) {
			return []
		}
		return Object.keys(value)
					 .map(key => {
						 return {
							 key,
							 value: value[key],
						 }
					 });
	}

	public openDialog(): void {
		this.goToBuilder(this.selectedReport);
	}

	public goToBuilder(report) {
		this.store.dispatch(stateActions.reportsActions.updateReport(report));
		this.router.navigateByUrl(`/counselor/reports/report-builder/${report.reportID}`);
	}

	public splitWords (string) {
		const resultArray = [];

		string.split('').forEach(letter => {
			if (letter === letter.toUpperCase()) {
				if (resultArray.length) {
					resultArray.push(' ');
				}
				resultArray.push(letter);
			} else {
				resultArray.push(letter.toLowerCase());
			}
		});

		resultArray[0] = resultArray[0].toUpperCase();

		return resultArray.join('');
	}

	public resetSelects (myInstance) {
		if (this.selectedSelect) {
			this.selectedSelect.value = null;
		}
		this.selectedSelect = myInstance;
	}

	public setSelectedReport (report, division) {
		this.selectedDivision = division;
		this.selectedReport = report;
	}

	public permissionReports (division) {
		const supervisor = this.session.agent.isSupervisor || this.session.agent.isAdministrator;
		const administrator = this.session.agent.isAdministrator;
		if (division.key === 'supervisorReports' && !supervisor) {
			return false;
		}
		if (division.key === 'administratorReports' && !administrator) {
			return false;
		}
		return true;
	}
}
