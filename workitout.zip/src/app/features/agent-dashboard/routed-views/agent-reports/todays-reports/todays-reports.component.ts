import {
	Component,
	OnInit,
	OnDestroy,
}									from '@angular/core';
import {
	DomSanitizer,
	SafeResourceUrl,
} 									from '@angular/platform-browser';
import { interval }					from 'rxjs';
import { Store }                  	from '@ngrx/store';

import { TableColumns }				from '../../../../../infrastructure/interfaces/table-columns';

import { AgentsDashboardService } 	from '../../../utils/agent-dashboard.service';
import { environment }              from 'environments/environment';

@Component({
    selector        : 'hg-todays-reports',
    templateUrl     : './todays-reports.component.html',
    styleUrls       : ['./todays-reports.component.scss'],
})
export class AgentTodaysReportsComponent implements OnInit, OnDestroy {
    public recentReports;
	public session;
    public settings;

    public displayedColumns: TableColumns[] = [
		{
			columnName: 'File Name',
			columnId  : 'name',
		},
		{
			columnName: 'Category',
			columnId  : 'category',
		},
		{
			columnName: 'Date Created',
			columnId  : 'createdDate',
		},
    ];
    public downloadUrl: SafeResourceUrl = null;
    public subscriptions = [];

    constructor(
        private agentsDashboardService: AgentsDashboardService,
        private store: Store<any>,
        private sanitizer: DomSanitizer,
    ) {
    }

    public ngOnInit(): void {
        const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSub);
		const intervalCheck = interval(10000).subscribe(() => {
			this.getRecentReports();
		});
		this.subscriptions.push(intervalCheck);
        this.getRecentReports();
	}

	public ngOnDestroy() {
		this.subscriptions.forEach(sub => sub.unsubscribe())
	}

	public getRecentReports() {
		let tempReports;
        this.agentsDashboardService.getRecentReports()
			.subscribe(recentReports => {
				tempReports = recentReports.reports.map(report => {
					report.status = this.statusLookup(report.status);
					return report;
				});

				if (JSON.stringify(tempReports) !== JSON.stringify(this.recentReports)) {
					this.recentReports = tempReports;
				}
			});
	}

    public statusLookup(status) {
		if (status.toLowerCase() === 's') {
			return 'Submitted';
		}
		if (status.toLowerCase() === 'e') {
			return 'Executing';
		}
		if (status.toLowerCase() === 'c') {
			return 'Completed';
		}
		if (status.toLowerCase() === 'f') {
			return 'Failed';
		}
	}

    public downloadAgentReport (cell: any): void {
		const id = cell.reportID;
		const fingerprint = this.session.fingerprint;
		if (id && fingerprint) {
			const url = `${environment.apiRoute}/content/downloads/agentReport?id=${id}&fp=${fingerprint}`;
			this.downloadUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
		}
	}
}
