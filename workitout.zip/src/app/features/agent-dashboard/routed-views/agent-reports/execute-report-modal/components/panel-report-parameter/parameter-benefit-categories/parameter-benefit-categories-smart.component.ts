import {
	ChangeDetectorRef,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
}                           from '@angular/core';
import { Store }            from '@ngrx/store';
import { AgentsCRMService } from '../../../../../../utils/agents-crm.service';
import { stateActions }     from '../../../../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns } 	from '../../../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector   : 'hg-parameter-benefit-categories-smart',
	templateUrl: './parameter-benefit-categories-smart.component.html',
	styleUrls  : ['./parameter-benefit-categories-smart.component.scss'],

})
export class ParameterBenefitCategoriesSmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input() public form;
	@Input() public options;

	@Output() public nextPanel = new EventEmitter();
	@Output() public endNavigationEmit = new EventEmitter();

	public benefitGrid;
	public currentSelection = [];
	public lastSelection = null;
	public reports;
	public selected = [];
	public selectedIndexes = [];
	public selectedObject = {};
	public selectedRows = [];
	public selectMode;
	public session;
	public settings;
	public subscriptions = [];
	public uniqueIds = [];

	public displayedColumns: TableColumns[] = [
		{
			columnName : 'Enrollment',
			columnId   : 'description',
		},
	];

	constructor (
		private store: Store<any>,
		public agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
	) {}

	ngOnInit () {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);

		const reportsSub = this.store.select('reportsState').subscribe( reports => {
			this.reports = reports;
		});
		this.subscriptions.push(reportsSub);

		this.selectedIndexes = this.reports.options.parameters.parameterDetails.filter( item => item.selected);
		this.selectMode = this.reports.options.parameters.parameterDetailsSingleSelect ? 'single' : 'multiple';

		this.store.dispatch(stateActions.stepperActions.updateSecondary('Benefit Categories'));
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public doneEmit () {
	}

	public goTo (paramID) {
	}

	public isPanelValid(): boolean {
		return this.currentSelection.length > 0;
	}

	public submit() {
		const payload = {
			reportParameterID: this.reports.options.parameters.parameterID,
			selectedValue: this.currentSelection.map( item => item.value).join(','),
		};
		this.agentsCRMService.postParameter(payload).subscribe( (response: any) => {
			if (response.nextPanel.value === 'Parameters') {
				this.agentsCRMService.getParameter().subscribe( getParams => {
					this.store.dispatch(stateActions.reportsActions.updateOptions({parameters: getParams}));
					this.nextPanel.emit({response: getParams} )
				})
			} else {
				this.endNavigationEmit.emit({current: 'Benefit Categories', response: response} )
			}
		});
	}

	dataGridChange(grid, event) {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		grid.selectedRowKeysChange.subscribe((rows) => {
			if (this.selectMode === 'single') {
				if (rows.length === 1) {
					this.lastSelection = rows[0];
				}
				if (rows.length === 2) {
					rows.splice(rows.indexOf(this.lastSelection), 1);
					this.benefitGrid.selectRows(rows);
				}
				if (rows.length > 2) {
					this.benefitGrid.selectRows([]);
				}
			} else {
				// This should be used for required fields. Right now leaving this here.
				this.benefitGrid.selectRows(rows.concat(this.selectedIndexes));
			}

			this.uniqueIds = rows.map(row => {
				return row.uniqueID;
			});

			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}

}
