import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
} from '@angular/core';

@Component({
	selector   : 'hg-panel-report-details-presentation',
	templateUrl: './panel-report-details-presentation.component.html',
	styleUrls  : ['./panel-report-details-presentation.component.scss'],

	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PanelReportDetailsPresentationComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input()
	public settings;
	@Input()
	public session;

	@Output()
	public submitEmit: EventEmitter<any> = new EventEmitter<any>();

	@Input()
	public form;
	@Input()
	public options;

	constructor () {
	}

	ngOnInit () {
	}

	ngOnDestroy () {
	}

	public submit () {
		const event = {};
		this.submitEmit.emit(event);
	}

}

