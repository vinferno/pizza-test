import { Component, HostBinding, Input, OnDestroy, OnInit } from '@angular/core';
import { Store }                                            from '@ngrx/store';
import { TableColumns }                                     from '../../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector   : 'hg-agent-report-benefit-categories-smart',
	templateUrl: './agent-report-benefit-categories-smart.component.html',
	styleUrls  : ['./agent-report-benefit-categories-smart.component.scss'],

})
export class AgentReportBenefitCategoriesSmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	public subscriptions = [];
	public session;
	public settings;

	@Input()
	public form;
	public benefitCategories = [{name: 'test benefit'}];
	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Name',
			columnId  : 'name',
		},
	];

	constructor (
		private store: Store<any>,
	) {}

	ngOnInit () {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit () {
	}

}
