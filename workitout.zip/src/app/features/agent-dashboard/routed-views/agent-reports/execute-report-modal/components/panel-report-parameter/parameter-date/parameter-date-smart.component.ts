import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
}                           from '@angular/core';
import { Store }            from '@ngrx/store';
import { AgentsCRMService } from '../../../../../../utils/agents-crm.service';
import { stateActions }     from '../../../../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns } 	from '../../../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector   : 'hg-parameter-date-smart',
	templateUrl: './parameter-date-smart.component.html',
	styleUrls  : ['./parameter-date-smart.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ParameterDateSmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input() public form;
	@Input() public options;

	@Output() public nextPanel = new EventEmitter();
	@Output() public endNavigationEmit = new EventEmitter();

	public benefitGrid;
	public currentSelection = [];
	public lastSelection = null;
	public reports;
	public selected = [];
	public selectedIndexes = [];
	public selectedObject = {};
	public selectedRows = [];
	public selectMode;
	public session;
	public settings;
	public subscriptions = [];
	public uniqueIds = [];

	public displayedColumns: TableColumns[] = [
		{
			columnName : 'Enrollment',
			columnId   : 'description',
		},
	];

	constructor (
		private store: Store<any>,
		public agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
	) {}

	ngOnInit () {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);

		const reportsSub = this.store.select('reportsState').subscribe( reports => {
			this.reports = reports;
		});
		this.subscriptions.push(reportsSub);
		this.store.dispatch(stateActions.stepperActions.updateSecondary('Date'));
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public isPanelValid(): boolean {
		if (this.form.fg.get('date') === null) {
			return false;
		}
		return !!this.form.fg.get('date').value;
	}

	public submit() {
		const payload = {
			selectedValue: this.form.fg.value.date.toISOString().split('T')[0],
			reportParameterID: this.reports.options.parameters.parameterID,
		};
		this.agentsCRMService.postParameter(payload).subscribe( (response: any) => {
			if (response.nextPanel.value === 'Parameters') {
				this.agentsCRMService.getParameter().subscribe( getParams => {
					this.store.dispatch(stateActions.reportsActions.updateOptions({parameters: getParams}));
					this.nextPanel.emit({response: getParams} )
				});
			} else {
				this.endNavigationEmit.emit({current: 'Date', response: response} )
			}
		});

	}

}
