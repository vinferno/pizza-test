import {
	ChangeDetectorRef,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
} 								from '@angular/core';
import { Store }				from '@ngrx/store';
import { AgentsCRMService }     from '../../../../../../utils/agents-crm.service';
import { stateActions }         from '../../../../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns } 		from '../../../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector   : 'hg-parameter-open-enrollment-smart',
	templateUrl: './parameter-open-enrollment-smart.component.html',
	styleUrls  : ['./parameter-open-enrollment-smart.component.scss'],

})
export class ParameterOpenEnrollmentSmartComponent implements OnInit, OnDestroy {
	@HostBinding('style.display') display = 'block';

	@Input() public form;

	@Output() public nextPanel = new EventEmitter();
	@Output() public endNavigationEmit = new EventEmitter();

	public benefitGrid;
	public currentSelection = [];
	public lastSelection = null;
	public reports;
	public selected = [];
	public selectedIndexes = [];
	public selectMode;
	public selectedObject = {};
	public selectedRows = [];
	public session;
	public settings;
	public subscriptions = [];
	public uniqueIds = [];

	public displayedColumns: TableColumns[] = [
		{
			columnName : 'Enrollment',
			columnId   : 'description',
		},
	];

	constructor (
		private cd: ChangeDetectorRef,
		private store: Store<any>,
		public agentsCRMService: AgentsCRMService,
	) {}

	ngOnInit () {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSub);
		const reportsSub = this.store.select('reportsState').subscribe(reports => {
			this.reports = reports;
			this.cd.detectChanges();
		});
		this.subscriptions.push(reportsSub);
		if (this.reports.options.parameters.parameterDetails) {
			this.selectedIndexes = this.reports.options.parameters.parameterDetails.filter( item => item.selected);
		}
		this.selectMode = this.reports.options.parameters.parameterDetailsSingleSelect ? 'single' : 'multiple';
		if (this.reports.options.parameters &&
			this.reports.options.parameters.previousTabs &&
			this.reports.options.parameters.previousTabs[0]
		) {
			this.agentsCRMService.postParameterById({
				reportParameterID: this.reports.options.parameters.previousTabs[0].parameterID,
			}).subscribe( (response) => {
				this.store.dispatch(stateActions.reportsActions.updateOptions({ parameters: response }));
			});
		}
		this.store.dispatch(stateActions.stepperActions.updateSecondary('Open Enrollment'));
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit() {
		const payload = {
			reportParameterID: this.reports.options.parameters.parameterID,
			selectedValue: this.currentSelection.map( item => item.value).join(','),
		};
		this.agentsCRMService.postParameter(payload).subscribe( (response: any) => {
			if (response.nextPanel.value === 'Parameters') {
				this.agentsCRMService.getParameter().subscribe( getParams => {
					this.store.dispatch(stateActions.reportsActions.updateOptions({parameters: getParams}));
					this.nextPanel.emit({response: getParams} )
				})
			} else {
				this.endNavigationEmit.emit({current: 'Open Enrollment', response: response} )
			}
		});
	}

	public isPanelValid(): boolean {
		return this.currentSelection.length > 0;
	}

	dataGridChange(grid, event) {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		grid.selectedRowKeysChange.subscribe((rows) => {
			if (this.selectMode === 'single') {
				if (rows.length === 1) {
					this.lastSelection = rows[0];
				}
				if (rows.length === 2) {
					rows.splice(rows.indexOf(this.lastSelection), 1);
					this.benefitGrid.selectRows(rows);
				}
				if (rows.length > 2) {

					this.benefitGrid.selectRows([]);
				}
			} else {
				this.benefitGrid.selectRows(rows.concat(this.selectedIndexes));
			}

			this.uniqueIds = rows.map(row => {
				return row.uniqueID;
			});

			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}

}
