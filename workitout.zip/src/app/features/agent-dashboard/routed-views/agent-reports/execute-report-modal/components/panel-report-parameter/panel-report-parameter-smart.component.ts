import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
} 								from '@angular/core';
import { Store }				from '@ngrx/store';

import { AgentsCRMService }     from '../../../../../utils/agents-crm.service';
import { stateActions }         from '../../../../../../../infrastructure/store/reducers/reducers-index';
import { FormContentBase }  	from '../../../../../../../infrastructure/core/classes/form-wizard';
import { ApiService }       	from '../../../../../../../infrastructure/core/api/api.service';
@Component({
	selector   : 'hg-panel-report-parameter-smart',
	templateUrl: './panel-report-parameter-smart.component.html',
	styleUrls  : ['./panel-report-parameter-smart.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PanelReportParameterSmartComponent extends FormContentBase implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input() public form;
	@Input() public currentForm;
	@Input() public options;

	@Output() public endChildPanelNavigationEmit = new EventEmitter();
	@Output() public intiateChildPanelEmit = new EventEmitter();
	@Output() public nextParentPanelEmit = new EventEmitter();
	@Output() public nextChildPanelEmit = new EventEmitter();

	public currentParentPanel = 'Parameters';
	public currentChildPanel = '';
	public reports;
	public settings;
	public session;
	public subscriptions = [];

	constructor (
		private agentsCRMService: AgentsCRMService,
		public api: ApiService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
	) {
		super(api, cd, store);
	}

	ngOnInit () {
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSub);
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSub);
		const reportsSub = this.store.select('reportsState').subscribe(reports => {
			this.reports = reports;
			this.cd.detectChanges();
		});
		this.subscriptions.push(reportsSub);

		this.agentsCRMService.getParameter().subscribe(parameters => {
			this.store.dispatch(stateActions.reportsActions.updateOptions({ parameters }));
			this.intiateChildPanelEmit.emit({parentPanel: this.currentParentPanel, childPanel: 'Open Enrollment'});
			this.cd.detectChanges();
		});
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Parameters', 'PanelReportParameterSmartComponent'));
		this.currentChildPanel = 'Open Enrollment';
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit () {
		this.agentsCRMService.postParameter(null).subscribe(response => {
			this.nextChildPanelEmit.emit({
				current: this.currentChildPanel,
				response,
			})
		});
	}

	public nextPanel (response) {
		let subPanelName = '';
		if (response.name) {
			subPanelName = response.name;
			this.store.dispatch(stateActions.stepperActions.updateSecondary(response.name));
		} else {
			subPanelName = response.nextPanel.value;
			this.store.dispatch(stateActions.stepperActions.resetSecondary());
		}
		this.nextChildPanelEmit.emit({current: this.currentChildPanel, response});
		this.currentChildPanel = subPanelName;
		this.cd.detectChanges();
	}

	public endNavigation (event) {
		this.endChildPanelNavigationEmit.emit(event);
	}

}
