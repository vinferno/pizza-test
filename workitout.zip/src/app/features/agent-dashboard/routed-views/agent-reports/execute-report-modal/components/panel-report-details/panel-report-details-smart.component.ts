import { Component, HostBinding, Input, OnDestroy, OnInit } from '@angular/core';
import { Store }                                            from '@ngrx/store';

@Component({
	selector   : 'hg-panel-report-details-smart',
	templateUrl: './panel-report-details-smart.component.html',
	styleUrls  : ['./panel-report-details-smart.component.scss'],

})
export class PanelReportDetailsSmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	public subscriptions = [];
	public settings;
	public session;

	@Input()
	public form;
	@Input()
	public options;

	constructor (
		private store: Store<any>,
	) {}

	ngOnInit () {
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit () {
	}

}
