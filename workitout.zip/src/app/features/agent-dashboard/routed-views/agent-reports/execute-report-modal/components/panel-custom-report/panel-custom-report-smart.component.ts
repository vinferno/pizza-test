import {
	ChangeDetectorRef,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
}	from '@angular/core';
import { Store }				from '@ngrx/store';
import { AgentsCRMService }     from '../../../../../utils/agents-crm.service';
import { TableColumns } 		from '../../../../../../../infrastructure/interfaces/table-columns';
import { stateActions } 	 	from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector: 'hg-panel-custom-report-smart',
	templateUrl: './panel-custom-report-smart.component.html',
	styleUrls: ['./panel-custom-report-smart.component.scss'],

})
export class PanelCustomReportSmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	public subscriptions = [];
	public settings;
	public session;
	public templates;
	public benefitGrid;
	public selected = [];
	public uniqueIds = [];
	public selectedObject = {};
	public selectedRows = [];
	public selectedIndexes = [];
	public lastSelection = null;
	public currentSelection = [];
	public selectMode = 'single';

	public displayedColumns: TableColumns[] = [
		{
			columnName: 'Template',
			columnId  : 'name',
		},
		{
			columnName: 'Description',
			columnId  : 'description',
		},

	];

	@Input() public form;
	@Input() public options;

	@Output() public nextPanel = new EventEmitter();

	constructor (
		private store: Store<any>,
		private agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
	) {}

	ngOnInit () {
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
		this.agentsCRMService.getTemplates().subscribe(templates => {
			this.templates = templates;
		});
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Templates', 'PanelCustomReportSmartComponent'));
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit (event) {
		this.agentsCRMService.postTemplates(event).subscribe(response => {
			this.nextPanel.emit({
				current: 'Templates',
				response,
			});
		});
	}

	public cancel () {
	}

	dataGridChange(grid, event) {
		this.benefitGrid = event.component;
		this.benefitGrid.selectRows(this.selectedIndexes);
		grid.selectedRowKeysChange.subscribe((rows) => {
			if (this.selectMode === 'single') {
				if (rows.length === 1) {
					this.lastSelection = rows[0];
				}
				if (rows.length === 2) {
					rows.splice(rows.indexOf(this.lastSelection), 1);
					this.benefitGrid.selectRows(rows);
				}
				if (rows.length > 2) {

					this.benefitGrid.selectRows([]);
				}
			} else {
				this.benefitGrid.selectRows(rows.concat(this.selectedIndexes));
			}

			this.uniqueIds = rows.map(row => {
				return row.uniqueID;
			});

			this.currentSelection = rows;
			this.cd.detectChanges();
		});
	}

}
