import { Component, HostBinding, Input, OnDestroy, OnInit } from '@angular/core';
import { Store }                                            from '@ngrx/store';
import { AgentCrmReportService }                            from '../../../../../../../infrastructure/core/api/endpoints/agents-crm/agent-crm-report.service';
import { AgentsCRMService }                                 from '../../../../../utils/agents-crm.service';

@Component({
	selector   : 'hg-agent-report-select-open-enrollment-smart',
	templateUrl: './agent-report-select-open-enrollment-smart.component.html',
	styleUrls  : ['./agent-report-select-open-enrollment-smart.component.scss'],

})
export class AgentReportSelectOpenEnrollmentSmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	public subscriptions = [];
	public session;
	public settings;

	@Input()
	public form;

	public openEnrollments = [{name: 'test company'}, {name: 'test company 2'}];

	constructor (
		private store: Store<any>,
		private agentCrmService: AgentsCRMService,
	) {}

	ngOnInit () {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);
		this.agentCrmService.getReportSelectOpenEnrollments({agentID: this.session.agent.agentID})
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit () {
	}

}
