import { AgentReportStepperSmartComponent }                     from './agent-report-stepper/agent-report-stepper-smart.component';
import { AgentReportSelectCompanySmartComponent }               from './agent-report-select-company/agent-report-select-company-smart.component';
import { AgentReportSelectOpenEnrollmentPresentationComponent } from './agent-report-select-open-enrollment/agent-report-select-open-enrollment-presentation.component';
import { AgentReportSelectOpenEnrollmentSmartComponent }     	from './agent-report-select-open-enrollment/agent-report-select-open-enrollment-smart.component';
import { AgentReportBenefitCategoriesPresentationComponent } 	from './agent-report-benefit-categories/agent-report-benefit-categories-presentation.component';
import { AgentReportBenefitCategoriesSmartComponent } 			from './agent-report-benefit-categories/agent-report-benefit-categories-smart.component';
import { PanelCustomReportSmartComponent }            			from './panel-custom-report/panel-custom-report-smart.component';
import { PanelReportDetailsSmartComponent }         			from './panel-report-details/panel-report-details-smart.component';
import { PanelReportDetailsPresentationComponent }   			from './panel-report-details/panel-report-details-presentation.component';
import { PanelReportSummarySmartComponent }          			from './panel-report-summary/panel-report-summary-smart.component';
import { PanelReportParameterSmartComponent }        			from './panel-report-parameter/panel-report-parameter-smart.component';
import { ReportParameterComponents }                 			from './panel-report-parameter/parameter-components';

export const AgentReportComponents = [
	PanelCustomReportSmartComponent,
	PanelReportDetailsSmartComponent,
	PanelReportDetailsPresentationComponent,
	PanelReportParameterSmartComponent,
	PanelReportSummarySmartComponent,
	AgentReportStepperSmartComponent,
	AgentReportSelectCompanySmartComponent,
	AgentReportSelectOpenEnrollmentSmartComponent,
	AgentReportSelectOpenEnrollmentPresentationComponent,
	AgentReportBenefitCategoriesSmartComponent,
	AgentReportBenefitCategoriesPresentationComponent,
	ReportParameterComponents,
];
