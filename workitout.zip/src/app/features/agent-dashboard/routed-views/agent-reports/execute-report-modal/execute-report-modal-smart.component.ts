import {
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
}                                 from '@angular/core';
import {
	FormBuilder,
	Validators,
	FormGroup,
}                                 from '@angular/forms';

import { Store }                  from '@ngrx/store';
import { Subscription }           from 'rxjs';

import { AgentsCRMService }       from '../../../utils/agents-crm.service';
import { animator }               from 'app/infrastructure/core/animations/animations';
import { SessionState }           from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }          from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { ValidationPhone }        from '../../../../../infrastructure/core/validation/validation-phone';
import { stateActions }     	  from '../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector    : 'hg-execute-report-modal-smart',
	templateUrl : './execute-report-modal-smart.component.html',
	styleUrls   : ['./execute-report-modal-smart.component.scss'],
	animations  : [animator.slide],
})
export class ExecuteReportModalSmartComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public form;
	@Input() public reports;

	@Output() public nextPanel = new EventEmitter();

	public data = {
		requiresStartDate: true,
		requiresDateRange: false,
		displayName      : 'test',
	};
	public detail;
	public diffDays: string = '0';
	public fileTypes = [];
	public optionsForm: FormGroup;
	public session: SessionState;
	public settings: SettingsState;
	private subscriptions: Subscription[] = [];

	constructor (
		private store: Store<any>,
		private fb: FormBuilder,
		private agentsCRMService: AgentsCRMService,
	) {
	}

	ngOnInit(): void {
		const sessionSub = this.store.select('sessionState').subscribe(session => {this.session = session});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {this.settings = settings});
		this.subscriptions.push(settingsSub);
		this.optionsForm = this.fb.group(
			{
				reportID           : [this.reports.report.reportID, Validators.compose([Validators.required])],
				fileName           : [
					this.formatFileName(this.reports.report.displayName),
					Validators.compose([Validators.required]),
				],
				templateName       : [
					this.formatFileName(this.reports.report.displayName + '_Template'),
				],
				templateDescription: [
					'',
				],
				fileFormat         : [null, Validators.compose([Validators.required])],
				sendEmail          : false,
				sendSms            : false,
				saveAsTemplate     : false,
				phoneNumber        : '',
				startDate          : null,
				endDate            : null,
			});
		this.optionsForm.valueChanges.subscribe(form => {
		});
		this.data = this.reports.report;
		this.agentsCRMService.getDetail().subscribe((detail: any) => {
			this.detail = detail;
			this.optionsForm.get('fileName').setValue(this.formatFileName(this.detail.fileName));
			this.fileTypes = detail.fileTypes;
		});
		this.optionsForm.get('reportID').setValue(0);
		this.optionsForm.get('sendSms').valueChanges.subscribe(value => {
			if (value) {
				this.optionsForm.get('phoneNumber')
					.setValidators(Validators.compose([
						Validators.required,
						ValidationPhone.validPhoneNumber(true),
					]));
				this.optionsForm.get('phoneNumber').updateValueAndValidity();
			} else {
				this.optionsForm.get('phoneNumber').setValidators(Validators.compose([]));
				this.optionsForm.get('phoneNumber').updateValueAndValidity();
			}
		});
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Detail', 'ExecuteReportModalSmartComponent'));
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public runReport(): void {
		const payload = this.optionsForm.value;
		payload.phoneNumber = payload.phoneNumber.replace(/\D/g, '');
		delete payload.endDate;
		delete payload.reportID;
		delete payload.startDate;
		payload.sendEmailOnFinish = payload.sendEmail;
		delete payload.sendEmail;
		payload.fileType = payload.fileFormat;
		delete payload.fileFormat;
		this.agentsCRMService.postDetail(payload).subscribe((response) => {
			this.nextPanel.emit({
				current: 'Detail',
				response,
			});
		});
	}

	private formatFileName(text: string): string {
		return text.replace(/[ ]/g, '_');
	}
}

