import { Component, HostBinding, Input, OnDestroy, OnInit } from '@angular/core';
import { Store }                                            from '@ngrx/store';
import { AgentsCRMService }                                 from '../../../../../utils/agents-crm.service';
import { Router }                                           from '@angular/router';
import { stateActions }     	  							from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector   : 'hg-panel-report-summary-smart',
	templateUrl: './panel-report-summary-smart.component.html',
	styleUrls  : ['./panel-report-summary-smart.component.scss'],

})
export class PanelReportSummarySmartComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input() public form;
	@Input() public options;

	public settings;
	public session;
	public subscriptions = [];
	public summary;

	constructor (
		private store: Store<any>,
		private agentsCRMService: AgentsCRMService,
		private router: Router,
	) {}

	ngOnInit() {
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);

		this.agentsCRMService.getSummary().subscribe(summary => {
			this.summary = summary;
		});
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Summary', 'PanelReportSummarySmartComponent'));
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit() {
		this.agentsCRMService.postSummary().subscribe( response => {
			if (response) {
				this.router.navigateByUrl('counselor/reports/todays-reports');
			}
		});
	}

}
