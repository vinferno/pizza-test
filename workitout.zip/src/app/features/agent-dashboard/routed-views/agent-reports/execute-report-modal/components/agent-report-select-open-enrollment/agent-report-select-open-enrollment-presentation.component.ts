import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
} from '@angular/core';

@Component({
	selector   : 'hg-agent-report-select-open-enrollment-presentation',
	templateUrl: './agent-report-select-open-enrollment-presentation.component.html',
	styleUrls  : ['./agent-report-select-open-enrollment-presentation.component.scss'],

	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AgentReportSelectOpenEnrollmentPresentationComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input()
	public session;
	@Input()
	public settings;

	@Output()
	public submitEmit: EventEmitter<any> = new EventEmitter<any>();

	@Input()
	public form;

	@Input()
	public openEnrollments;

	constructor () {
	}

	ngOnInit () {
	}

	ngOnDestroy () {
	}

	public submit () {
		const event = {};
		this.submitEmit.emit(event);
	}

}

