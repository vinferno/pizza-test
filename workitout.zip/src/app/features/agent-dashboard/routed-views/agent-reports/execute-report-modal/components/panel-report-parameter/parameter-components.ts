import { ParameterOpenEnrollmentSmartComponent }           from './parameter-open-enrollment/parameter-open-enrollment-smart.component';
import { ParameterBenefitCategoriesSmartComponent }        from './parameter-benefit-categories/parameter-benefit-categories-smart.component';
import { ParameterDateSmartComponent }                     from './parameter-date/parameter-date-smart.component';

export const ReportParameterComponents = [
	ParameterOpenEnrollmentSmartComponent,
	ParameterBenefitCategoriesSmartComponent,
	ParameterDateSmartComponent,
];
