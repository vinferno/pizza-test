import {
	ChangeDetectorRef,
	Component,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
}                                 	from '@angular/core';
import {
	ActivatedRoute,
	Router,
}                                 	from '@angular/router';
import {
	FormBuilder,
	Validators,
}            						from '@angular/forms';

import { Store }                  	from '@ngrx/store';
import { BehaviorSubject }        	from 'rxjs';
import { withLatestFrom }         	from 'rxjs/operators';

import { AgentsCRMService }       	from '../../../../../utils/agents-crm.service';
import { AgentsDashboardService } 	from '../../../../../utils/agent-dashboard.service';
import { ApiService }             	from '../../../../../../../infrastructure/core/api/api.service';
import { EnrollmentAddService }   	from '../../../../../../../infrastructure/enrollment/enrollment-add.service';
import { FormPersistentService }  	from '../../../../../../../infrastructure/core/services/form-persistent.service';
import { FormDialogBase }         	from '../../../../../../../infrastructure/core/classes/form-wizard';
import { StepperState } 			from '../../../../../../../infrastructure/store/reducers/stepper/stepper-state';
import { stateActions }    	 		from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector   : 'hg-agent-report-stepper-smart',
	templateUrl: './agent-report-stepper-smart.component.html',
	styleUrls  : ['./agent-report-stepper-smart.component.scss'],

})
export class AgentReportStepperSmartComponent extends FormDialogBase implements OnInit, OnDestroy {
	@HostBinding('style.display') display = 'block';

	@Input() public data;

	public agentCompanies;
	public companyID;
	public form;
	public reports;
	public reportID;
	public reportIDInvalid;
	public session;
	public settings;

	public formWizardName: string = 'Add Benefit';
	public options = new BehaviorSubject({});
	public returnRoute: string = '/counselor/reports';
	public subscriptions = [];
	public steppers: StepperState;

	public formsInit = [
		{
			name: 'Company',
			fg  : {
				uniqueID: '',
				companyID: '',
			},
		},
		{
			name: 'Templates',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Parameters',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Open Enrollment',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Benefit Categories',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Date',
			fg  : {
				uniqueID: '',
				date: [null, Validators.required],
			},
		},
		{
			name: 'Detail',
			fg  : {
				uniqueID: '',
			},
		},
		{
			name: 'Summary',
			fg  : {
				uniqueID: '',
			},
		},
	];

	public parentPanels = [
		{
			name: 'Company',
			hasChildWizard: false,
		},
		{
			name: 'Templates',
			hasChildWizard: false,
		},
		{
			name: 'Parameters',
			hasChildWizard: true,
		},
		{
			name: 'Detail',
			hasChildWizard: false,
		},
		{
			name: 'Summary',
			hasChildWizard: false,
		},
	];

	public childPanels = [
		{
			parentName: 'Parameters',
			name: 'Open Enrollment',
		},
		{
			parentName: 'Parameters',
			name: 'Benefit Categories',
		},
		{
			parentName: 'Parameters',
			name: 'Date',
		},
	];

	constructor (
		public api: ApiService,
		public formService: FormPersistentService,
		public router: Router,
		public service: EnrollmentAddService,
		public cd: ChangeDetectorRef,
		public store: Store<any>,
		public route: ActivatedRoute,
		public agentsDashboardService: AgentsDashboardService,
		public agentsCRMService: AgentsCRMService,
	) {
		super(formService, router, api, cd, store);
		this.alias = {
			Company   			: 'Company',
			Templates  			: 'Templates',
			Parameters			: 'Parameters',
			'Open Enrollment'   : 'Open Enrollment',
			'Benefit Categories': 'Benefit Categories',
			Date                : 'Date',
			Detail   			: 'Detail',
			Summary   			: 'Summary',
			Finalize  			: 'Finalize',
		};
	}

	ngOnInit () {
		super.ngOnInit();
		const reportsSub = this.store.select('reportsState')
			.pipe(withLatestFrom())
			.subscribe((reports: any) => {
				this.reports = reports[reports.length - 1];
			});
		this.subscriptions.push(reportsSub);
		this.form = this.fb.group({
			companyID: '',
		});
		this.reportID = this.route.snapshot.params.reportID;

		const reportParam = this.route.paramMap.subscribe(params => {
			this.reportID = params.get('reportID');
		});
		this.subscriptions.push(reportParam);
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings
		});
		this.subscriptions.push(settingsSub);
		const enabledCompaniesSub = this.agentsDashboardService.getAgentEnabledCompanies().subscribe(agentCompanies => {
			this.agentCompanies = agentCompanies;
			this.cd.detectChanges();
		});
		this.subscriptions.push(enabledCompaniesSub);
		this.subscriptions.push(
			this.store.select('stepperState').subscribe( (steppers: StepperState) => {
				this.steppers = steppers;
				const stepperParentPanel = steppers.primaryStepper.slice(-1)[0];
				const stepperChildPanel = steppers.secondaryStepper.slice(-1)[0];
				this.wizardSelectionChanges(stepperParentPanel, stepperChildPanel);
				this.cd.detectChanges();
			}),
		);

		this.agentsCRMService.initializeReport({ reportID: this.reportID }).subscribe(parameters => {
			if (!this.reports.report.reportID && !this.reportIDInvalid) {
				this.reportIDInvalid = true;
				this.router.navigateByUrl('/counselor/reports');
			}
		});
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
		this.store.dispatch(stateActions.stepperActions.resetPrimary());
		this.store.dispatch(stateActions.stepperActions.resetSecondary());
	}

	public nextParentPanel (current, response) {
		this.changePanels(current, response.nextPanel.value);
	}

	public intiateChildPanel(parentPanel, childPanel) {
		this.changePanels(parentPanel, childPanel);
	}

	public nextChildPanel (current, response) {
		this.changePanels(current, response.name);
	}

	public endChildPanelNavigation(current, response) {
		this.store.dispatch(stateActions.stepperActions.resetSecondary());
		this.nextParentPanel(current, response);
	}

	private changePanels(curentPanel, nextPanel) {
		this.skipBetween(curentPanel, nextPanel);
		this.skipTo(nextPanel);
		this.cd.detectChanges();
	}
}
