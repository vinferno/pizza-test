import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
} from '@angular/core';

@Component({
	selector   : 'hg-agent-report-benefit-categories-presentation',
	templateUrl: './agent-report-benefit-categories-presentation.component.html',
	styleUrls  : ['./agent-report-benefit-categories-presentation.component.scss'],

	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AgentReportBenefitCategoriesPresentationComponent implements OnInit, OnDestroy {

	@HostBinding('style.display') display = 'block';

	@Input()
	public session;
	@Input()
	public settings;

	@Output()
	public submitEmit: EventEmitter<any> = new EventEmitter<any>();

	@Input()
	public form;
	@Input()
	public benefitCategories;
	@Input()
	public displayedColumns;

	constructor () {
	}

	ngOnInit () {
	}

	ngOnDestroy () {
	}

	public submit () {
		const event = {};
		this.submitEmit.emit(event);
	}

}

