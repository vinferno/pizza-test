import {
	AfterContentInit, ChangeDetectorRef,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	OnDestroy,
	OnInit,
	Output,
}                           from '@angular/core';
import { Store }            from '@ngrx/store';
import { Validators }       from '@angular/forms';
import { AgentsCRMService } from '../../../../../utils/agents-crm.service';
import { stateActions }     from '../../../../../../../infrastructure/store/reducers/reducers-index';

@Component({
	selector   : 'hg-agent-report-select-company-smart',
	templateUrl: './agent-report-select-company-smart.component.html',
	styleUrls  : ['./agent-report-select-company-smart.component.scss'],

})
export class AgentReportSelectCompanySmartComponent implements OnInit, OnDestroy, AfterContentInit {

	@HostBinding('style.display') display = 'block';

	public subscriptions = [];
	public session;
	public settings;

	@Input() public form;
	@Input() public agentCompanies;

	@Output() public nextPanel = new EventEmitter();

	constructor (
		public cd: ChangeDetectorRef,
		public store: Store<any>,
		public agentsCRMService: AgentsCRMService,
	) {
	}

	ngOnInit () {
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSub);
		this.store.dispatch(stateActions.stepperActions.updatePrimary('Company', 'AgentReportSelectCompanySmartComponent'));
	}

	ngAfterContentInit () {
		this.form.get('companyID').setValidators([Validators.required]);
		this.form.get('companyID').updateValueAndValidity();
	}

	ngOnDestroy () {
		this.subscriptions.forEach(sub => {
			sub.unsubscribe();
		})
	}

	public submit () {
		this.agentsCRMService.company({ companyID: this.form.value.companyID.companyID }).subscribe(response => {
			this.nextPanel.emit({current: 'Company', response} );
			this.store.dispatch(stateActions.reportsActions.updateOptions(response));
		});
	}

}
