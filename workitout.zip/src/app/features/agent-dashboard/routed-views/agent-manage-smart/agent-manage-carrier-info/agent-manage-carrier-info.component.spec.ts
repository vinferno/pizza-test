import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageCarrierInfoComponent } from './agent-manage-carrier-info.component';

describe('AgentManageCarrierInfoComponent', () => {
  let component: AgentManageCarrierInfoComponent;
  let fixture: ComponentFixture<AgentManageCarrierInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageCarrierInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageCarrierInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
