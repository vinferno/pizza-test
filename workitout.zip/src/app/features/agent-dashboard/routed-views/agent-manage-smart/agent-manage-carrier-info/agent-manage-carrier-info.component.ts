import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators }                            from '@angular/forms';
import { AgentsManageService }                                from '../../../utils/agents-manage.service';

@Component({
	selector   : 'hg-agent-manage-carrier-info',
	templateUrl: './agent-manage-carrier-info.component.html',
	styleUrls  : ['./agent-manage-carrier-info.component.scss'],
})
export class AgentManageCarrierInfoComponent implements OnInit, OnChanges {
	public agentSearchResults;
	public carrierSearchResults;
	public selectedCarrier;
	public includeDisabled = false;
	public edit = null;
	public agentForm;
	public testForm;
	@Input()
	public settings;
	@Input()
	public broker;
	public emptyGridMessage: string = 'No search results.';
	public agentList;
	public carriersList;
	public carrierForm;
	private formDefault;
	@Input()
	public session;
	public companyForm;
	private companyID: number = null;

	constructor (
		private agentsManageService: AgentsManageService,
		private fb: FormBuilder,
	) { }

	ngOnInit () {
		this.formDefault = {
			firstName            : ['', Validators.compose([Validators.required])],
			middleName           : ['', Validators.compose([])],
			lastName             : ['', Validators.compose([Validators.required])],
			address              : ['', Validators.compose([])],
			city                 : ['', Validators.compose([])],
			state                : ['', Validators.compose([])],
			zipCode              : ['', Validators.compose([])],
			officePhone          : ['', Validators.compose([])],
			phoneExt             : ['', Validators.compose([])],
			phone                : ['', Validators.compose([Validators.required])],
			fax                  : ['', Validators.compose([])],
			email                : ['', Validators.compose([Validators.required, Validators.email])],
			userID               : ['', Validators.compose([])],
			systemAccessExpiresOn: ['', Validators.compose([])],
			type                 : ['', Validators.compose([Validators.required])],
			broker               : ['', Validators.compose([])],
			disableAccount       : ['', Validators.compose([])],
		};
		this.agentForm = this.fb.group(this.formDefault);
		this.testForm = this.fb.group({ test: '' });
		this.companyForm = this.fb.group({ company: '' });
		this.carrierForm = this.fb.group({ carrier: '' });
		this.getAgentCarrierInfo();
		this.getAgentCarriers();
	}

	ngOnChanges (changes: SimpleChanges): void {
	}

	public getAgentCarrierInfo () {
		if (!this.selectedCarrier) {
			return;
		}
		this.agentsManageService.getAgentCarrierInfo({
			carrierID      : this.selectedCarrier.id,
			companyID      : this.companyID,
			includeDisabled: this.includeDisabled,
		})
			.subscribe(carrierInfo => {
				this.agentSearchResults = carrierInfo;
				this.agentList = carrierInfo;
				this.edit = null;
			});
	}

	public getAgentCarriers () {
		this.agentsManageService.getAgentCarriers({ includeDisabled: this.includeDisabled })
			.subscribe(carriers => {
				this.carrierSearchResults = carriers;
			});
	}

	public setSelectedCompany(event) {
		if (event && event.companyID) {
			this.companyID = event.companyID;
			this.getAgentCarrierInfo();
		}
	}

	public save () {
		this.agentsManageService.saveAgentCarrierInfo({ carrierInfos: this.agentList }).subscribe(() => {
			this.getAgentCarrierInfo();
		});
	}

	public cancel () {
		this.getAgentCarrierInfo();
	}

	public changeList (list) {
		this.agentList = list;
	}

	public changeCarrierList (list) {
		this.carriersList = list;
	}

	public selectCarrier (carrier) {
		this.selectedCarrier = carrier;
		this.getAgentCarrierInfo();
	}
}
