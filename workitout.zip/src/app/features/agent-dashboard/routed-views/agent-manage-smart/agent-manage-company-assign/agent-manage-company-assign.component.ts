import { Component, Input, OnInit }                 from '@angular/core';
import { AgentsManageService }                      from '../../../utils/agents-manage.service';
import { TableColumns }                             from '../../../../../infrastructure/interfaces/table-columns';
import { SessionState }                             from '../../../../../infrastructure/store/reducers/session/session-state';
import { FormBuilder, FormGroup, Validators }       from '@angular/forms';
import { MatDialog } from "@angular/material/dialog";
import { AgentManageNotAssignedToCompanyComponent } from './agent-manage-not-assigned-to-company/agent-manage-not-assigned-to-company.component';
import { Agent }                                    from '../../../../../infrastructure/interfaces/agent';
import { CompanyAssignmentAgent }                   from '../../../../../infrastructure/interfaces/companyAssignmentAgent';

@Component({
	selector   : 'hg-agent-manage-company-assign',
	templateUrl: './agent-manage-company-assign.component.html',
	styleUrls  : ['./agent-manage-company-assign.component.scss'],
})
export class AgentManageCompanyAssignComponent implements OnInit {
	public selectedDialogComponent = AgentManageNotAssignedToCompanyComponent;
	public agentsAssigned;
	public enableSave: boolean = false;
	@Input()
	public settings;
	@Input()
	public session: SessionState;
	public emptyGridMessage: string = 'No search results.';

	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId  : 'name',
		},
		{
			columnName: 'Email',
			columnId  : 'email',
		},
		{
			columnName: 'Phone Number',
			columnId  : 'Phone',
		},
		{
			columnName: 'Name',
			columnId  : 'name',
		},
	];
	public form: FormGroup;
	public selectedCompany;

	constructor (
		private agentsManageService: AgentsManageService,
		private fb: FormBuilder,
		private dialog: MatDialog,
	) { }

	ngOnInit () {
		this.form = this.fb.group({ company: [null, Validators.required] });
	}

	public showColumn (columnId) {
		const doNotShow = [];
		return !doNotShow.includes(columnId)
	}

	public setSelectedCompany ($event) {
		if (this.form.valid) {
			this.selectedCompany = $event;
			this.getAgentsForCompany();
		}
	}

	public getAgentsForCompany () {
		this.agentsManageService.getAgentsAssignedToCompany(this.form.value.company.companyID).subscribe((agents: CompanyAssignmentAgent[]) => {
			this.agentsAssigned = agents.map( agent => {
				return {...agent, ...{name: `${agent.firstName} ${agent.lastName}` }}
			});
		});
	}

	public assignCompanies () {
		if (!this.selectedCompany) {
			return;
		}
		this.openDialog();
	}

	public removeCompanyAssignments () {
		if (!this.agentsAssigned) {return; }
		const agentsAssign = this.agentsAssigned.filter(agent => agent.disabled).map(agent => agent.id);
		this.agentsManageService.unAssignAgentsFromCompany(this.selectedCompany.companyID, agentsAssign).subscribe((data) => {
			this.getAgentsForCompany();
		});
	}

	public openDialog () {
		const dialogRef = this.dialog.open(this.selectedDialogComponent, {
			disableClose: true,
			data        : { ...this.selectedCompany },
		}).afterClosed().subscribe((data) => {
			this.getAgentsForCompany();
		});
	}

	public isSelectedCompany() {
		return true;
	}
}
