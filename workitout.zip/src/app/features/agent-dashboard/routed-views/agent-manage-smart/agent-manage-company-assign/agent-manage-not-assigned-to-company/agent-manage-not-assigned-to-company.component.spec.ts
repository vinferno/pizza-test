import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageNotAssignedToCompanyComponent } from './agent-manage-not-assigned-to-company.component';

describe('AgentManageNotAssignedToCompanyComponent', () => {
  let component: AgentManageNotAssignedToCompanyComponent;
  let fixture: ComponentFixture<AgentManageNotAssignedToCompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageNotAssignedToCompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageNotAssignedToCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
