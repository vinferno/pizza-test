import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageCompanyAssignComponent } from './agent-manage-company-assign.component';

describe('AgentManageCompanyAssignComponent', () => {
  let component: AgentManageCompanyAssignComponent;
  let fixture: ComponentFixture<AgentManageCompanyAssignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageCompanyAssignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageCompanyAssignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
