import { Component, Inject, OnInit }                from '@angular/core';
import { SessionState }                             from '../../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }                             from '../../../../../../infrastructure/interfaces/table-columns';
import { FormBuilder, FormGroup }                   from '@angular/forms';
import { AgentsManageService }                      from '../../../../utils/agents-manage.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from "@angular/material/dialog";
import { Store }                                    from '@ngrx/store';

@Component({
	selector   : 'hg-agent-manage-not-assigned-to-company',
	templateUrl: './agent-manage-not-assigned-to-company.component.html',
	styleUrls  : ['./agent-manage-not-assigned-to-company.component.scss'],
})
export class AgentManageNotAssignedToCompanyComponent implements OnInit {
	public agentSearchResults;
	public agentList;
	public agentForm;
	public virtualProperty = virtualProperty;
	public enableSave: boolean = false;
	public agentsUnAssigned;
	public settings;
	public session: SessionState;
	public emptyGridMessage: string = 'Please select an Agent to see a list of companies.';

	public columnList: TableColumns[] = [
		{
			columnName: 'First Name',
			columnId  : 'firstName',
		},
		{
			columnName: 'Last Name',
			columnId  : 'lastName',
		},
		{
			columnName: 'Email',
			columnId  : 'email',
		},
	];

	public form: FormGroup;

	constructor (
		private agentsManageService: AgentsManageService,
		private dialog: MatDialog,
		private fb: FormBuilder,
		private store: Store<any>,
		public dialogRef: MatDialogRef<AgentManageNotAssignedToCompanyComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
	) { }

	ngOnInit () {
		this.getAgentsNotAssignedToCompany(this.data.companyID);
		this.store.select('settingsState').subscribe(settings => this.settings = settings);
		this.store.select('sessionState').subscribe(session => this.session = session);
		this.agentForm = this.fb.group({agent: ''});
	}

	public getAgentsNotAssignedToCompany (agentID) {
		this.agentsManageService.getAgentsNotAssignedToCompany(agentID).subscribe(agents => {
			this.agentsUnAssigned = agents;
			this.assignFilteredList(agents);
			if (!agents || !agents[0]) {
				this.emptyGridMessage = 'No search results.';
			}
		})
	}

	public showColumn () {
		return true;
	}

	public assignCompanies () {
		const agentsAssign = this.agentsUnAssigned.filter(agent => agent.disabled).map(agent => agent.id);
		if (!this.data.companyID || !agentsAssign.length) {
			return;
		}
		this.agentsManageService.assignAgentsToCompany(this.data.companyID, agentsAssign).subscribe(() => {
			this.dialogRef.close();
		})
	}

	public removeCompanyAssignments () {
	}

	public assignFilteredList( event) {
		this.agentList = event;
	}

	public closeDialog() {
		this.dialogRef.close();
	}
}

function virtualProperty(collection) {
	collection.forEach( item => {
		item.name = item.firstName + ' ' + item.lastName;
	});
}
