import { Component, Input, OnInit } from '@angular/core';
import { TableColumns }             from '../../../../../infrastructure/interfaces/table-columns';
import { AgentsManageService }      from '../../../utils/agents-manage.service';
import { FormBuilder, Validators }  from '@angular/forms';

@Component({
	selector   : 'hg-agent-manage-edit',
	templateUrl: './agent-manage-edit.component.html',
	styleUrls  : ['./agent-manage-edit.component.scss'],
})
export class AgentManageEditComponent implements OnInit {
	public agentSearchResults;
	public includeDisabled = false;
	public edit = null;
	public agentForm;
	public testForm;
	@Input()
	public settings;
	public virtualProperty = virtualProperty;
	public columnList: TableColumns[] = [
		{
			columnName: 'First Name',
			columnId  : 'firstName',
		},
		{
			columnName: 'Last Name',
			columnId  : 'lastName',
		},
		{
			columnName: 'User ID',
			columnId  : 'uid',
		},
		{
			columnName: 'Email',
			columnId  : 'email',
		},
		{
			columnName: 'Phone',
			columnId  : 'phone',
		},
		{
			columnName: 'Disabled',
			columnId  : 'disabled',
		},
	];
	public emptyGridMessage: string = 'No search results.';
	private formDefault;
	public agentList;
	@Input() public broker;

	constructor (
		private agentsManageService: AgentsManageService,
		private fb: FormBuilder,
	) { }

	ngOnInit () {
		this.formDefault = {
			firstName            : ['', Validators.compose([Validators.required])],
			middleName           : ['', Validators.compose([])],
			lastName             : ['', Validators.compose([Validators.required])],
			address              : ['', Validators.compose([])],
			city                 : ['', Validators.compose([])],
			state                : ['', Validators.compose([])],
			zipCode              : ['', Validators.compose([])],
			officePhone          : ['', Validators.compose([])],
			phoneExt             : ['', Validators.compose([])],
			phone                : ['', Validators.compose([Validators.required])],
			fax                  : ['', Validators.compose([])],
			email                : ['', Validators.compose([Validators.required, Validators.email])],
			uid               : ['', Validators.compose([Validators.required])],
			systemAccessExpiresOn: ['', Validators.compose([])],
			type                 : ['', Validators.compose([Validators.required])],
			broker               : ['', Validators.compose([])],
			disableAccount       : ['', Validators.compose([])],
			resetPassword 		 : [false, Validators.compose([])],
		};
		this.agentForm = this.fb.group(this.formDefault);
		this.testForm = this.fb.group({test: ''});
		this.getAgents();
	}

	public getAgents () {
		this.agentsManageService.getAgents({ includeDisabled: this.includeDisabled })
			.subscribe(agents => {
				this.agentSearchResults = agents;
				this.agentList = agents;
				this.edit = null;
			});
	}

	public showColumn (columnId) {
		const doNotShow = ['phone', 'disabled'];
		return !doNotShow.includes(columnId)
	}

	public formatPhone (phone) {
		let newVal = phone.replace(/\D/g, '');
		if (newVal.length === 0) {
			newVal = '';
		} else if (newVal.length <= 3) {
			newVal = newVal.replace(/^(\d{0,3})/, '($1)');
		} else if (newVal.length <= 6) {
			newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
		} else if (newVal.length <= 10) {
			newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(\d{0,4})/, '($1) $2-$3');
		} else {
			newVal = newVal.substring(0, 10);
			newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(\d{0,4})/, '($1) $2-$3');
		}
		return newVal;
	}

	public save () {
		this.saveEdit();
		this.agentsManageService.editAgentProfile(this.edit).subscribe(() => {
			this.getAgents();
		});
	}

	public resetPassword() {
		this.saveEdit();
		this.agentsManageService.editAgentResetPassword(this.edit).subscribe(() => {
			this.getAgents();
		});
	}

	public cancel () {
		this.edit = null;
		this.agentForm.reset();
		this.getAgents();
	}

	public setEdit (agent) {
		this.edit = agent;
		Object.keys(this.formDefault).forEach(key => {
			this.agentForm.get(key).setValue(this.edit[key]);
			this.agentForm.get(key).updateValueAndValidity();
		})
	}

	public saveEdit () {
		Object.keys(this.formDefault).forEach(key => {
			this.edit[key] = this.agentForm.get(key).value;
		});
		this.edit.phone = this.edit.phone.replace(/\D/g, '');
		this.edit.fax = this.edit.fax.replace(/\D/g, '');
		this.edit.BrokerID = this.broker.id;
	}

	public changeList(list) {
		this.agentList = list;
	}
}

function virtualProperty(collection) {
	collection.forEach( item => {
		item.name = item.firstName + ' ' + item.lastName;
	});
}
