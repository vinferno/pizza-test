import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageEditComponent } from './agent-manage-edit.component';

describe('AgentManageEditComponent', () => {
  let component: AgentManageEditComponent;
  let fixture: ComponentFixture<AgentManageEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
