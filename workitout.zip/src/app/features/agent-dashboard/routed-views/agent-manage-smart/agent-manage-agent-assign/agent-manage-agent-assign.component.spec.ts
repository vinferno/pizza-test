import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageAgentAssignComponent } from './agent-manage-agent-assign.component';

describe('AgentManageAgentAssignComponent', () => {
  let component: AgentManageAgentAssignComponent;
  let fixture: ComponentFixture<AgentManageAgentAssignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageAgentAssignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageAgentAssignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
