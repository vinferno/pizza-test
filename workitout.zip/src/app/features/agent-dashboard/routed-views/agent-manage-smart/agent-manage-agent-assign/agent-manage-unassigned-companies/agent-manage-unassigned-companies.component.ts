import { Component, Inject, OnInit }                from '@angular/core';
import { SessionState }                             from '../../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }                             from '../../../../../../infrastructure/interfaces/table-columns';
import { FormBuilder, FormGroup }                   from '@angular/forms';
import { AgentsManageService }                      from '../../../../utils/agents-manage.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from "@angular/material/dialog";
import { Store }                                    from '@ngrx/store';

@Component({
	selector   : 'hg-agent-manage-unassigned-companies',
	templateUrl: './agent-manage-unassigned-companies.component.html',
	styleUrls  : ['./agent-manage-unassigned-companies.component.scss'],
})
export class AgentManageUnassignedCompaniesComponent implements OnInit {
	public agentSearchResults;
	public CompanySearchResults;
	public settings;
	public session: SessionState;
	public emptyGridMessage: string = 'Please select an Agent to see a list of companies.';
	public companiesFiltered;

	public columnList: TableColumns[] = [
		{
			columnName: 'Company Name',
			columnId  : 'companyName',
		},
		{
			columnName: 'Company ID',
			columnId  : 'companyID',
		},
		{
			columnName: 'Code',
			columnId  : 'code',
		},
	];

	public form: FormGroup;

	constructor (
		private agentsManageService: AgentsManageService,
		private dialog: MatDialog,
		private fb: FormBuilder,
		private store: Store<any>,
		public dialogRef: MatDialogRef<AgentManageUnassignedCompaniesComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
	) { }

	ngOnInit () {
		this.getCompaniesForSpecificAgentUnassigned(this.data.agentID);
		this.form = this.fb.group({company: ''});
		this.store.select('settingsState').subscribe(settings => this.settings = settings);
		this.store.select('sessionState').subscribe(session => this.session = session);
	}

	public getCompaniesForSpecificAgentUnassigned (agentID) {
		this.agentsManageService.getCompaniesForAgentUnassigned(agentID).subscribe(companies => {
			this.CompanySearchResults = companies;
			this.assignFilteredList(companies);
			if (!companies || !companies[0]) {
				this.emptyGridMessage = 'No search results.';
			}
		})
	}

	public showColumn () {
		return true;
	}

	public assignCompanies () {
		const companyIds = this.CompanySearchResults.filter(company => company.disabled).map(company => company.companyID);
		if (!this.data.agentID || !companyIds.length) {
			return;
		}
		this.agentsManageService.assignCompaniesToAgent(this.data.agentID, companyIds).subscribe(() => {
			this.dialogRef.close();
		})
	}

	public removeCompanyAssignments () {
	}

	public assignFilteredList(event) {
		this.companiesFiltered = event;
	}

	public closeDialog() {
		this.dialogRef.close();
	}
}
