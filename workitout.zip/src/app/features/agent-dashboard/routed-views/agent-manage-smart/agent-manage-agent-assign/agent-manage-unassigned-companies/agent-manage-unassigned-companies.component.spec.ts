import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageUnassignedCompaniesComponent } from './agent-manage-unassigned-companies.component';

describe('AgentManageUnassignedCompaniesComponent', () => {
  let component: AgentManageUnassignedCompaniesComponent;
  let fixture: ComponentFixture<AgentManageUnassignedCompaniesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageUnassignedCompaniesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageUnassignedCompaniesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
