import { Component, Input, OnInit }                from '@angular/core';
import { AgentsManageService }                     from '../../../utils/agents-manage.service';
import { MatDialog } 							   from '@angular/material/dialog';
import { FormBuilder, FormGroup }                  from '@angular/forms';
import { SessionState }                            from '../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }                            from '../../../../../infrastructure/interfaces/table-columns';
import { AgentManageUnassignedCompaniesComponent } from './agent-manage-unassigned-companies/agent-manage-unassigned-companies.component';

@Component({
	selector   : 'hg-agent-manage-agent-assign',
	templateUrl: './agent-manage-agent-assign.component.html',
	styleUrls  : ['./agent-manage-agent-assign.component.scss'],
})
export class AgentManageAgentAssignComponent implements OnInit {
	public agentSearchResults;
	public selectedDialogComponent = AgentManageUnassignedCompaniesComponent;
	public CompanySearchResults;
	@Input()
	public settings;
	@Input()
	public session: SessionState;
	public emptyGridMessage: string = 'Please select an Agent to see a list of companies.';

	public columnList: TableColumns[] = [
		{
			columnName: 'Company Name',
			columnId  : 'companyName',
		},
		{
			columnName: 'Company ID',
			columnId  : 'companyID',
		},
		{
			columnName: 'Code',
			columnId  : 'code',
		},
	];
	public selectedAgent;

	public form: FormGroup;
	public selectForm: FormGroup;
	public includeDisabled: boolean = false;

	constructor (
		private agentsManageService: AgentsManageService,
		private dialog: MatDialog,
		private fb: FormBuilder,
	) { }

	ngOnInit () {
		this.getAgents();
		this.form = this.fb.group({ agentID: [''] });
		this.form.valueChanges.subscribe(value => {
			this.selectedAgent = value;
			if (value && value.agentID) {
				this.getCompaniesForSpecificAgent(value.agentID);
			}
		});
		this.selectForm = this.form = this.fb.group({ agentID: [''] });
	}

	public getAgents (): void {
		this.agentsManageService.getAgents({ includeDisabled: this.includeDisabled })
			.subscribe(agents =>
				this.agentSearchResults = agents,
			);
	}

	public updateAgent(event) {
		if (event && event.agentID){
			this.selectedAgent = event;
			this.getCompaniesForSpecificAgent(event.agentID);
		}

	}

	public getCompaniesForSpecificAgent (agentID) {
		this.agentsManageService.getCompaniesForAgent(agentID).subscribe(companies => {
			this.CompanySearchResults = companies;
			if (!companies || !companies[0]) {
				this.emptyGridMessage = 'No search results.';
			}
		})
	}

	public showColumn () {
		return true;
	}

	public assignCompanies () {
		this.openDialog();
	}

	public removeCompanyAssignments () {
		if (!this.CompanySearchResults) {return; }
		const companyIds = this.CompanySearchResults.filter(company => company.disabled).map(company => company.companyID);
		if (!this.selectedAgent || !companyIds.length) {
			return;
		}
		this.agentsManageService.UnAssignCompaniesFromAgent(this.selectedAgent.agentID, companyIds).subscribe(() => {
			this.getCompaniesForSpecificAgent(this.selectedAgent.agentID);
		})
	}

	public openDialog () {
		this.dialog.open(this.selectedDialogComponent, {
			disableClose: true,
			data        : { ...this.selectedAgent },
		}).afterClosed().subscribe(() => {
			this.getCompaniesForSpecificAgent(this.selectedAgent.agentID);
		});
	}

	public getColumnWidth(i) {
		if (i === 0) {
			return '52%';
		}
	}
}
