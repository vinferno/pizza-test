import { ChangeDetectorRef, Component, EventEmitter, HostBinding, Input, OnInit, Output, OnDestroy } from '@angular/core';
import { DomSanitizer }                                                                   from '@angular/platform-browser';
import { SessionState }                                                                   from '../../../../infrastructure/store/reducers/session/session-state';
import { RouterState } 																	  from '../../../../infrastructure/store/reducers/router/router-state';
import { Store } from '@ngrx/store';
import {
	Observable,
	Subscription,
} from 'rxjs';

@Component({
	selector   : 'hg-agent-manage-presentation',
	templateUrl: './agent-manage-presentation.component.html',
	styleUrls  : ['./agent-manage-presentation.component.scss'],
})
export class AgentManagePresentationComponent implements OnInit, OnDestroy {
	@HostBinding('style.display') display = 'block';
	@Input() public session: SessionState;
	@Input() public settings;
	@Input() public changeTab;
	@Input() public brokerForm;
	@Input() brokers;
	@Input() broker;
	public selectedBroker;
	@Output() public emitSelectedBroker = new EventEmitter();
	public url: RouterState;
	public urlState: Observable<RouterState>;
	public subscriptions: Subscription[] = [];

	public currentIndex = 0;

	constructor (
		private sanitizer: DomSanitizer,
		private cd: ChangeDetectorRef,
		private store: Store<any>,
	) {
	}

	ngOnInit () {
		this.changeTab.subscribe(tab => {
			this.currentIndex = tab;
			this.cd.detectChanges();
		});
		this.urlState = this.store.select('routerState');
		const urlSubscription = this.urlState.subscribe(url => {
			this.url = url;
			this.cd.detectChanges();
		});
		this.subscriptions.push(urlSubscription);
	}

	public ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public emitSelected(value) {
		this.selectedBroker = value;
		this.emitSelectedBroker.emit(value);
	}

}
