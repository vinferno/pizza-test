import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageSmartComponent } from './agent-manage-smart.component';

describe('AgentManageSmartComponent', () => {
  let component: AgentManageSmartComponent;
  let fixture: ComponentFixture<AgentManageSmartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageSmartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageSmartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
