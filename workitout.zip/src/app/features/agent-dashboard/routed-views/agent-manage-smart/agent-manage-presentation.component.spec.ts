import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManagePresentationComponent } from './agent-manage-presentation.component';

describe('AgentManagePresentationComponent', () => {
  let component: AgentManagePresentationComponent;
  let fixture: ComponentFixture<AgentManagePresentationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManagePresentationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManagePresentationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
