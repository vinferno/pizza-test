import { Component, HostBinding, OnInit, OnDestroy } from '@angular/core';
import { BehaviorSubject, interval } 				 from 'rxjs';
import { Store }                  					 from '@ngrx/store';
import { AgentsDashboardService }  					 from '../../utils/agent-dashboard.service';
import { MatDialog } 								 from '@angular/material/dialog';
import { ModalService }            					 from '../../../../infrastructure/core/services/modal.service';
import { ActivatedRoute, Router }  					 from '@angular/router';
import { stateActions }            					 from '../../../../infrastructure/store/reducers/reducers-index';
import { AgentsManageService }     					 from '../../utils/agents-manage.service';
import { FormBuilder }             					 from '@angular/forms';

@Component({
  selector: 'hg-agent-manage-smart',
  templateUrl: './agent-manage-smart.component.html',
  styleUrls: ['./agent-manage-smart.component.scss']
})
export class AgentManageSmartComponent implements OnInit, OnDestroy {
	@HostBinding('style.display') display = 'block';
	public sessionState;
	public session;
	public settings;

	public changeTab = new BehaviorSubject(0);

	public reports: any[] = [];
	public reportHistory;
	public recentReports;
	public reportsState;
	public subscriptions = [];
	public agentSearchResults;
	public includeDisabled = false;
	public brokerForm = null;
	public brokers = [];
	public broker;

	private currentSelectedbroker;

	constructor (
		private store: Store<any>,
		private agentsDashboardService: AgentsManageService,
		public dialog: MatDialog,
		public modals: ModalService,
		public router: Router,
		public route: ActivatedRoute,
		private fb: FormBuilder,
	) {
	}

	ngOnInit () {
		this.brokerForm = this.fb.group({broker: null});
		const sessionSub = this.store.select('sessionState').subscribe(session => {
			this.session = session;
			if (!this.currentSelectedbroker || this.currentSelectedbroker !== session.agent.brokerID ) {
				this.currentSelectedbroker = session.agent.brokerID;
				this.updateWorkingBroker({ Id: session.agent.brokerID});
			}
		});
		this.subscriptions.push(sessionSub);
		const settingsSub = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSub);
		this.agentsDashboardService.getAgents({includeDisabled: this.includeDisabled}).subscribe(agents => this.agentSearchResults = agents);
		this.getReports();
		this.getRecentReports();
		const reportStateSub = this.store.select('reportsState').subscribe(reportsState => {
			this.reportsState = reportsState;
		});
		this.subscriptions.push(reportStateSub);
		const reportParam = this.route.paramMap.subscribe(params => {
			const tab = params.get('tab');
			if (tab === 'recent') {
				this.selectReportRecent();
			}
			if (tab === 'history') {
				this.selectReportHistory();
			}
		});
		this.subscriptions.push(reportParam);
		this.getBrokers();
	}

	ngOnDestroy () {
		this.store.dispatch(stateActions.reportsActions.updateOptions(null));
		this.subscriptions.forEach(sub => sub.unsubscribe())
	}

	public getReports () {
		let tempReports;
	}

	public getRecentReports () {
		let tempReports;

	}

	statusLookup (status) {
		if (status.toLowerCase() === 's') {
			return 'Submitted';
		}
		if (status.toLowerCase() === 'e') {
			return 'Executing';
		}
		if (status.toLowerCase() === 'c') {
			return 'Completed';
		}
		if (status.toLowerCase() === 'f') {
			return 'Failed';
		}
	}

	unpackReports (value: any, args: any[] = null): any {
		if (!value) {
			return []
		}
		return Object.keys(value)
					 .map(key => {
						 return {
							 key,
							 value: value[key],
						 }
					 });
	}

	public openDialog (report): void {
		this.goToBuilder(report);
	}

	public selectReportRecent () {
		this.changeTab.next(1);
	}

	public selectReportHistory () {
		this.changeTab.next(2);
	}

	public goToBuilder (report) {
		this.store.dispatch(stateActions.reportsActions.updateReport(report));
		this.router.navigateByUrl(`/counselor/reports/report-builder/${report.reportID}`);
	}

	public deleteReport(report) {
	}

	public getBrokers() {
		this.agentsDashboardService.getBrokers()
			.subscribe( (res: any[]) => this.brokers = res.sort(function(a, b) {
				const prop = 'name';
				const textA = a[prop].toUpperCase();
				const textB = b[prop].toUpperCase();
				return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
			}));
	}

	public updateWorkingBroker(value) {
		this.broker = null;
		this.agentsDashboardService.updateWorkingBroker(value).subscribe(broker => {
			this.broker = broker;
		});
	}
}
