import { Component, Input, OnInit } from '@angular/core';
import { TableColumns }             from '../../../../../infrastructure/interfaces/table-columns';
import { AgentsManageService }      from '../../../utils/agents-manage.service';
import { MatDialog } from "@angular/material/dialog";
import { NewAgentModalComponent }   from './new-agent-modal/new-agent-modal.component';
import { FormBuilder }              from '@angular/forms';

@Component({
	selector   : 'hg-agent-manage-agent',
	templateUrl: './agent-manage-agent.component.html',
	styleUrls  : ['./agent-manage-agent.component.scss'],
})
export class AgentManageAgentComponent implements OnInit {
	public agentSearchResults;
	public includeDisabled = false;
	public enableSave: boolean = false;
	@Input()
	public settings;
	public testForm;
	public virtualProperty = virtualProperty;
	public selectedDialogComponent = NewAgentModalComponent;
	public columnList: TableColumns[] = [
		{
			columnName: 'First Name',
			columnId  : 'firstName',
		},
		{
			columnName: 'Last Name',
			columnId  : 'lastName',
		},
		{
			columnName: 'User ID',
			columnId  : 'uid',
		},
		{
			columnName: 'Email',
			columnId  : 'email',
		},
		{
			columnName: 'Phone',
			columnId  : 'phone',
		},
		{
			columnName: 'Disabled',
			columnId  : 'disabled',
		},
	];
	public emptyGridMessage: string = 'No search results.';
	public agentList;

	constructor (
		private agentsManageService: AgentsManageService,
		private dialog: MatDialog,
		private fb: FormBuilder,
	) { }

	ngOnInit () {
		this.testForm = this.fb.group({test: ''});
		this.getAgents();
	}

	public getAgents () {
		this.agentsManageService.getAgents({ includeDisabled: this.includeDisabled })
			.subscribe(agents => {
				this.agentSearchResults = agents;
				this.agentList = agents;
			});
	}

	public saveDisabled () {
		this.agentsManageService
			.updateAgentsDisabled({
				disabled: this.agentSearchResults
							  .filter(agent => agent.disabled)
							  .map((agent) => agent.id),
				enabled : this.agentSearchResults
							  .filter(agent => !agent.disabled)
							  .map((agent) => agent.id),
			}).subscribe(() => {
			this.getAgents();
		});
	}

	public openDialog () {
		this.dialog.open(this.selectedDialogComponent, { disableClose: true }).afterClosed().subscribe(() => {
			this.getAgents();
		});
	}

	public showColumn (columnId) {
		const doNotShow = ['phone', 'disabled'];
		return !doNotShow.includes(columnId)
	}

	public formatPhone (phone) {
		let newVal = phone.replace(/\D/g, '');
		if (newVal.length === 0) {
			newVal = '';
		} else if (newVal.length <= 3) {
			newVal = newVal.replace(/^(\d{0,3})/, '($1)');
		} else if (newVal.length <= 6) {
			newVal = newVal.replace(/^(\d{0,3})(\d{0,3})/, '($1) $2');
		} else if (newVal.length <= 10) {
			newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(\d{0,4})/, '($1) $2-$3');
		} else {
			newVal = newVal.substring(0, 10);
			newVal = newVal.replace(/^(\d{0,3})(\d{0,3})(\d{0,4})/, '($1) $2-$3');
		}
		return newVal;
	}
	public changeList(list) {
		this.agentList = list;
	}
}

function virtualProperty(collection) {
	collection.forEach( item => {
		item.name = item.firstName + ' ' + item.lastName;
	});
}
