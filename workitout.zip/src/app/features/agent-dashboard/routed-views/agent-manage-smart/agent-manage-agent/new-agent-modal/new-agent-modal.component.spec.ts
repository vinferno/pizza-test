import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewAgentModalComponent } from './new-agent-modal.component';

describe('NewAgentModalComponent', () => {
  let component: NewAgentModalComponent;
  let fixture: ComponentFixture<NewAgentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewAgentModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewAgentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
