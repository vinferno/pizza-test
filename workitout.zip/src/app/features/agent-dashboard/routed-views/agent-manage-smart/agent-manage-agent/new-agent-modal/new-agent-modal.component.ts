import { Component, OnInit }                  from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from "@angular/material/dialog";
import { Store }                       from '@ngrx/store';
import { settings }                    from 'cluster';
import { SettingsState }               from '../../../../../../infrastructure/store/reducers/settings/settings-state';
import { AgentsManageService }         from '../../../../utils/agents-manage.service';
import { catchError }                  from 'rxjs/operators';
import { HttpErrorResponse }           from '@angular/common/http';
import { ResponseErrorHandlerService } from '../../../../../../infrastructure/core/services/response-error-handler.service';
import { validate }                    from 'codelyzer/walkerFactory/walkerFn';
import form                            from 'devextreme/ui/form';

@Component({
	selector   : 'hg-new-agent-modal',
	templateUrl: './new-agent-modal.component.html',
	styleUrls  : ['./new-agent-modal.component.scss'],
})
export class NewAgentModalComponent implements OnInit {
	public agentForm: FormGroup = null;
	public settings: SettingsState;
	public formDefault;
	public edit = {phone: ''};

	constructor (
		private fb: FormBuilder,
		public dialogRef: MatDialogRef<NewAgentModalComponent>,
		private store: Store<any>,
		private agentsManageService: AgentsManageService,
		private errors: ResponseErrorHandlerService,
	) { }

	ngOnInit () {

		this.formDefault = {
			firstName            : ['', Validators.compose([Validators.required])],
			middleName           : ['', Validators.compose([])],
			lastName             : ['', Validators.compose([Validators.required])],
			address              : ['', Validators.compose([])],
			city                 : ['', Validators.compose([])],
			state                : ['', Validators.compose([])],
			zipCode              : ['', Validators.compose([])],
			officePhone          : ['', Validators.compose([])],
			phoneExt             : ['', Validators.compose([])],
			phone                : ['', Validators.compose([])],
			fax                  : ['', Validators.compose([])],
			email                : ['', Validators.compose([Validators.required, Validators.email])],
			uID                  : ['', Validators.compose([])],
			systemAccessExpiresOn: ['', Validators.compose([])],
			type                 : ['', Validators.compose([Validators.required])],
			broker               : ['', Validators.compose([])],
			disableAccount       : ['', Validators.compose([])],
		};
		this.store.select('settingsState').subscribe( settings => {
			this.settings = settings;
		});
		this.agentForm = this.fb.group(this.formDefault);
	}

	public save() {
		this.saveEdit();
		this.edit.phone = this.edit.phone.replace(/\D/g, '');
		this.agentsManageService.agentCreateAgent(this.edit).subscribe( res => {
			this.edit = {phone: ''};
			this.dialogRef.close(res);
		}, ((error: HttpErrorResponse) => this.errors.handleError(error)));
	}

	public saveEdit () {
		Object.keys(this.formDefault).forEach(key => {
			this.edit[key] = this.agentForm.get(key).value;
		})
	}

	public cancel() {
		this.edit = {phone:''};
	}

	public closeDialog() {
		this.dialogRef.close();
	}

}
