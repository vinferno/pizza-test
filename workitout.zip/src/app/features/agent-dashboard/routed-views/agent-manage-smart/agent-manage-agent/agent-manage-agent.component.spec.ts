import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentManageAgentComponent } from './agent-manage-agent.component';

describe('AgentManageAgentComponent', () => {
  let component: AgentManageAgentComponent;
  let fixture: ComponentFixture<AgentManageAgentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentManageAgentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentManageAgentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
