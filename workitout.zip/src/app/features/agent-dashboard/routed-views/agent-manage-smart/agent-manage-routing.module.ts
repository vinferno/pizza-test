import { NgModule }                                	from '@angular/core';
import { RouterModule, Routes }                    	from '@angular/router';

import { AgentDashboardGuard }                     	from '../../utils/guards/agent-dashboard.guard';
import { agentDashboardResolvers }                 	from '../../utils/resolvers/agent-dashboard/agent-dashboard-resolvers';
import { AgentManageAgentComponent }               	from './agent-manage-agent/agent-manage-agent.component';
import { AgentManageSmartComponent }			   	from './agent-manage-smart.component';
import { AgentManagePresentationComponent }         from './agent-manage-presentation.component';
import { AgentManageAgentAssignComponent }         	from './agent-manage-agent-assign/agent-manage-agent-assign.component';
import { AgentManageCarrierInfoComponent }		   	from './agent-manage-carrier-info/agent-manage-carrier-info.component';
import { AgentManageCompanyAssignComponent }       	from './agent-manage-company-assign/agent-manage-company-assign.component';
import { AgentManageEditComponent }                 from './agent-manage-edit/agent-manage-edit.component';
import { AgentManageNotAssignedToCompanyComponent } from './agent-manage-company-assign/agent-manage-not-assigned-to-company/agent-manage-not-assigned-to-company.component';
import { AgentManageUnassignedCompaniesComponent }  from './agent-manage-agent-assign/agent-manage-unassigned-companies/agent-manage-unassigned-companies.component';
import { TitleResolver }                           	from '../../../../infrastructure/core/resolvers/title.resolver';

const routes: Routes = [
	{
		path       : '',
		component  : AgentManageSmartComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path     : 'manage-agents',
				component: AgentManageAgentComponent,
			},
			{
				path     : 'company-assign',
				component: AgentManageCompanyAssignComponent,
			},
			{
				path     : 'agent-assign',
				component: AgentManageAgentAssignComponent,
			},
			{
				path     : 'carrier-info',
				component: AgentManageCarrierInfoComponent,
			},
			{
				path     : 'edit-agents',
				component: AgentManageEditComponent,
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class AgentManageRoutingModule { }

export const routedComponents = [
	AgentManageAgentComponent,
	AgentManageSmartComponent,
	AgentManagePresentationComponent,
	AgentManageAgentAssignComponent,
	AgentManageCarrierInfoComponent,
	AgentManageCompanyAssignComponent,
	AgentManageAgentAssignComponent,
	AgentManageUnassignedCompaniesComponent,
	AgentManageNotAssignedToCompanyComponent,
	AgentManageEditComponent,
];
