import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                            from '@angular/core';

import { AgentSearchResult } from '../../../../infrastructure/interfaces/agent';
import { animator }          from '../../../../infrastructure/core/animations/animations';
import { SettingsState }     from '../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }      from '../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-agent-history-presentation',
	templateUrl     : './agent-history-presentation.component.html',
	styleUrls       : ['./agent-history-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentHistoryPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public agentHistoryResults: AgentSearchResult[];
	@Input() public columnList: TableColumns;
	@Input() public emptyGridMessage: string;
	@Input() public settings: SettingsState;

	@Output() public emitAddMember: EventEmitter<AgentSearchResult> = new EventEmitter();

	public addMember(member: AgentSearchResult): void {
		this.emitAddMember.emit(member);
	}
}
