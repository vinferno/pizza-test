import {
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                 from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subject,
	Subscription,
}                                 from 'rxjs';
import { exhaustMap, tap }        from 'rxjs/operators';

import {
	AgentConfirmMember,
	AgentSearchResult,
}                                 from '../../../../infrastructure/interfaces/agent';
import { AgentsDashboardService } from '../../utils/agent-dashboard.service';
import { MembersService }         from '../../../../infrastructure/core/services/members.service';
import { FormService }            from '../../../../infrastructure/shared/controls/form/form.service';
import { stateActions }           from '../../../../infrastructure/store/reducers/reducers-index';
import { SettingsState }          from '../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from 'app/infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-agent-history-smart',
	template        :
		`<hg-agent-history-presentation
			[agentHistoryResults]="agentHistoryResults"
			[columnList]="columnList"
			[emptyGridMessage]="emptyGridMessage"
			[settings]="(settingsState$ | async)"
			(emitAddMember)="subject$.next($event)"
		></hg-agent-history-presentation>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentHistorySmartComponent implements OnInit, OnDestroy {
	public agentConfirmMember: AgentConfirmMember;
	public agentHistoryResults: AgentSearchResult[];
	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId  : 'memberName',
		},
		{
			columnName: 'Company',
			columnId  : 'companyName',
		},
		{
			columnName: 'Last 4 SSN',
			columnId  : 'ssn',
			width     : 100,
		},
	];
	public emailForm: FormGroup;
	public emptyGridMessage: string = 'No search results.';
	public selectedMember: AgentSearchResult = null;
	public settings: SettingsState;
	public settingsState$: Observable<SettingsState>;
	public subject$ = new Subject<AgentSearchResult>();

	private subscriptions: Subscription[] = [];

	constructor (
		public agentDashboardService: AgentsDashboardService,
		private fb: FormBuilder,
		private formService: FormService,
		public membersService: MembersService,
		private route: ActivatedRoute,
		public router: Router,
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.agentHistoryResults = this.route.snapshot.data['history'];
		this.initializeState();
		this.addMemberListener();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public confirmMember(): void {
		this.router.navigateByUrl('/counselor/member-confirm');
	}

	private initializeState(): void {
		this.settingsState$ = this.store.select('settingsState');
	}

	private addMemberListener(): void {
		const addMemberSubscription = this.subject$
			.pipe(
				tap(member => {
					this.selectedMember = member;
					this.agentDashboardService.agentDashboardForm.get('selectedMember').setValue(member);
				}),
				exhaustMap(() => this.membersService.getMemberConfirm(this.selectedMember.systemNumber)),
			)
			.subscribe((response) => {
				this.store.dispatch(stateActions.sessionActions.updateAgent({ callerID: null }));
				this.agentConfirmMember = response;
				this.agentDashboardService.agentDashboardForm.get('agentConfirmMember').setValue(response);
				this.agentDashboardService.agentDashboardForm.addControl('emailForm', this.buildForm());
				this.confirmMember();
			});
		this.subscriptions.push(addMemberSubscription);
	}

	private buildForm(): FormGroup {
		const emailForm = this.fb.group({
			email: [''],
		});

		this.buildDynamicField(emailForm);

		return emailForm;
	}

	private buildDynamicField(form: FormGroup): FormGroup {
		if (this.agentConfirmMember.showCallerID) { this.formService.addFormControl(form, 'callerID', []); }

		return form;
	}
}
