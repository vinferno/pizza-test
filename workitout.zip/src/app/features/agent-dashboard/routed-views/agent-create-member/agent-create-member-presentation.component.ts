import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                                 from '@angular/core';
import { FormGroup }              from '@angular/forms';

import { AgentCreateMemberModel } from '../../../../infrastructure/interfaces/agent';
import { animator }               from '../../../../infrastructure/core/animations/animations';
import { IError }                 from '../../../../infrastructure/interfaces/error';
import { SessionState }           from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }          from '../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-agent-create-member-presentation',
	templateUrl     : './agent-create-member-presentation.component.html',
	styleUrls       : ['./agent-create-member-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCreateMemberPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public createMemberError: IError = {
		header     : '',
		description: 'Please contact your HR Administrator if you have any questions.',
	};
	@Input() public disableInput: boolean;
	@Input() public disableNewMemberFormSubmit: boolean;
	@Input() public enabledCompaniesForm: FormGroup;
	@Input() public genericError: string;
	@Input() public isCreateMemberInvalid: boolean = false;
	@Input() public memberSearchForm: FormGroup;
	@Input() public newMemberForm: FormGroup;
	@Input() public newMemberModel: AgentCreateMemberModel;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public companyDropDownSelect: EventEmitter<void> = new EventEmitter();
	@Output() public emitCreateMember: EventEmitter<void> = new EventEmitter();
	@Output() public emitGetCompanyCreateMemberModel: EventEmitter<void> = new EventEmitter();

	constructor () { }

	public createMember(): void {
		this.emitCreateMember.emit()
	}

	public getCompanyCreateMemberModel(): void {
		this.emitGetCompanyCreateMemberModel.emit();
	}

	public selectCompany(): void {
		this.companyDropDownSelect.emit();
	}
}
