import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
	OnDestroy,
}                                 from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
	Validators,
}                                 from '@angular/forms';
import { Router }                 from '@angular/router';

import * as moment                from 'moment';
import { Store }                  from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                 from 'rxjs';

import {
	AgentCreateMemberModel,
	AgentCreateMemberModelPayload,
	AgentCreateMemberPayload,
	AgentCreateMemberResponse,
	AgentMemberLogin,
	AgentSearchResult,
}                                 from '../../../../infrastructure/interfaces/agent';
import { AgentAuthService }       from 'app/infrastructure/auth/agent-auth.service';
import { AgentsDashboardService } from '../../utils/agent-dashboard.service';
import { AuthService }            from '../../../../infrastructure/auth/auth.service';
import { Constants }              from '../../../../infrastructure/utils/constants';
import { FormService }            from '../../../../infrastructure/shared/controls/form/form.service';
import { IError }                 from '../../../../infrastructure/interfaces/error';
import { ICompanyMembership }     from '../../../../infrastructure/interfaces/company-membership';
import { MembersService }         from '../../../../infrastructure/core/services/members.service';
import { SessionState }           from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }          from '../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }           from '../../../../infrastructure/store/reducers/reducers-index';

@Component({
	template        :
		`<div class="page">
			<hg-agent-create-member-presentation
				[session]="session"
				[settings]="(settingsState$ | async)"
				[newMemberForm]="newMemberForm"
				[enabledCompaniesForm]="enabledCompaniesForm"
				[genericError]="genericError"
				[newMemberModel]="newMemberModel"
				[createMemberError]="createMemberError"
				[isCreateMemberInvalid]="isCreateMemberInvalid"
				[disableNewMemberFormSubmit]="disableNewMemberFormSubmit()"
				(companyDropDownSelect)="selectCompany()"
				(emitGetCompanyCreateMemberModel)="getCompanyCreateMemberModel()"
				(emitCreateMember)="createMember()"
			></hg-agent-create-member-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCreateMemberSmartComponent implements OnInit, OnDestroy {
	public createMemberError: IError;
	public emailForm: FormGroup;
	public enabledCompaniesForm: FormGroup;
	public genericError: string = Constants.genericFormError;
	public isCreateMemberInvalid: boolean = false;
	public newMemberForm: FormGroup;
	public newMemberModel: AgentCreateMemberModel;
	public oldMemberForm: FormGroup;
	public selectedCompanyName: string = '';
	public selectedMember: AgentSearchResult = null;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private agentsDashboardService: AgentsDashboardService,
		public agentAuthService: AgentAuthService,
		private fb: FormBuilder,
		private formService: FormService,
		public membersService: MembersService,
		public router: Router,
		private store: Store<any>,
	) { }

	ngOnInit() {
		this.initializeState();
		this.initializeAgentSubscription();
		this.initializeForms();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public selectCompany(): void {
		this.getCompanyCreateMemberModel();
	}

	public getCompanyCreateMemberModel(): void {
		if (!this.enabledCompaniesForm.controls['company'].value.companyID) { return; }
		const payload: AgentCreateMemberModelPayload = {
			companyID: this.enabledCompaniesForm.controls['company'].value.companyID,
		};

		this.newMemberModel = null;
		this.agentsDashboardService.createMemberModel(payload).subscribe(response => {
				this.isCreateMemberInvalid = false;
				this.selectedCompanyName = this.enabledCompaniesForm.controls['company'].value.companyName;
				this.newMemberModel = response;
				if (this.newMemberForm) {
					this.oldMemberForm = this.newMemberForm;
					this.newMemberForm = null;
					this.newMemberForm = this.buildForm();
				} else {
					this.newMemberForm = this.buildDynamicFields(this.newMemberForm);
				}
			},
			error => {
				this.createMemberError = error;
				this.isCreateMemberInvalid = true;
			});
	}

	public disableNewMemberFormSubmit(): boolean {
		return this.newMemberForm.valid;
	}

	public createMember(): void {
		const payload: AgentCreateMemberPayload = this.buildCreateMemberPayload();

		this.agentsDashboardService.createMember(payload).subscribe(response => {
				this.isCreateMemberInvalid = false;
				this.confirmNewMember(response);
			},
			error => {
				this.createMemberError = error;
				this.isCreateMemberInvalid = true;
			});
	}

	public confirmNewMember(member: AgentCreateMemberResponse): void {
		this.selectedMember = new AgentSearchResult();
		for (const property in member) {
			if (member.hasOwnProperty(property)) { this.selectedMember[property] = member[property]; }
		}
		this.confirmMember();
	}

	public confirmMember(): void {
		const payload: AgentMemberLogin = {
			systemNumber: this.selectedMember.systemNumber,
			homeEmail   : this.selectedMember.homeEmail,
			agentID     : this.session.agent.agentID,
		};
		this.membersService.confirm(payload).subscribe(() => {
			this.agentAuthService.setMembership(this.selectedMember.systemNumber).subscribe(
				() => {
					this.isCreateMemberInvalid = false;
					const selectedMember: ICompanyMembership = {
						systemNumber      : this.selectedMember.systemNumber,
						memberName        : this.selectedMember.memberName,
						companyName       : this.selectedMember.companyName,
						isVerified        : this.selectedMember.isVerified,
					};
					this.store.dispatch(stateActions.sessionActions.updateSelectedMember({ selectedMember }));
					this.router.navigateByUrl('/dashboard');
					this.store.dispatch(stateActions.sessionActions.updateMemberList({ memberList: [selectedMember] }));
				},
				error => {
					this.createMemberError = error;
					this.isCreateMemberInvalid = true;
				},
			);
		});
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
	}

	private initializeAgentSubscription(): void {
		this.agentsDashboardService.getAgentEnabledCompaniesToCreateMembers().subscribe(agentCreateMemberCompanies => {
				this.isCreateMemberInvalid = false;
				this.store.dispatch(stateActions.sessionActions.updateAgent({ agentCreateMemberCompanies }));
			},
			error => {
				this.createMemberError = error;
				this.isCreateMemberInvalid = true;
			});
	}

	private initializeForms(): void {
		this.newMemberForm = this.fb.group({
			homeEmail        : new FormControl(''),
			homePhone        : new FormControl(''),
			cellPhone        : new FormControl(''),
			dateOfHire       : new FormControl(null),
			dateOfBirth      : new FormControl(null),
			firstName        : new FormControl(''),
			middleName       : new FormControl(''),
			lastName         : new FormControl(''),
			workJobTitle     : new FormControl(''),
			workEmail        : new FormControl(''),
			workPhone        : new FormControl(''),
			homeAddressLine1 : new FormControl(''),
			homeAddressLine2 : new FormControl(''),
			homeCity         : new FormControl(''),
			homeState        : new FormControl(''),
			homeZipCode      : new FormControl(''),
			gender           : new FormControl(''),
			ssnDecrypted     : new FormControl(''),
			employmentStatus : new FormControl(''),
			workHours        : new FormControl(null),
		});
		this.enabledCompaniesForm = this.fb.group({
			company: ['', Validators.compose([Validators.required])],
		});
	}

	private buildForm(): FormGroup {
		const newMemberForm = this.fb.group({
			homeEmail        : new FormControl((this.oldMemberForm.get('homeEmail').value) ? this.oldMemberForm.get('homeEmail').value : ''),
			homePhone        : new FormControl((this.oldMemberForm.get('homePhone').value) ? this.oldMemberForm.get('homePhone').value : ''),
			cellPhone        : new FormControl((this.oldMemberForm.get('cellPhone').value) ? this.oldMemberForm.get('cellPhone').value : ''),
			dateOfHire       : new FormControl((this.oldMemberForm.get('dateOfHire').value) ? this.oldMemberForm.get('dateOfHire').value : null),
			dateOfBirth      : new FormControl((this.oldMemberForm.get('dateOfBirth').value) ? this.oldMemberForm.get('dateOfBirth').value : null),
			workHours        : new FormControl((this.oldMemberForm.get('workHours').value) ? this.oldMemberForm.get('workHours').value : null),
			firstName        : new FormControl((this.oldMemberForm.get('firstName').value) ? this.oldMemberForm.get('firstName').value : ''),
			middleName       : new FormControl((this.oldMemberForm.get('middleName').value) ? this.oldMemberForm.get('middleName').value : ''),
			lastName         : new FormControl((this.oldMemberForm.get('lastName').value) ? this.oldMemberForm.get('lastName').value : ''),
			workJobTitle     : new FormControl((this.oldMemberForm.get('workJobTitle').value) ? this.oldMemberForm.get('workJobTitle').value : ''),
			workEmail        : new FormControl((this.oldMemberForm.get('workEmail').value) ? this.oldMemberForm.get('workEmail').value : ''),
			workPhone        : new FormControl((this.oldMemberForm.get('workPhone').value) ? this.oldMemberForm.get('workPhone').value : ''),
			homeAddressLine1 : new FormControl((this.oldMemberForm.get('homeAddressLine1').value) ? this.oldMemberForm.get('homeAddressLine1').value : ''),
			homeAddressLine2 : new FormControl((this.oldMemberForm.get('homeAddressLine2').value) ? this.oldMemberForm.get('homeAddressLine2').value  : ''),
			homeCity         : new FormControl((this.oldMemberForm.get('homeCity').value) ? this.oldMemberForm.get('homeCity').value : ''),
			homeState        : new FormControl((this.oldMemberForm.get('homeState').value) ? this.oldMemberForm.get('homeState').value : ''),
			homeZipCode      : new FormControl((this.oldMemberForm.get('homeZipCode').value) ? this.oldMemberForm.get('homeZipCode').value : ''),
			gender           : new FormControl((this.oldMemberForm.get('gender').value) ? this.oldMemberForm.get('gender').value : ''),
			ssnDecrypted     : new FormControl((this.oldMemberForm.get('ssnDecrypted').value) ? this.oldMemberForm.get('ssnDecrypted').value : ''),
			employmentStatus : new FormControl((this.oldMemberForm.get('employmentStatus').value) ? this.oldMemberForm.get('employmentStatus').value : ''),
		});

		this.buildDynamicFields(newMemberForm);

		return newMemberForm;
	}

	private buildDynamicFields(form: FormGroup): FormGroup {
		if (this.newMemberModel.showErid) { this.formService.addFormControl(form, 'erid', []); }
		if (this.newMemberModel.showPayrollNumber) { this.formService.addFormControl(form, 'payrollNumber', []); }
		if (this.newMemberModel.showDivision) { this.formService.addFormControl(form, 'division', []); }
		if (this.newMemberModel.showEEClass1) { this.formService.addFormControl(form, 'eEClass1', []); }
		if (this.newMemberModel.showEEClass2) { this.formService.addFormControl(form, 'eEClass2', []); }
		if (this.newMemberModel.showEEClass3) { this.formService.addFormControl(form, 'eEClass3', []); }
		if (this.newMemberModel.showEEClass4) { this.formService.addFormControl(form, 'eEClass4', []); }
		if (this.newMemberModel.showEEClass5) { this.formService.addFormControl(form, 'eEClass5', []); }
		if (this.newMemberModel.showCompanyLocation) { this.formService.addFormControl(form, 'companyLocation', []); }
		if (this.newMemberModel.showSalary1) {
			this.formService.addFormControl(form, 'salary1', []);
			this.formService.addFormControl(form, 'salary1Frequency', []);
		}
		if (this.newMemberModel.showSalary2) {
			this.formService.addFormControl(form, 'salary2', []);
			this.formService.addFormControl(form, 'salary2Frequency', []);
		}
		if (this.newMemberModel.showSalary3) {
			this.formService.addFormControl(form, 'salary3', []);
			this.formService.addFormControl(form, 'salary3Frequency', []);
		}
		if (this.newMemberModel.showUdf1) { this.formService.addFormControl(form, 'udf1', []); }
		if (this.newMemberModel.showUdf2) { this.formService.addFormControl(form, 'udf2', []); }
		if (this.newMemberModel.showUdf3) { this.formService.addFormControl(form, 'udf3', []); }
		if (this.newMemberModel.showUdf4) { this.formService.addFormControl(form, 'udf4', []); }
		if (this.newMemberModel.showUdf5) { this.formService.addFormControl(form, 'udf5', []); }

		return form;
	}

	private buildCreateMemberPayload(): AgentCreateMemberPayload {
		const payload: AgentCreateMemberPayload = new AgentCreateMemberPayload;
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				if (this.newMemberForm.controls[property] && this.newMemberForm.controls[property].value) {
					if (property === 'ssnDecrypted' || property === 'homePhone' || property === 'cellPhone' || property === 'workPhone' || property === 'homeZipCode') {
						payload[property] = this.newMemberForm.controls[property].value.replace(Constants.patterns.NON_DECIMAL_DIGITS, '');
					} else if (property === 'salary1' || property === 'salary2' || property === 'salary3') {
						payload[property] = this.newMemberForm.controls[property].value.replace(Constants.patterns.DECIMAL_DIGITS_ONLY, '');
					} else if (property === 'workHours') {
						payload[property] = Number(this.newMemberForm.controls[property].value);
					} else {
						payload[property] = this.newMemberForm.controls[property].value;
					}
				}
			}
		}
		payload.companyID = this.enabledCompaniesForm.controls['company'].value.companyID;

		// explicitly convert dates to ISO strings
		payload.dateOfBirth = moment(this.newMemberForm.value.dateOfBirth).toISOString();
		payload.dateOfHire = moment(this.newMemberForm.value.dateOfHire).toISOString();


		return payload;
	}
}
