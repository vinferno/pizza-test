import {
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
 }                       from '@angular/core';

import { Store }         from '@ngrx/store';
import {
	Observable,
	Subscription,
}                        from 'rxjs';

import { animator }      from '../../../../infrastructure/core/animations/animations';
import { INavigation }   from 'app/infrastructure/interfaces/navigation';
import { SessionState }  from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState } from '../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector    : 'hg-agent-follow-ups',
	templateUrl : './agent-follow-ups.component.html',
	styleUrls   : ['./agent-follow-ups.component.scss'],
	animations  : [animator.slide],
})
export class AgentFollowUpsComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public navLinks: INavigation[]  = [
		{
			label : 'Open Follow Ups',
			link  : '/counselor/follow-ups',
		},
		{
			label : 'Completed Follow Ups',
			link  : '/counselor/completed-follow-ups',
		},
	];
	public session: SessionState;
	public settings: SettingsState;

	private sessionState: Observable<SessionState>;
	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
		this.checkForSupervisor();
	}

	public ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public trackByLink(index: number, item): number {
		return (item) ? item.link : null;
	}

	private initializeState(): void {
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.sessionState.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
	}

	private checkForSupervisor(): void {
		if (this.session && this.session.agent && this.session.agent.isSupervisor) {
			const managementLink = {
				label : 'Follow Up Management',
				link  : '/counselor/follow-up-management',
			}

			this.navLinks.push(managementLink);
		}
	}
}
