import { NgModule }                                    from '@angular/core';
import { RouterModule, Routes }                        from '@angular/router';

import { AgentDashboardGuard }                         from '../../utils/guards/agent-dashboard.guard';
import { agentDashboardResolvers }                     from '../../utils/resolvers/agent-dashboard/agent-dashboard-resolvers';
import { AgentFollowUpsComponent }                     from './agent-follow-ups.component';
import { CompletedFollowUpGridPresentationComponent }  from './completed-follow-up-grid/completed-follow-up-grid-presentation.component';
import { CompletedFollowUpGridSmartComponent }         from './completed-follow-up-grid/completed-follow-up-grid-smart.component';
import { FollowUpGridPresentationComponent }           from './follow-up-grid/follow-up-grid-presentation.component';
import { FollowUpGridSmartComponent }                  from './follow-up-grid/follow-up-grid-smart.component';
import { FollowUpDetailPresentationComponent }         from './follow-up-detail/follow-up-detail-presentation.component';
import { FollowUpDetailSmartComponent }                from './follow-up-detail/follow-up-detail-smart.component';
import { FollowUpManagementGridPresentationComponent } from './follow-up-management-grid/follow-up-management-grid-presentation.component';
import { FollowUpManagementGridSmartComponent }        from './follow-up-management-grid/follow-up-management-grid-smart.component';
import { ReassignFollowUpsComponent }                  from './follow-up-management-grid/reassign-follow-ups/reassign-follow-ups.component';
import { TitleResolver }                               from '../../../../infrastructure/core/resolvers/title.resolver';

const routes: Routes = [
	{
		path       : '',
		component  : AgentFollowUpsComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path     : 'completed-follow-ups',
				component: CompletedFollowUpGridSmartComponent,
				resolve  : {
					scheduledEventList: agentDashboardResolvers.AgentCompletedFollowUpsResolver,
				},
			},
			{
				path     : 'follow-ups',
				component: FollowUpGridSmartComponent,
				resolve  : {
					scheduledEventList: agentDashboardResolvers.AgentFollowUpsResolver,
				},
			},
			{
				path     : 'follow-up-detail',
				component: FollowUpDetailSmartComponent,
				resolve  : {
					scheduledEvent: agentDashboardResolvers.AgentFollowUpDetailResolver,
				},
			},
			{
				path     : 'follow-up-management',
				component: FollowUpManagementGridSmartComponent,
				resolve  : {
					scheduledEventList: agentDashboardResolvers.AgentFollowUpManagementResolver,
				},
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class AgentFollowUpsRoutingModule { }

export const routedComponents = [
	AgentFollowUpsComponent,
	CompletedFollowUpGridSmartComponent,
	CompletedFollowUpGridPresentationComponent,
	FollowUpGridPresentationComponent,
	FollowUpGridSmartComponent,
	FollowUpDetailPresentationComponent,
	FollowUpDetailSmartComponent,
	FollowUpManagementGridPresentationComponent,
	FollowUpManagementGridSmartComponent,
	ReassignFollowUpsComponent,
];

export const entryComponents = [
	ReassignFollowUpsComponent,
];
