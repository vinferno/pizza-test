import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                           from '@angular/core';
import {
	ActivatedRoute,
	Router,
}                           from '@angular/router';

import { Store }            from '@ngrx/store';
import {
	Observable,
	Subscription,
}                           from 'rxjs';

import { AgentsCRMService } from '../../../utils/agents-crm.service';
import {
	AgentFilterPayload,
	ScheduledEvent,
	ScheduledEventCompletePayload,
	ScheduledEventsList,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { RouterState }      from '../../../../../infrastructure/store/reducers/router/router-state';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }    from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }     from '../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns }     from '../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-follow-up-grid',
	template        :
		`<div class="page">
			<hg-follow-up-grid-presentation
				[scheduledEventList]="scheduledEventList"
				[columnList]="columnList"
				[editButtonLabel]="editButtonLabel"
				[emptyGridMessage]="emptyGridMessage"
				[session]="session"
				[settings]="(settingsState$ | async)"
				(emitComplete)="markEventAsComplete($event)"
				(emitSelect)="navigateToDetailPage($event)"
			>
			</hg-follow-up-grid-presentation>
		</div>
		`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpGridSmartComponent implements OnInit, OnDestroy {
	@Input() public scheduledEventList: ScheduledEventsList;

	public columnList: TableColumns[] = [
		{
			columnName: 'Subject',
			columnId  : 'subject',
		},
		{
			columnName: 'Assigned',
			columnId  : 'agentAssignedTo.name',
		},
		{
			columnName: 'Event Type',
			columnId  : 'eventType.scheduledEventTypeLabel',
		},
		{
			columnName: 'Date',
			columnId  : 'dueDate',
		},
	];
	public editButtonLabel: string = 'Update Event';
	public emptyGridMessage: string = 'No follow ups currently available.';
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;
	public url: RouterState;

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];
	private urlState$: Observable<RouterState>;

	constructor (
		private agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		if (this.route.snapshot.data['scheduledEventList']) {
			this.scheduledEventList = this.route.snapshot.data['scheduledEventList'];
		}
	}

	public ngOnInit(): void {
		this.initializeState();
	}

	public ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public navigateToDetailPage(cell: ScheduledEvent): void {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ scheduledEvent: cell }));

		if (this.url && this.url.current.url) {
			switch (this.url.current.url) {
				case '/counselor/follow-ups':
					this.router.navigate(['counselor/follow-up-detail']);
					break;
				case '/counselor/customer-relations/member-follow-up/open':
					this.router.navigate(['counselor/customer-relations/member-follow-up/detail']);
					break;
			}
		}
	}

	public markEventAsComplete(event: ScheduledEvent): void {
		const payload: ScheduledEventCompletePayload =  {
			scheduledEventID : event.scheduledEventID,
			appendNote       : event.note,
		}
		this.agentsCRMService.completeEvent(payload).subscribe(() => this.refreshScheduledEventsGrid());
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
		this.urlState$ = this.store.select('routerState');
		const urlSubscription = this.urlState$.subscribe(url => {
			this.url = url;
			this.cd.detectChanges();
		});
		this.subscriptions.push(urlSubscription);
	}

	private refreshScheduledEventsGrid(): void {
		(this.session.selectedMember && this.session.selectedMember.systemNumber)
			? this.getMemberScheduledEvents()
			: this.getScheduledEvents();
	}

	private getMemberScheduledEvents(): void {
		const payload: AgentFilterPayload = {
			agentID      : this.session.agent.agentID,
			systemNumber : this.session.selectedMember.systemNumber,
		};
		this.agentsCRMService.getMemberScheduledEvents(payload).subscribe(response => {
			this.scheduledEventList = response;
			this.cd.detectChanges();
		});
	}

	private getScheduledEvents(): void {
		const payload: AgentFilterPayload = {
			agentID      : this.session.agent.agentID,
			systemNumber : null,
		};
		this.agentsCRMService.getScheduledEvents(payload).subscribe(response => {
			this.scheduledEventList = response;
			this.cd.detectChanges();
		});
	}
}
