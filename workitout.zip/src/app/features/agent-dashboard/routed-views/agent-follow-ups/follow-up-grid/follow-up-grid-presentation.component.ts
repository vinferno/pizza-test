import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
	Output,
	EventEmitter,
}                        from '@angular/core';

import {
	ScheduledEventsList,
	ScheduledEvent,
}                        from '../../../../../infrastructure/interfaces/agent-crm';
import { animator }      from '../../../../../infrastructure/core/animations/animations';
import { SettingsState } from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }  from '../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }  from '../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-follow-up-grid-presentation',
	templateUrl     : './follow-up-grid-presentation.component.html',
	styleUrls       : ['./follow-up-grid-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpGridPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public scheduledEventList: ScheduledEventsList;
	@Input() public columnList: TableColumns[] = [];
	@Input() public editButtonLabel: string = 'Update Event';
	@Input() public emptyGridMessage: string;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitComplete = new EventEmitter<ScheduledEvent>();
	@Output() public emitSelect = new EventEmitter<ScheduledEvent>();

	public newEvent: ScheduledEvent = new ScheduledEvent();

	public selectCell(event: ScheduledEvent): void {
		this.emitSelect.emit(event);
	}

	public completeEvent(event: ScheduledEvent): void {
		this.emitComplete.emit(event);
	}

	public trackByColumnID(index: number, item): number {
		return (item) ? item.columnID : null;
	}
}
