import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Inject,
	OnDestroy,
	OnInit,
}                           from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                           from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { Store }            from '@ngrx/store';
import {
	Observable,
	Subscription,
}                           from 'rxjs';

import { AgentsCRMService } from '../../../../utils/agents-crm.service';
import { Constants }        from '../../../../../../infrastructure/utils/constants';
import { ModalService }     from '../../../../../../infrastructure/core/services/modal.service';
import {
	ReassignScheduledEventListPayload,
	ScheduledEventsList,
}                           from '../../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }     from '../../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }    from '../../../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-reassign-follow-ups',
	templateUrl     : './reassign-follow-ups.component.html',
	styleUrls       : ['./reassign-follow-ups.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class ReassignFollowUpsComponent implements OnInit, OnDestroy {
	public form: FormGroup;
	public session: SessionState;
	public settings: SettingsState;

	private sessionState: Observable<SessionState>;
	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor (
		@Inject(MAT_DIALOG_DATA) public scheduledEventList: ScheduledEventsList,
		private agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
		private dialogRef: MatDialogRef<ReassignFollowUpsComponent>,
		private fb: FormBuilder,
		private modalService: ModalService,
		private store: Store<any>,
	) {
		this.form = this.buildForm();
	}

	ngOnInit() {
		this.initializeState();
		this.modalService.addModal(this.dialogRef);
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public isValid(): boolean {
		return !!(this.form.get('agentAssignedTo').value) && this.form.get('agentAssignedTo').value !== Constants.emptyInt;
	}

	public reassignFollowUpList(): void {
		const payload: ReassignScheduledEventListPayload = {
			agentAssignedTo: this.form.get('agentAssignedTo').value.agentID,
			scheduledEventIDs: this.scheduledEventList.scheduledEvents.map(event => event.scheduledEventID),
		}
		this.agentsCRMService.reassignScheduledEventList(payload).subscribe(() => this.dialogRef.close());
	}

	public cancel(): void {
		this.dialogRef.close();
	}

	private initializeState(): void {
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.sessionState.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			agentAssignedTo: new FormControl(''),
		});

		return form;
	}
}
