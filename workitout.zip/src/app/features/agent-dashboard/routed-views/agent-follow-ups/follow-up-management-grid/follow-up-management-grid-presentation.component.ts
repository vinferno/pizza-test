import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
	Output,
	EventEmitter,
}                        from '@angular/core';
import { FormGroup }     from '@angular/forms';

import { animator }      from '../../../../../infrastructure/core/animations/animations';
import {
	ScheduledEventsList,
	ScheduledEvent,
}                        from '../../../../../infrastructure/interfaces/agent-crm';
import { SettingsState } from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }  from '../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }  from '../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-follow-up-management-grid-presentation',
	templateUrl     : './follow-up-management-grid-presentation.component.html',
	styleUrls       : ['./follow-up-management-grid-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpManagementGridPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public columnList: TableColumns[] = [];
	@Input() public editButtonLabel: string = 'Update Event';
	@Input() public emptyGridMessage: string;
	@Input() public form: FormGroup;
	@Input() public scheduledEventList: ScheduledEventsList;
	@Input() public selectedScheduledEventList: ScheduledEventsList = new ScheduledEventsList();
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitClear = new EventEmitter<void>();
	@Output() public emitReassign = new EventEmitter<ScheduledEventsList>();
	@Output() public emitSelect = new EventEmitter<ScheduledEvent>();
	@Output() public emitSpecification = new EventEmitter<ScheduledEventsList>();
	@Output() public emitToggle = new EventEmitter<ScheduledEvent>();

	public newEvent: ScheduledEvent = new ScheduledEvent();

	public clear(): void {
		this.emitClear.emit();
	}

	public reassign(): void {
		this.emitReassign.emit(this.selectedScheduledEventList);
	}

	public search(): void {
		this.emitSpecification.emit();
	}

	public selectCell(event: ScheduledEvent): void {
		this.emitSelect.emit(event);
	}

	public toggleEvent(event: ScheduledEvent): void {
		this.emitToggle.emit(event);
	}

	public trackByColumnID(index: number, item): number {
		return (item) ? item.columnID : null;
	}

	public updateSelection(event: any): void {
		this.selectedScheduledEventList.scheduledEvents = event.selectedRowsData;
	}

	public hasSelection(): boolean  {
		return !!(this.selectedScheduledEventList.scheduledEvents.length);
	}
}
