import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                                     from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                                     from '@angular/forms';
import { MatDialogRef, MatDialog } from "@angular/material/dialog";
import { ActivatedRoute, Router }     from '@angular/router';

import { Store }                      from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                     from 'rxjs';

import { AgentsCRMService }           from '../../../utils/agents-crm.service';
import { Constants }                  from '../../../../../infrastructure/utils/constants';
import { ModalService }               from '../../../../../infrastructure/core/services/modal.service';
import { ReassignFollowUpsComponent } from './reassign-follow-ups/reassign-follow-ups.component';
import { RouterState }                from '../../../../../infrastructure/store/reducers/router/router-state';
import {
	ScheduledEventsList,
	ScheduledEvent,
	ScheduledEventCompletePayload,
	ScheduledEventSpecificationPayload,
}                                     from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }               from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }              from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }               from '../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns }               from '../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-follow-up-management-grid',
	template        :
		`<div class="page">
			<hg-follow-up-management-grid-presentation
				[scheduledEventList]="scheduledEventList"
				[columnList]="columnList"
				[editButtonLabel]="editButtonLabel"
				[emptyGridMessage]="emptyGridMessage"
				[form]="form"
				[session]="session"
				[settings]="(settingsState$ | async)"
				(emitClear)="clear()"
				(emitReassign)="reassignCounselor($event)"
				(emitSelect)="navigateToDetailPage($event)"
				(emitSpecification)="updateGrid()"
				(emitToggle)="toggle($event)"
			></hg-follow-up-management-grid-presentation>
		</div>
		`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpManagementGridSmartComponent implements OnInit, OnDestroy {
	@Input() public scheduledEventList: ScheduledEventsList;

	public columnList: TableColumns[] = [
		{
			columnName: 'Subject',
			columnId  : 'subject',
		},
		{
			columnName: 'Assigned',
			columnId  : 'agentAssignedTo.name',
		},
		{
			columnName: 'Event Type',
			columnId  : 'eventType.scheduledEventTypeLabel',
		},
		{
			columnName: 'Date',
			columnId  : 'dueDate',
			width     : 150,
		},
	];
	public agentAssignedTo: number;
	public dateRange: number;
	public isCompletedResponse: string = '0';
	public editButtonLabel: string = 'Update Event';
	public emptyGridMessage: string = 'No follow ups currently available.';
	public form: FormGroup;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;
	public url: RouterState;

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];
	private urlState$: Observable<RouterState>;

	constructor (
		private agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
		public dialog: MatDialog,
		private fb: FormBuilder,
		private modalService: ModalService,
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		if (this.route.snapshot.data['scheduledEventList']) {
			this.initializeRouterParams();
		}
		this.form = this.buildForm();
	}

	public ngOnInit(): void {
		this.initializeState();
	}

	public ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
		this.store.dispatch(stateActions.sessionActions.updateAgent({ followUpSpecification: null }));
	}

	public toggle(event: ScheduledEvent): void {
		(event.isCompleted) ? this.markEventAsOpen(event) : this.markEventAsComplete(event);
	}

	public clear(): void {
		const callLogSpecification: ScheduledEventSpecificationPayload = new ScheduledEventSpecificationPayload();
		for (const property in callLogSpecification) {
			if (callLogSpecification.hasOwnProperty(property) && property !== 'agentID' && property !== 'systemNumber') {
				this.form.get(property).setValue(callLogSpecification[property]);
			}
		}

		this.refreshScheduledEventsGrid();
	}

	public updateGrid(): void {
		const payload = this.buildPayload();
		this.updateSpecification(payload);
	}

	public navigateToDetailPage(cell: ScheduledEvent): void {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ scheduledEvent: cell }));

		if (this.url && this.url.current.url) {
			switch (this.url.current.url) {
				case '/counselor/follow-up-management':
					this.router.navigate(['counselor/follow-up-detail']);
					break;
				case '/counselor/customer-relations/member-follow-up/management':
					this.router.navigate(['counselor/customer-relations/member-follow-up/detail']);
					break;
			}
		}
	}

	public reassignCounselor(selectedScheduledEventList: ScheduledEventsList): void {
		const dialogRef: MatDialogRef<ReassignFollowUpsComponent> = this.dialog.open(ReassignFollowUpsComponent, { data: selectedScheduledEventList });

		dialogRef.beforeClose().subscribe(() => this.updateGrid());
		this.modalService.addModal(dialogRef);
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
		this.urlState$ = this.store.select('routerState');
		const urlSubscription = this.urlState$.subscribe(url => {
			this.url = url;
			this.cd.detectChanges();
		});
		this.subscriptions.push(urlSubscription);
	}

	private initializeRouterParams(): void {
		this.scheduledEventList = this.route.snapshot.data['scheduledEventList'];
		this.dateRange = this.scheduledEventList.dateRangeDropDownEnumUsed;
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			agentAssignedTo: new FormControl (this.agentAssignedTo),
			dateRangeDropDownEnum: new FormControl(this.dateRange.toString()),
			isCompletedResponse: new FormControl (this.isCompletedResponse),
		});

		return form;
	}

	private buildPayload(): ScheduledEventSpecificationPayload {
		const payload: ScheduledEventSpecificationPayload = new ScheduledEventSpecificationPayload();
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				switch (property) {
					case 'agentID':
						payload[property] = this.session.agent.agentID
						break;
					case 'systemNumber':
						payload[property] = (this.session.selectedMember && this.session.selectedMember.systemNumber)
												? this.session.selectedMember.systemNumber
												: Constants.emptyInt;
						break;
					case 'agentAssignedTo':
						payload[property] = (this.form.controls[property].value) ? this.form.controls[property].value : Constants.emptyInt;
						break;
					default:
						payload[property] = this.form.controls[property].value;
						break;
				}
			}
		}

		this.store.dispatch(stateActions.sessionActions.updateAgent({ followUpSpecification: payload }));

		return payload;
	}

	private markEventAsComplete(event: ScheduledEvent): void {
		const payload: ScheduledEventCompletePayload =  {
			scheduledEventID : event.scheduledEventID,
			appendNote       : event.note,
		}
		this.agentsCRMService.completeEvent(payload).subscribe(() => this.updateGrid());
	}

	private markEventAsOpen(event: ScheduledEvent): void {
		const payload: ScheduledEventCompletePayload =  {
			scheduledEventID : event.scheduledEventID,
			appendNote       : event.note,
		}
		this.agentsCRMService.markEventAsOpen(payload).subscribe(() => this.updateGrid());
	}

	private refreshScheduledEventsGrid(): void {
		(this.session.selectedMember && this.session.selectedMember.systemNumber)
			? this.getMemberDefaultScheduledEvents()
			: this.getAgentDefaultScheduledEvents();
	}

	private updateSpecification(payload: ScheduledEventSpecificationPayload): void {
		(this.session.selectedMember && this.session.selectedMember.systemNumber)
			? this.getMemberScheduledEvents(payload)
			: this.getAgentScheduledEvents(payload);
	}

	private getAgentDefaultScheduledEvents(): void {
		this.agentsCRMService.getDefaultScheduledEventsSpecification().subscribe(response => this.setDropdownValues(response));
	}

	private getAgentScheduledEvents(payload: ScheduledEventSpecificationPayload): void {
		this.agentsCRMService.getScheduledEventsSpecification(payload).subscribe(response => this.setDropdownValues(response));
	}

	private getMemberDefaultScheduledEvents(): void {
		this.agentsCRMService.getDefaultScheduledEventsMemberSpecification().subscribe(response => this.setDropdownValues(response));
	}

	private getMemberScheduledEvents(payload: ScheduledEventSpecificationPayload): void {
		this.agentsCRMService.getScheduledEventsMemberSpecification(payload).subscribe(response => this.setDropdownValues(response));
	}

	private setDropdownValues(response: ScheduledEventsList): void {
		this.scheduledEventList = response;
		this.agentAssignedTo = response.agentAssignedToParam;
		this.dateRange = response.dateRangeDropDownEnumUsed;
		this.isCompletedResponse = response.isCompletedParam;
		this.form.get('dateRangeDropDownEnum').setValue(this.dateRange.toString());
		this.form.get('isCompletedResponse').setValue(this.isCompletedResponse);
		this.cd.detectChanges();
	}
}
