import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                              from '@angular/core';
import {
	AbstractControl,
	FormGroup,
}                              from '@angular/forms';

import { animator }            from '../../../../../infrastructure/core/animations/animations';
import { ScheduledEvent }      from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }        from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }       from '../../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-follow-up-detail-presentation',
	templateUrl     : './follow-up-detail-presentation.component.html',
	styleUrls       : ['./follow-up-detail-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpDetailPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public form: FormGroup;
	@Input() public hasScheduledEventID: boolean = false;
	@Input() public now: Date;
	@Input() public scheduledEvent: ScheduledEvent;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;
	@Input() public toggleLabel: string = 'Complete';

	@Output() public emitComplete = new EventEmitter<void>();
	@Output() public emitReturn = new EventEmitter<void>();
	@Output() public emitSave = new EventEmitter<FormGroup>();

	public getEventTypeClass(): string {
		let agentClass: string = '';
		(this.isNewOrSupervisor())
			? agentClass = 'form-width-half'
			: agentClass = 'form-width-full';

		return agentClass;
	}

	public isAppendOnly(): boolean {
		return this.session.agent.scheduledEvent.scheduledEventID && !this.session.agent.isSupervisor;
	}

	public isNewOrSupervisor(): boolean {
		return Boolean(this.session.agent.scheduledEvent.scheduledEventID) || this.session.agent.isSupervisor;
	}

	public isSupervisor(): boolean {
		return this.session.agent.isSupervisor;
	}

	public complete(): void {
		this.emitComplete.emit();
	}

	public returnToList(): void {
		this.emitReturn.emit();
	}

	public save(): void {
		this.emitSave.emit(this.form);
	}

	public get dueDate(): AbstractControl {
		return this.form.get('dueDate');
	}
}
