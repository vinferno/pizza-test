import {
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                               from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                               from '@angular/forms';
import {
	ActivatedRoute,
	Router,
}                               from '@angular/router';

import * as moment              from 'moment';
import { Store }                from '@ngrx/store';
import {
	Observable,
	Subscription,
}                               from 'rxjs';

import { AgentsCRMService }     from '../../../utils/agents-crm.service';
import { Constants }            from '../../../../../infrastructure/utils/constants';
import { RouterState }          from '../../../../../infrastructure/store/reducers/router/router-state';
import {
	ScheduledEventPayload,
	ScheduledEventOverridePayload,
	ScheduledEvent,
	ScheduledEventAppendPayload,
	ScheduledEventCompletePayload,
}                               from '../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }         from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }        from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }         from '../../../../../infrastructure/store/reducers/reducers-index';
import { ValidationIsRequired } from '../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-follow-up-detail',
	template        :
		`<div class="page">
			<hg-follow-up-detail-presentation
				[scheduledEvent]="scheduledEvent"
				[form]="form"
				[hasScheduledEventID]="hasScheduledEventID()"
				[now]="now"
				[session]="session"
				[settings]="(settingsState$ | async)"
				[toggleLabel]="toggleLabel"
				(emitComplete)="toggle()"
				(emitReturn)="navigateToScheduledEventsList()"
				(emitSave)="save()"
			>
			</hg-follow-up-detail-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class FollowUpDetailSmartComponent implements OnInit, OnDestroy {
	public form: FormGroup;
	public now: Date = new Date();
	public scheduledEvent: ScheduledEvent;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;

	public toggleLabel: string = 'Complete';
	public url: RouterState;

	private payload: ScheduledEventPayload | ScheduledEventOverridePayload | ScheduledEventAppendPayload | ScheduledEventCompletePayload;
	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];
	private urlState$: Observable<RouterState>;

	constructor (
		private agentsCRMService: AgentsCRMService,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		this.scheduledEvent = this.route.snapshot.data['scheduledEvent'];
	}

	public ngOnInit(): void {
		this.initializeState();
		this.form = this.buildForm();
		(this.scheduledEvent.isCompleted) ? this.toggleLabel = 'Mark As Open' : this.toggleLabel = 'Mark As Complete';
	}

	public ngOnDestroy(): void {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ scheduledEvent: null }));
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public save(): void {
		if (this.hasScheduledEventID()) {
			if (this.session.agent.isSupervisor) {
				this.payload = new ScheduledEventOverridePayload();
				this.buildPayload(this.payload);
				this.modifyScheduledEvent();
			} else if (this.session.agent.isSupervisor === false) {
				this.payload = new ScheduledEventAppendPayload();
				this.buildPayload(this.payload);
				this.appendScheduledEvent();
			}
		} else {
			this.payload = new ScheduledEventPayload();
			this.buildPayload(this.payload);
			this.createScheduledEvent();
		}
	}

	public toggle(): void {
		(this.scheduledEvent.isCompleted) ? this.markEventAsOpen() : this.markEventAsComplete();
	}

	public navigateToScheduledEventsList(): void {
		if (this.url && this.url.last.url) {
			switch (this.url.last.url) {
				case '/counselor/follow-ups':
					this.router.navigate(['counselor/follow-ups']);
					break;
				case '/counselor/customer-relations/member-follow-up/open':
					this.router.navigate(['counselor/customer-relations/member-follow-up/open']);
					break;
				case '/counselor/follow-up-management':
					this.router.navigate(['counselor/follow-up-management']);
					break;
				case '/counselor/customer-relations/member-follow-up/management':
					this.router.navigate(['counselor/customer-relations/member-follow-up/management']);
					break;
			}
		}
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
		this.urlState$ = this.store.select('routerState');
		const urlSubscription = this.urlState$.subscribe(url => {
			this.url = url;
		});
		this.subscriptions.push(urlSubscription);
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			note: new FormControl ({ value: this.scheduledEvent.note, disabled: this.hasScheduledEventID() }),
			eventType: new FormControl ({ value: this.scheduledEvent.eventType.scheduledEventTypeID, disabled: this.isManagementUpdate() }, ValidationIsRequired.isRequired('Event Type')),
			reminder: new FormControl(this.scheduledEvent.reminder),
			subject: new FormControl({ value: this.scheduledEvent.subject, disabled: this.isManagementUpdate() }),
			timeZone: new FormControl(this.scheduledEvent.timeZone.timeZoneID),
		});

		if (!this.session.agent.scheduledEvent.scheduledEventID) {
			this.addNewEventFormControls(form);
		}

		if (this.session.agent.scheduledEvent.scheduledEventID) {
			this.addAppendModifyEventFormControls(form);
		}

		if (this.session.agent.scheduledEvent.scheduledEventID && this.session.agent.isSupervisor === false) {
			this.addAppendEventFormControls(form);
		}

		if (!this.session.agent.scheduledEvent.scheduledEventID && this.session.agent.isSupervisor === false) {
			this.addNewFieldAgentEventFormControls(form);
		}

		if (this.session.agent.isSupervisor) {
			this.addModifyEventFormControls(form);
		}

		return form;
	}

	private addNewEventFormControls(form: FormGroup): void {
		const newEvent: ScheduledEventPayload = new ScheduledEventPayload();

		form.addControl('systemNumber', new FormControl(
			(this.session.selectedMember && this.session.selectedMember.systemNumber)
				? this.session.selectedMember.systemNumber
				: null,
		));
		form.addControl('agentID', new FormControl(this.session.agent.agentID));
		form.addControl('dueDate', new FormControl(newEvent.dueDate, ValidationIsRequired.isRequired('Date and Time')));
	}

	private addNewFieldAgentEventFormControls(form: FormGroup): void {
		form.addControl('agentAssignedTo', new FormControl(this.session.agent.agentID));
	}

	private addAppendEventFormControls(form: FormGroup): void {
		form.addControl('agentAssignedTo', new FormControl({value: this.scheduledEvent.agentAssignedTo.name, disabled: true}));
	}

	private addAppendModifyEventFormControls(form: FormGroup): void {
		form.addControl('scheduledEventID', new FormControl(this.scheduledEvent.scheduledEventID));
		form.addControl('dueDate', new FormControl(this.scheduledEvent.dueDate, ValidationIsRequired.isRequired('Date and Time')));
		form.addControl('appendNote', new FormControl(''));
	}

	private addModifyEventFormControls(form: FormGroup): void {
		form.addControl('agentAssignedTo', new FormControl(this.scheduledEvent.agentAssignedTo.agentID));
	}

	private buildPayload(
		payload: ScheduledEventPayload | ScheduledEventOverridePayload | ScheduledEventAppendPayload | ScheduledEventCompletePayload,
	): ScheduledEventPayload | ScheduledEventOverridePayload | ScheduledEventAppendPayload | ScheduledEventCompletePayload {
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				(property === 'dueDate')
					? payload[property] = moment(new Date(this.form.controls[property].value)).format('YYYY-MM-DDTHH:mm:ss')
					: payload[property] = this.form.controls[property].value;
				if (property === 'reminder' && !this.form.controls[property].value) {
					payload[property] = Constants.emptyInt;
				}
			}
		}

		return payload;
	}

	private createScheduledEvent(): void {
		this.agentsCRMService.newScheduledEvent(<ScheduledEventPayload>this.payload)
			.subscribe(() => this.navigateToScheduledEventsList());
	}

	private appendScheduledEvent(): void {
		this.agentsCRMService.appendScheduledEventNote(<ScheduledEventAppendPayload>this.payload)
			.subscribe(() => this.navigateToScheduledEventsList());
	}

	private modifyScheduledEvent(): void {
		this.agentsCRMService.modifyScheduledEvent(<ScheduledEventOverridePayload>this.payload)
			.subscribe(() => this.navigateToScheduledEventsList());
	}

	private markEventAsComplete(): void {
		this.payload = new ScheduledEventCompletePayload();
		this.buildPayload(this.payload);
		this.agentsCRMService.completeEvent(this.payload).subscribe(() => this.navigateToScheduledEventsList());
	}

	private markEventAsOpen(): void {
		this.payload = new ScheduledEventCompletePayload();
		this.buildPayload(this.payload);
		this.agentsCRMService.markEventAsOpen(this.payload).subscribe(() => this.navigateToScheduledEventsList());
	}

	public hasScheduledEventID(): boolean {
		return this.scheduledEvent.scheduledEventID && this.scheduledEvent.scheduledEventID !== Constants.emptyInt;
	}

	public isManagementUpdate(): boolean {
		if (this.url && this.url.last.url) {
			switch (this.url.last.url) {
				case '/counselor/follow-up-management':
				case '/counselor/customer-relations/member-follow-up/management':
					return true;
				default:
					return false;
			}
		}
	}
}
