import { CommonModule }           from '@angular/common';
import { NgModule }               from '@angular/core';
import {
	FormsModule,
	ReactiveFormsModule,
}                                 from '@angular/forms';

import {
	AgentFollowUpsRoutingModule,
	entryComponents,
	routedComponents,
}                                 from './agent-follow-ups-routing.module';
import { AgentControlsModule }    from '../../utils/controls/agent-controls.module';
import { ControlsModule }         from '../../../../infrastructure/shared/controls/controls.module';
import { CovalentModule }         from '../../../../infrastructure/utils/covalent.module';
import { DevExtremeModule }       from '../../../../infrastructure/utils/devextreme.module';
import { MaterialModule }         from '../../../../infrastructure/utils/material.module';
import { resolvers }              from '../../utils/resolvers/resolvers';
import { SharedModule }           from 'app/infrastructure/shared/shared.module';

@NgModule({
	imports     : [
		CommonModule,
		AgentFollowUpsRoutingModule,
		MaterialModule,
		FormsModule,
		ReactiveFormsModule,
		SharedModule,
		AgentControlsModule,
		ControlsModule,
		CovalentModule,
		DevExtremeModule,
	],
	declarations: [routedComponents],
	providers   : [
		resolvers,
	],
	entryComponents: [entryComponents],
})
export class AgentFollowUpsModule { }
