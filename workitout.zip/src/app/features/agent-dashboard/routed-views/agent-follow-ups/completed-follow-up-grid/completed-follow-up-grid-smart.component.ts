import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                           from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                           from '@angular/forms';
import { ActivatedRoute }   from '@angular/router';

import { Store }            from '@ngrx/store';
import {
	Observable,
	Subscription,
}                           from 'rxjs';

import { AgentsCRMService } from '../../../utils/agents-crm.service';
import {
	AgentFilterPayload,
	ScheduledEventsList,
	ScheduledEvent,
	ScheduledEventCompletePayload,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { Constants }        from '../../../../../infrastructure/utils/constants';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }    from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }     from '../../../../../infrastructure/interfaces/table-columns';
import { IDateRangeSelect } from '../../../../../infrastructure/interfaces/date-range-select';

@Component({
	selector        : 'hg-completed-follow-up-grid',
	template        :
		`<div class="page">
			<hg-completed-follow-up-grid-presentation
				[scheduledEventList]="scheduledEventList"
				[columnList]="columnList"
				[emptyGridMessage]="emptyGridMessage"
				[form]="form"
				[session]="session"
				[settings]="(settingsState$ | async)"
				(emitSelect)="updateGrid($event)"
				(emitSetAsIncomplete)="markEventAsOpen($event)"
			>
			</hg-completed-follow-up-grid-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CompletedFollowUpGridSmartComponent implements OnInit, OnDestroy {
	@Input() public scheduledEventList: ScheduledEventsList;

	public columnList: TableColumns[] = [
		{
			columnName: 'Subject',
			columnId  : 'subject',
		},
		{
			columnName: 'Assigned',
			columnId  : 'agentAssignedTo.name',
		},
		{
			columnName: 'Event Type',
			columnId  : 'eventType.scheduledEventTypeLabel',
		},
		{
			columnName: 'Date',
			columnId  : 'dueDate',
		},
	];
	public dateRange: number = 0;
	public editButtonLabel: string = 'Update Event';
	public emptyGridMessage: string = 'No follow ups currently available.';
	public form: FormGroup;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;

	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private agentsCRMService: AgentsCRMService,
		private cd: ChangeDetectorRef,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private store: Store<any>,
	) {
		if (this.route.snapshot.data['scheduledEventList']) {
			this.scheduledEventList = this.route.snapshot.data['scheduledEventList'];
		}
		this.form = this.buildForm();
	}

	public ngOnInit(): void {
		this.initializeState();
	}

	public ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public updateGrid(event: IDateRangeSelect): void {
		if (event) {
			this.form.get('dateRangeDropDownEnum').setValue(event.value);
			this.form.get('dateRangeDropDownEnum').updateValueAndValidity();
		}
		const payload = this.buildPayload();
		this.updateSpecification(payload);
	}

	public markEventAsOpen(event: ScheduledEvent): void {
		const payload: ScheduledEventCompletePayload =  {
			scheduledEventID : event.scheduledEventID,
			appendNote       : event.note,
		};
		this.agentsCRMService.markEventAsOpen(payload).subscribe(() => this.updateGrid(null));
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			dateRangeDropDownEnum: new FormControl(this.dateRange.toString()),
		});

		return form;
	}

	private buildPayload(): AgentFilterPayload {
		const payload: AgentFilterPayload = new AgentFilterPayload();
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				switch (property) {
					case 'agentID':
						payload[property] = this.session.agent.agentID
						break;
					case 'systemNumber':
						payload[property] = (this.session.selectedMember && this.session.selectedMember.systemNumber)
												? this.session.selectedMember.systemNumber
												: Constants.emptyInt;
						break;
					default:
						if (this.form.controls[property]) {
							payload[property] = this.form.controls[property].value;
						}
						break;
				}
			}
		}

		return payload;
	}

	private updateSpecification(payload: AgentFilterPayload): void {
		(this.session.selectedMember && this.session.selectedMember.systemNumber)
			? this.getCompletedMemberScheduledEvents(payload)
			: this.getCompletedScheduledEvents(payload);
	}

	private getCompletedMemberScheduledEvents(payload: AgentFilterPayload): void {
		this.agentsCRMService.getCompletedMemberScheduledEvents(payload).subscribe(response => {
			this.scheduledEventList = response;
			this.cd.detectChanges();
		});
	}

	private getCompletedScheduledEvents(payload: AgentFilterPayload): void {
		this.agentsCRMService.getCompletedScheduledEvents(payload).subscribe(response => {
			this.scheduledEventList = response;
			this.cd.detectChanges();
		});
	}
}
