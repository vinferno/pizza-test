import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
	Output,
	EventEmitter,
}                        from '@angular/core';
import { FormGroup }     from '@angular/forms';

import {
	ScheduledEventsList,
	ScheduledEvent,
}                           from '../../../../../infrastructure/interfaces/agent-crm';
import { animator }         from '../../../../../infrastructure/core/animations/animations';
import { SettingsState }    from '../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }     from '../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }     from '../../../../../infrastructure/interfaces/table-columns';
import { IDateRangeSelect } from '../../../../../infrastructure/interfaces/date-range-select';

@Component({
	selector        : 'hg-completed-follow-up-grid-presentation',
	templateUrl     : './completed-follow-up-grid-presentation.component.html',
	styleUrls       : ['./completed-follow-up-grid-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class CompletedFollowUpGridPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public scheduledEventList: ScheduledEventsList;
	@Input() public columnList: TableColumns[] = [];
	@Input() public editButtonLabel: string = 'Update Event';
	@Input() public emptyGridMessage: string;
	@Input() public form: FormGroup;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitSelect = new EventEmitter<IDateRangeSelect>();
	@Output() public emitSetAsIncomplete = new EventEmitter<ScheduledEvent>();

	public newEvent: ScheduledEvent = new ScheduledEvent();

	public select(event: IDateRangeSelect): void {
		this.emitSelect.emit(event);
	}

	public setAsIncomplete(event: ScheduledEvent): void {
		this.emitSetAsIncomplete.emit(event);
	}

	public trackByColumnID(index: number, item): number {
		return (item) ? item.columnID : null;
	}
}
