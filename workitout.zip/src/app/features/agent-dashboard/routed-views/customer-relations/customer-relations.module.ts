import { CommonModule }            from '@angular/common';
import { NgModule }                from '@angular/core';
import {
	FormsModule,
	ReactiveFormsModule,
}                                  from '@angular/forms';

import {
	CustomerRelationsRoutingModule,
	routedComponents,
}                                  from './customer-relations-routing.module';
import { AgentControlsModule }     from '../../utils/controls/agent-controls.module';
import { ControlsModule }          from '../../../../infrastructure/shared/controls/controls.module';
import { CovalentModule }          from '../../../../infrastructure/utils/covalent.module';
import { DevExtremeModule }        from '../../../../infrastructure/utils/devextreme.module';
import { MaterialModule }          from '../../../../infrastructure/utils/material.module';
import { MemberActivityLogModule } from './member-activity-log/member-activity-log.module';
import { MemberFollowUpsModule }   from './member-follow-ups/member-follow-ups.module';
import { resolvers }               from '../../utils/resolvers/resolvers';
import { SharedModule }            from 'app/infrastructure/shared/shared.module';

@NgModule({
	imports     : [
		CommonModule,
		MemberActivityLogModule,
		MemberFollowUpsModule,
		CustomerRelationsRoutingModule,
		MaterialModule,
		FormsModule,
		ReactiveFormsModule,
		SharedModule,
		AgentControlsModule,
		ControlsModule,
		CovalentModule,
		DevExtremeModule,
	],
	declarations: [routedComponents],
	providers   : [
		resolvers,
	],
})
export class CustomerRelationsModule { }
