import { NgModule }                          from '@angular/core';
import { RouterModule, Routes }              from '@angular/router';

import { routes as memberActivityLogRoutes } from './member-activity-log/member-activity-log-routing.module';
import { routes as memberFollowUpsRoutes }   from './member-follow-ups/member-follow-ups-routing.module';

export const routes: Routes = [
	{
		path       : '',
		children   : [
			{
				path       : '',
				redirectTo : 'member-activity-log',
				pathMatch  : 'full',
			},
			{
				path       : 'member-activity-log',
				children: memberActivityLogRoutes,
				data: { title: 'Member Activity Log' },
			},
			{
				path     : 'member-follow-up',
				children: memberFollowUpsRoutes,
				data: { title: 'Member Follow Ups' },
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class CustomerRelationsRoutingModule { }

export const routedComponents = [];
