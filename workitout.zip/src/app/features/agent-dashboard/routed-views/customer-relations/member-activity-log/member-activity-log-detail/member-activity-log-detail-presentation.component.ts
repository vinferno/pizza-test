import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                            from '@angular/core';
import { FormGroup }         from '@angular/forms';

import { animator }          from '../../../../../../infrastructure/core/animations/animations';
import { MemberActivityLog } from '../../../../../../infrastructure/interfaces/agent-crm';
import { SettingsState }     from '../../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }      from '../../../../../../infrastructure/store/reducers/session/session-state';

@Component({
	selector        : 'hg-member-activity-log-detail-presentation',
	templateUrl     : './member-activity-log-detail-presentation.component.html',
	styleUrls       : ['./member-activity-log-detail-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class MemberActivityLogDetailPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public activityLog: MemberActivityLog;
	@Input() public form: FormGroup;
	@Input() public hasActivityLogID: boolean = false;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitSave = new EventEmitter<FormGroup>();

	public save(): void {
		this.emitSave.emit(this.form);
	}
}
