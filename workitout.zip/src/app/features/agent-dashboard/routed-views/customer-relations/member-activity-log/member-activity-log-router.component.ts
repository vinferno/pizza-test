import {
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
 }                       from '@angular/core';

import { Store }         from '@ngrx/store';
import {
	Observable,
	Subscription,
}                        from 'rxjs';

import { animator }      from '../../../../../infrastructure/core/animations/animations';
import { SettingsState } from '../../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector    : 'hg-member-activity-log-router',
	templateUrl : './member-activity-log-router.component.html',
	styleUrls   : ['./member-activity-log-router.component.scss'],
	animations  : [animator.slide],
})
export class MemberActivityLogRouterComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public navLinks = [
		{
			label : 'Create Activity Log',
			path  : '/counselor/customer-relations/member-activity-log/detail',
		},
		{
			label : 'Activity Log History',
			path  : '/counselor/customer-relations/member-activity-log/history',
		},
	];
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private store: Store<any>,
	) { }

	ngOnInit() {
		this.initializeState();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
	}
}
