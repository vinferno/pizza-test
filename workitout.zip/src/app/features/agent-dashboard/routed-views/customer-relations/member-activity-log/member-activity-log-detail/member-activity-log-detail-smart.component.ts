import {
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                               from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                               from '@angular/forms';
import {
	ActivatedRoute,
	Router,
}                               from '@angular/router';

import { Store }                from '@ngrx/store';
import {
	Observable,
	Subscription,
}                               from 'rxjs';

import {
	MemberActivityLog,
	MemberActivityLogPayload,
	MemberAppendActivityLogPayload,
}                               from '../../../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService }     from '../../../../utils/agents-crm.service';
import { Constants }            from '../../../../../../infrastructure/utils/constants';
import { SessionState }         from '../../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }        from '../../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }         from '../../../../../../infrastructure/store/reducers/reducers-index';
import { ValidationIsRequired } from '../../../../../../infrastructure/core/validation/validation-is-required';

@Component({
	selector        : 'hg-member-activity-log-detail',
	template        :
		`<div class="col-12 mt-4">
			<hg-member-activity-log-detail-presentation
				[activityLog]="activityLog"
				[form]="form"
				[hasActivityLogID]="hasActivityLogID()"
				[session]="session"
				[settings]="(settingsState$ | async)"
				(emitSave)="save()"
			></hg-member-activity-log-detail-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class MemberActivityLogDetailSmartComponent implements OnInit, OnDestroy {
	public activityLog: MemberActivityLog;
	public form: FormGroup;
	public session: SessionState;
	public settingsState$: Observable<SettingsState>;

	private payload: MemberAppendActivityLogPayload | MemberActivityLogPayload;
	private sessionState$: Observable<SessionState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private agentsCRMService: AgentsCRMService,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		this.activityLog = this.route.snapshot.data['activityLog'];
	}

	ngOnInit() {
		this.initializeState();
		this.form = this.buildForm();
	}

	ngOnDestroy() {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ memberActivityLog: null }));
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public save(): void {
		if (this.hasActivityLogID()) {
			this.payload = new MemberAppendActivityLogPayload();
			this.buildPayload(this.payload);
			this.appendActivityLog();
		} else {
			this.payload = new MemberActivityLogPayload();
			this.buildPayload(this.payload);
			this.createActivityLog();
		}
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		const sessionSubscription = this.sessionState$.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState$ = this.store.select('settingsState');
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			activityTypeID: new FormControl ({ value: this.activityLog.activityTypeID, disabled: this.hasActivityLogID() }),
			activityNote: new FormControl ({ value: this.activityLog.activityNote, disabled: this.hasActivityLogID() }, ValidationIsRequired.isRequired('Note')),
		});

		if (this.hasActivityLogID()) {
			form.addControl('activityLogID', new FormControl(this.activityLog.activityLogID));
			form.addControl('appendActivityNote', new FormControl('', ValidationIsRequired.isRequired('Appended Note')));
		}

		return form;
	}

	private buildPayload(payload: MemberActivityLogPayload | MemberAppendActivityLogPayload): MemberActivityLogPayload | MemberAppendActivityLogPayload {
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				(property === 'systemNumber')
					? payload[property] = this.session.selectedMember.systemNumber
					: payload[property] = this.form.controls[property].value;
			}
		}

		return payload;
	}

	private createActivityLog(): void {
		this.agentsCRMService.createActivityLog(<MemberActivityLogPayload>this.payload)
			.subscribe(() => this.router.navigate(['counselor/customer-relations/member-activity-log/history']));
	}

	private appendActivityLog(): void {
		this.agentsCRMService.appendActivityLog(<MemberAppendActivityLogPayload>this.payload)
			.subscribe(() => this.router.navigate(['counselor/customer-relations/member-activity-log/history']));
	}

	public hasActivityLogID(): boolean {
		return this.activityLog.activityLogID && this.activityLog.activityLogID !== Constants.emptyInt;
	}
}
