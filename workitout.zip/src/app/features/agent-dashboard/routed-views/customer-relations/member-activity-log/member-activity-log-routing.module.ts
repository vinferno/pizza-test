import { NgModule }                                     from '@angular/core';
import { RouterModule, Routes }                         from '@angular/router';

import { AgentDashboardGuard }                          from '../../../utils/guards/agent-dashboard.guard';
import { agentDashboardResolvers }                      from '../../../utils/resolvers/agent-dashboard/agent-dashboard-resolvers';
import { MemberActivityLogDetailPresentationComponent } from './member-activity-log-detail/member-activity-log-detail-presentation.component';
import { MemberActivityLogDetailSmartComponent }        from './member-activity-log-detail/member-activity-log-detail-smart.component';
import { MemberActivityLogGridPresentationComponent }   from './member-activity-log-grid/member-activity-log-grid-presentation.component';
import { MemberActivityLogGridSmartComponent }          from './member-activity-log-grid/member-activity-log-grid-smart.component';
import { MemberActivityLogRouterComponent }             from './member-activity-log-router.component';
import { TitleResolver }                                from '../../../../../infrastructure/core/resolvers/title.resolver';

export const routes: Routes = [
	{
		path       : '',
		component  : MemberActivityLogRouterComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path       : '',
				redirectTo : 'detail',
				pathMatch  : 'full',
			},
			{
				path       : 'history',
				component  : MemberActivityLogGridSmartComponent,
				data: { title: 'Member Activity Log' },
				resolve: {
					activityLog : agentDashboardResolvers.MemberActivityLogResolver,
					title       : TitleResolver,
				},
			},
			{
				path     : 'detail',
				component: MemberActivityLogDetailSmartComponent,
				resolve  : {
					activityLog: agentDashboardResolvers.MemberActivityLogDetailResolver,
				},
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class MemberActivityLogRoutingModule { }

export const routedComponents = [
	MemberActivityLogRouterComponent,
	MemberActivityLogGridPresentationComponent,
	MemberActivityLogGridSmartComponent,
	MemberActivityLogDetailPresentationComponent,
	MemberActivityLogDetailSmartComponent,
];
