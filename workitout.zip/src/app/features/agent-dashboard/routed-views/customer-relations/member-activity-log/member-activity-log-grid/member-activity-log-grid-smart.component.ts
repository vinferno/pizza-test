import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
	Input,
}                         from '@angular/core';
import {
	ActivatedRoute,
	Router,
}                         from '@angular/router';

import { Store }          from '@ngrx/store';
import { Observable }     from 'rxjs';

import {
	MemberActivityLog,
	MemberActivityLogList,
}                         from '../../../../../../infrastructure/interfaces/agent-crm';
import { SessionState }   from '../../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }  from '../../../../../../infrastructure/store/reducers/settings/settings-state';
import { stateActions }   from '../../../../../../infrastructure/store/reducers/reducers-index';
import { TableColumns }   from '../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-member-activity-log-grid',
	template        :
		`<div class="page">
			<hg-member-activity-log-grid-presentation
				[activityLog]="activityLog"
				[columnList]="columnList"
				[editButtonLabel]="editButtonLabel"
				[emptyGridMessage]="emptyGridMessage"
				[session]="(sessionState$ | async)"
				[settings]="(settingsState$ | async)"
				(emitSelect)="navigateToDetailPage($event)"
			>
			</hg-member-activity-log-grid-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class MemberActivityLogGridSmartComponent implements OnInit {
	@Input() public activityLog: MemberActivityLogList;

	public columnList: TableColumns[] = [
		{
			columnName : 'Counselor',
			columnId   : 'agent',
		},
		{
			columnName : 'Activity Type',
			columnId   : 'activityType',
		},
		{
			columnName : 'Last Updated',
			columnId   : 'lastUpdated',
			width      : 150,
		},
		{
			columnName : 'Note',
			columnId   : 'activityNote',
		},
	];
	public editButtonLabel: string = 'Append to Note';
	public emptyGridMessage: string = 'No activity log currently available.';
	public sessionState$: Observable<SessionState>;
	public settingsState$: Observable<SettingsState>;

	constructor (
		private route: ActivatedRoute,
		private router: Router,
		private store: Store<any>,
	) {
		this.activityLog = this.route.snapshot.data['activityLog'];
	}

	public ngOnInit(): void {
		this.initializeState();
	}

	public navigateToDetailPage(cell: MemberActivityLog) {
		this.store.dispatch(stateActions.sessionActions.updateAgent({ memberActivityLog: cell }));
		this.router.navigate(['counselor/customer-relations/member-activity-log/detail']);
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		this.settingsState$ = this.store.select('settingsState');
	}
}
