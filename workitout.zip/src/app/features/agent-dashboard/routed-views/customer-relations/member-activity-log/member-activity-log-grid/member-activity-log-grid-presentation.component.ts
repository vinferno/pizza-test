import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
	Output,
	EventEmitter,
}                        from '@angular/core';

import {
	MemberActivityLog,
	MemberActivityLogList,
}                        from '../../../../../../infrastructure/interfaces/agent-crm';
import { animator }      from '../../../../../../infrastructure/core/animations/animations';
import { SettingsState } from '../../../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }  from '../../../../../../infrastructure/store/reducers/session/session-state';
import { TableColumns }  from '../../../../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-member-activity-log-grid-presentation',
	templateUrl     : './member-activity-log-grid-presentation.component.html',
	styleUrls       : ['./member-activity-log-grid-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class MemberActivityLogGridPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public activityLog: MemberActivityLogList;
	@Input() public columnList: TableColumns[] = [];
	@Input() public editButtonLabel: string = 'Append to Note';
	@Input() public emptyGridMessage: string;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;

	@Output() public emitSelect = new EventEmitter<MemberActivityLog>();

	public newLog: MemberActivityLog = new MemberActivityLog();

	public selectCell(log: MemberActivityLog): void {
		this.emitSelect.emit(log);
	}
}
