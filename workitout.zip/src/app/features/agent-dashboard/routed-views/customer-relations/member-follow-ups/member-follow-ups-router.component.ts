import {
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
 }                       from '@angular/core';

import { Store }         from '@ngrx/store';
import {
	Observable,
	Subscription,
}                        from 'rxjs';

import { animator }      from '../../../../../infrastructure/core/animations/animations';
import { SessionState }  from '../../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState } from '../../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector    : 'hg-member-follow-ups-router',
	templateUrl : './member-follow-ups-router.component.html',
	styleUrls   : ['./member-follow-ups-router.component.scss'],
	animations  : [animator.slide],
})
export class MemberFollowUpsRouterComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public navLinks = [
		{
			label : 'Open Follow Ups',
			path  : '/counselor/customer-relations/member-follow-up/open',
		},
		{
			label : 'Completed Follow Ups',
			path  : '/counselor/customer-relations/member-follow-up/completed',
		},
	];
	public session: SessionState;
	public settings: SettingsState;

	private sessionState: Observable<SessionState>;
	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private store: Store<any>,
	) { }

	ngOnInit() {
		this.initializeState();
		this.checkForSupervisor();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	private initializeState(): void {
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.sessionState.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
	}

	private checkForSupervisor(): void {
		if (this.session && this.session.agent && this.session.agent.isSupervisor) {
			const managementLink = {
				label : 'Follow Up Management',
				path  : '/counselor/customer-relations/member-follow-up/management',
			}

			this.navLinks.push(managementLink);
		}
	}
}
