import { NgModule }                             from '@angular/core';
import { RouterModule, Routes }                 from '@angular/router';

import { AgentDashboardGuard }                  from '../../../utils/guards/agent-dashboard.guard';
import { agentDashboardResolvers }              from '../../../utils/resolvers/agent-dashboard/agent-dashboard-resolvers';
import { CompletedFollowUpGridSmartComponent }  from '../../agent-follow-ups/completed-follow-up-grid/completed-follow-up-grid-smart.component';
import { FollowUpGridSmartComponent }           from '../../agent-follow-ups/follow-up-grid/follow-up-grid-smart.component';
import { FollowUpDetailSmartComponent }         from '../../agent-follow-ups/follow-up-detail/follow-up-detail-smart.component';
import { FollowUpManagementGridSmartComponent } from '../../agent-follow-ups/follow-up-management-grid/follow-up-management-grid-smart.component';
import { MemberFollowUpsRouterComponent }       from './member-follow-ups-router.component';
import { TitleResolver }                        from '../../../../../infrastructure/core/resolvers/title.resolver';

export const routes: Routes = [
	{
		path       : '',
		component  : MemberFollowUpsRouterComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path       : '',
				redirectTo : 'open',
				pathMatch  : 'full',
			},
			{
				path     : 'completed',
				component: CompletedFollowUpGridSmartComponent,
				resolve  : {
					scheduledEventList: agentDashboardResolvers.MemberCompletedFollowUpsResolver,
				},
			},
			{
				path     : 'open',
				component: FollowUpGridSmartComponent,
				resolve  : {
					scheduledEventList: agentDashboardResolvers.MemberFollowUpsResolver,
				},
			},
			{
				path     : 'management',
				component: FollowUpManagementGridSmartComponent,
				resolve  : {
					scheduledEventList: agentDashboardResolvers.MemberFollowUpManagementResolver,
				},
			},
			{
				path     : 'detail',
				component: FollowUpDetailSmartComponent,
				resolve  : {
					scheduledEvent: agentDashboardResolvers.AgentFollowUpDetailResolver,
				},
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class MemberFollowUpsRoutingModule { }

export const routedComponents = [
	MemberFollowUpsRouterComponent,
];
