import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
	EventEmitter,
	Output,
	OnInit,
	OnDestroy
}                                from '@angular/core';
import { FormGroup }             from '@angular/forms';

import { AgentCompany }          from '../../../../infrastructure/interfaces/agent';
import { PageTitlePresentationComponent } from '../../../../infrastructure/shared/page-title/page-title-presentation.component';
import { AgentCompanyResources } from '../../../../infrastructure/interfaces/agent-crm';
import { animator }              from '../../../../infrastructure/core/animations/animations';
import { SettingsState }         from '../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }          from '../../../../infrastructure/store/reducers/session/session-state';
import { RouterState } 			 from '../../../../infrastructure/store/reducers/router/router-state';
import { Store } 				 from '@ngrx/store';
import {
	Observable,
	Subscription,
} 								 from 'rxjs';


@Component({
	selector        : 'hg-agent-company-resources-presentation',
	templateUrl     : './agent-company-resources-presentation.component.html',
	styleUrls       : ['./agent-company-resources-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCompanyResourcesPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public agentCompanyResources: AgentCompanyResources;
	@Input() public form: FormGroup;
	@Input() public session: SessionState;
	@Input() public settings: SettingsState;
	@Input() public tabs: { name: string; emptyGridMessage: string; }[];

	@Output() public emitSelectCompany: EventEmitter<AgentCompany> = new EventEmitter();
	public url: RouterState;
	public urlState: Observable<RouterState>;
	public subscriptions: Subscription[] = [];
	public emptyMessageCompliance: string = 'There are no compliance resources currently available.';
	public emptyMessageContacts: string = 'There are no contacts currently available.';
	public emptyMessageCompanyLevel: string = 'There are no company resources currently available.';
	public emptyMessageBenefitLevel: string = 'There are no benefit resources currently available.';

	public trackByName(index: number, item: { name: string; emptyGridMessage: string; }): string {
		return item.name;
	}

	public setSelectedCompany(company: AgentCompany): void {
		this.emitSelectCompany.emit(company);
	}

	constructor (
		private cd: ChangeDetectorRef,
		private store: Store<any>,
	) {
	}

	ngOnInit () {
		this.urlState = this.store.select('routerState');
		const urlSubscription = this.urlState.subscribe(url => {
			this.url = url;
			this.cd.detectChanges();
		});
		this.subscriptions.push(urlSubscription);
	}

	public ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}
}
