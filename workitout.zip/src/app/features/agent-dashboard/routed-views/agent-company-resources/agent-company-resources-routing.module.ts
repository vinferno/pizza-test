import { NgModule }                                	from '@angular/core';
import { RouterModule, Routes }                    	from '@angular/router';

import { AgentDashboardGuard }                     	from '../../utils/guards/agent-dashboard.guard';
import { AgentCompanyResourcesSmartComponent } 		from './agent-company-resources-smart.component';
import { AgentCompanyResourcesPresentationComponent } from './agent-company-resources-presentation.component';
import { TitleResolver }                           	from '../../../../infrastructure/core/resolvers/title.resolver';

const routes: Routes = [
	{
		path       : '',
		component  : AgentCompanyResourcesSmartComponent,
		resolve    : {
			title: TitleResolver,
		},
		canActivateChild: [AgentDashboardGuard],
		children   : [
			{
				path     : 'benefit-level',
				component: AgentCompanyResourcesSmartComponent,
			},
			{
				path     : 'company-level',
				component: AgentCompanyResourcesSmartComponent,
			},
			{
				path     : 'compliance',
				component: AgentCompanyResourcesSmartComponent,
			},
			{
				path     : 'contacts',
				component: AgentCompanyResourcesSmartComponent,
			},
		],
	},
];

@NgModule({
	imports     : [
		RouterModule.forChild(routes),
	],
	exports     : [RouterModule],
})
export class AgentCompanyResourcesRoutingModule { }

export const routedComponents = [
	AgentCompanyResourcesSmartComponent,
	AgentCompanyResourcesPresentationComponent,
];
