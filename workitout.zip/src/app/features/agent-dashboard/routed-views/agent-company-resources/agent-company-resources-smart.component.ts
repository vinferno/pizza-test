import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
}                                from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                                from '@angular/forms';

import { Store }                 from '@ngrx/store';
import { Observable }            from 'rxjs';

import { AgentCompany }          from '../../../../infrastructure/interfaces/agent';
import { AgentCompanyResources } from '../../../../infrastructure/interfaces/agent-crm';
import { AgentsCRMService }      from '../../utils/agents-crm.service';
import { SessionState }          from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }         from '../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-agent-company-resources',
	template        :
		`<div class="page">
			<hg-agent-company-resources-presentation
				[agentCompanyResources]="(agentCompanyResources$ | async)"
				[form]="form"
				[settings]="(settingsState$ | async)"
				[session]="(sessionState$ | async)"
				[tabs]="tabs"
				(emitSelectCompany)="selectCompany($event)"
			></hg-agent-company-resources-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCompanyResourcesSmartComponent implements OnInit {
	public agentCompanyResources$: Observable<AgentCompanyResources>;
	public form: FormGroup;
	public sessionState$: Observable<SessionState>;
	public settingsState$: Observable<SettingsState>;
	public tabs: { name: string; emptyGridMessage: string; }[] = [
		{
			name: 'Benefit Level',
			emptyGridMessage: 'There are no Benefit Resources currently available.',
		},
		{
			name: 'Company Level',
			emptyGridMessage: 'There are no Company Resources currently available.',
		},
		{
			name: 'Compliance',
			emptyGridMessage: 'There are no Compliance Resources currently available.',
		},
		{
			name: 'Contacts',
			emptyGridMessage: 'There are no contacts currently available.',
		},
	];

	constructor (
		private agentsCRMService: AgentsCRMService,
		private fb: FormBuilder,
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
		this.buildForm();
	}

	public selectCompany(company: AgentCompany): void {
		if (company) { this.getCompanyResourcesById(company.companyID); }
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		this.settingsState$ = this.store.select('settingsState');
	}

	private buildForm(): void {
		this.form = this.fb.group({
			companyID: new FormControl (null),
		});
	}

	private getCompanyResourcesById(companyID: number): void {
		this.agentCompanyResources$ = null;
		this.agentCompanyResources$ = this.agentsCRMService.getCompanyResourcesByID({ companyID });
	}
}
