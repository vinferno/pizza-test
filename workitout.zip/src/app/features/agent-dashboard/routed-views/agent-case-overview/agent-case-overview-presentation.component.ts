import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	Input,
}                        from '@angular/core';

import { animator }      from '../../../../infrastructure/core/animations/animations';
import { SettingsState } from '../../../../infrastructure/store/reducers/settings/settings-state';
import { SessionState }  from '../../../../infrastructure/store/reducers/session/session-state';

@Component({
	selector        : 'hg-agent-case-overview-presentation',
	templateUrl     : './agent-case-overview-presentation.component.html',
	styleUrls       : ['./agent-case-overview-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCaseOverviewPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() public session: SessionState;
	@Input() public settings: SettingsState;
}
