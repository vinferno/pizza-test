import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
}                        from '@angular/core';

import { Store }         from '@ngrx/store';
import { Observable }    from 'rxjs';

import { SessionState }  from '../../../../infrastructure/store/reducers/session/session-state';
import { SettingsState } from '../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-agent-case-overview',
	template        :
		`<div class="page">
			<hg-agent-case-overview-presentation
				[session]="(sessionState$ | async)"
				[settings]="(settingsState$ | async)"
			></hg-agent-case-overview-presentation>
		</div>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AgentCaseOverviewSmartComponent implements OnInit {
	public sessionState$: Observable<SessionState>;
	public settingsState$: Observable<SettingsState>;

	constructor (
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
	}

	private initializeState(): void {
		this.sessionState$ = this.store.select('sessionState');
		this.settingsState$ = this.store.select('settingsState');
	}
}
