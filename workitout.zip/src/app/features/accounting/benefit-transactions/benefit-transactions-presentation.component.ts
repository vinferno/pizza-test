import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                                 from '@angular/core';
import { FormGroup }              from '@angular/forms';

import { animator }               from '../../../infrastructure/core/animations/animations';
import { SnapshotAccountingList } from '../../../infrastructure/interfaces/accounting';
import { SettingsState }          from '../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }           from '../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-benefit-transactions-presentation',
	templateUrl     : './benefit-transactions-presentation.component.html',
	styleUrls       : ['./benefit-transactions-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BenefitTransactionsPresentationComponent {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	@Input() snapshotAccountingList: SnapshotAccountingList;
	@Input() public columnList: TableColumns[] = [];
	@Input() public detailColumnList: TableColumns[] = [];
	@Input() public emptyGridMessage: string;
	@Input() public form: FormGroup;
	@Input() public isQueryValid: boolean = false;
	@Input() public settings: SettingsState;

	@Output() public emitClear = new EventEmitter<void>();
	@Output() public emitSearch = new EventEmitter<FormGroup>();

	constructor () { }

	public clear(): void {
		this.emitClear.emit();
	}

	public search(): void {
		this.emitSearch.emit(this.form);
	}
}
