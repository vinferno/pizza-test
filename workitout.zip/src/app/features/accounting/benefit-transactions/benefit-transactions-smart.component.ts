import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                    from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                                    from '@angular/forms';
import {
	ActivatedRoute,
}                                    from '@angular/router';

import { Store }                     from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                    from 'rxjs';

import {
	SnapshotAccountingList,
	SnapshotAccountingPayload,
}                                    from '../../../infrastructure/interfaces/accounting';
import { Constants }                 from '../../../infrastructure/utils/constants';
import { SettingsState }             from '../../../infrastructure/store/reducers/settings/settings-state';
import { SnapshotAccountingService } from '../../../infrastructure/core/services/snapshot-accounting.service';
import { TableColumns }              from '../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-benefit-transactions',
	templateUrl     : './benefit-transactions-smart.component.html',
	styleUrls       : ['./benefit-transactions-smart.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BenefitTransactionsSmartComponent implements OnInit, OnDestroy {
	public benefitType: number = 0;
	public columnList: TableColumns[] = [
		{
			columnName: 'Billing Period',
			columnId  : 'billingPeriodDisplay',
		},
		{
			columnName: 'Effective On',
			columnId  : 'effectiveOn',
			width     : 100,
		},
		{
			columnName: 'Termed On',
			columnId  : 'terminatedOn',
			width     : 90,
		},
		{
			columnName: 'Total Due',
			columnId  : 'totalDue',
			format    : Constants.currencyFormat,
			width     : 100,
		},
		{
			columnName: 'Balance Due',
			columnId  : 'balanceDue',
			format    : Constants.currencyFormat,
			width     : 100,
		},
		{
			columnName: 'Coverage Amount',
			columnId  : 'coverageAmount',
			format    : Constants.currencyFormat,
			width     : 140,
		},
		{
			columnName: 'Tier',
			columnId  : 'tier',
		},
	];
	public dateRange: number = 0;
	public detailColumnList: TableColumns[] = [
		{
			columnName: 'Transaction Date',
			columnId  : 'dateDisplay',
		},
		{
			columnName: 'Amount',
			columnId  : 'amount',
			format    : Constants.currencyFormat,
		},
		{
			columnName: 'Transaction',
			columnId  : 'transaction',
		},
		{
			columnName: 'Account',
			columnId  : 'account',
		},
	];
	public emptyGridMessage: string = 'No transactions currently available.';
	public form: FormGroup;
	public settings: SettingsState;
	public snapshotAccountingList: SnapshotAccountingList;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private snapshotAccountingService: SnapshotAccountingService,
		private cd: ChangeDetectorRef,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private store: Store<any>,
	) {
		if (this.route.snapshot.data['snapshotAccountingList']) {
			this.initializeRouterParams();
		}
	}

	ngOnInit() {
		this.initializeState();
		this.form = this.buildForm();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public search(): void {
		const payload = this.buildPayload();
		this.getClosedPeriodsByID(payload);
	}

	public clear(): void {
		this.getClosedPeriods();
	}

	public isQueryValid(): boolean {
		return !!(
			this.form.get('memberBenefitID').value ||
			this.form.get('dateRangeDropDownEnum').value
		);
	}

	private initializeRouterParams(): void {
		this.snapshotAccountingList = this.route.snapshot.data['snapshotAccountingList'];
		this.benefitType = this.snapshotAccountingList.memberBenefitIDUsed;
		this.dateRange = this.snapshotAccountingList.dateRangeDropDownEnumUsed;
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			memberBenefitID : new FormControl(this.benefitType),
			dateRangeDropDownEnum: new FormControl(this.dateRange.toString()),
		});

		return form;
	}

	private buildPayload(): SnapshotAccountingPayload {
		const payload: SnapshotAccountingPayload = new SnapshotAccountingPayload();
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				payload[property] = (this.form.get(property) && this.form.get(property).value) ? this.form.controls[property].value : Constants.emptyInt;
			}
		}

		return payload;
	}

	private getClosedPeriodsByID(payload: SnapshotAccountingPayload): void {
		this.snapshotAccountingService.getClosedPeriodsByID(payload).subscribe(response => this.setDropdownValues(response));
	}

	private getClosedPeriods(): void {
		this.snapshotAccountingService.getClosedPeriods().subscribe(response => this.setDropdownValues(response));
	}

	private setDropdownValues(response: SnapshotAccountingList): void {
		this.snapshotAccountingList = response;
		this.benefitType = response.memberBenefitIDUsed;
		this.dateRange = response.dateRangeDropDownEnumUsed;
		this.form.get('memberBenefitID').setValue(this.benefitType);
		this.form.get('dateRangeDropDownEnum').setValue(this.dateRange.toString());
		this.cd.detectChanges();
	}
}
