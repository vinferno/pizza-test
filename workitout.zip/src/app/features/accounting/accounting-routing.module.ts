import { NgModule }                                 from '@angular/core';
import { RouterModule, Routes }                     from '@angular/router';

import { AccountingComponent }                      from './accounting.component';
import { accountingResolvers }                      from '../../infrastructure/core/resolvers/accounting/accounting-resolvers';
import { AccountTransactionsPresentationComponent } from './account-transactions/account-transactions-presentation.component';
import { AccountTransactionsSmartComponent }        from './account-transactions/account-transactions-smart.component';
import { BenefitTransactionsPresentationComponent } from './benefit-transactions/benefit-transactions-presentation.component';
import { BenefitTransactionsSmartComponent }        from './benefit-transactions/benefit-transactions-smart.component';
import { TitleResolver }                            from '../../infrastructure/core/resolvers/title.resolver';

@NgModule({
	imports : [RouterModule],
	exports : [RouterModule],
})
export class AccountingRoutingModule { }

export const routedComponents = [
	AccountingComponent,
	AccountTransactionsPresentationComponent,
	AccountTransactionsSmartComponent,
	BenefitTransactionsPresentationComponent,
	BenefitTransactionsSmartComponent,
];

export const ACCOUNTING_TAB_ROUTES: Routes = [
	{
	  path       : '',
	  component  : AccountingComponent,
	  resolve    : {
		title: TitleResolver,
	  },
	  children   : [
		{
		  path      : 'account-transactions',
		  component : AccountTransactionsSmartComponent,
		  resolve   : {
			accountTransactionList: accountingResolvers.AccountTransactionsResolver,
		  },
		},
		{
		  path      : 'benefit-transactions',
		  component : BenefitTransactionsSmartComponent,
		  resolve   : {
			snapshotAccountingList: accountingResolvers.BenefitTransactionsResolver,
		  },
		},
		{
			path: '',
			redirectTo: 'account-transactions',
			pathMatch  : 'full',
		},
	  ],
	},
  ];
