import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                  from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                                  from '@angular/forms';
import {
	ActivatedRoute,
}                                  from '@angular/router';

import { Store }                   from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                  from 'rxjs';

import {
	AccountingPayload,
	AccountTransactionList,
}                                  from '../../../infrastructure/interfaces/accounting';
import { Constants }               from '../../../infrastructure/utils/constants';
import { MemberAccountingService } from '../../../infrastructure/core/services/member-accounting.service';
import { SettingsState }           from '../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }            from '../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-account-transactions',
	templateUrl     : './account-transactions-smart.component.html',
	styleUrls       : ['./account-transactions-smart.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AccountTransactionsSmartComponent implements OnInit, OnDestroy {
	public accountTransactionList: AccountTransactionList;
	public accountType: number;
	public columnList: TableColumns[] = [
		{
			columnName: 'Date',
			columnId  : 'dateToUse',
			width     : 90,
		},
		{
			columnName: 'Transaction',
			columnId  : 'transaction',
			width     : 175,
		},
		{
			columnName: 'Amount',
			columnId  : 'amount',
			format    : Constants.currencyFormat,
			width     : 100,
		},
		{
			columnName: 'Billing Period',
			columnId  : 'billingPeriodDisplay',
		},
		{
			columnName: 'Benefit',
			columnId  : 'benefitName',
		},
		{
			columnName: 'Payroll Code',
			columnId  : 'payrollCode',
		},
	];
	public dateRange: number;
	public emptyGridMessage: string = 'No transactions currently available.';
	public form: FormGroup;
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor (
		private memberAccountingService: MemberAccountingService,
		private cd: ChangeDetectorRef,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private store: Store<any>,
	) {
		if (this.route.snapshot.data['accountTransactionList']) {
			this.initializeRouterParams();
		}
	}

	ngOnInit() {
		this.initializeState();
		this.form = this.buildForm();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	public search(): void {
		const payload = this.buildPayload();
		this.getAccountTransactionListByID(payload);
	}

	public clear(): void {
		this.getAccountTransactionList();
	}

	public isQueryValid(): boolean {
		return !!(
			this.form.get('accountID').value ||
			this.form.get('dateRangeDropDownEnum').value
		);
	}

	private initializeRouterParams(): void {
		this.accountTransactionList = this.route.snapshot.data['accountTransactionList'];
		this.accountType = this.accountTransactionList.accountIDUsed;
		this.dateRange = this.accountTransactionList.dateRangeDropDownEnumUsed;
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}

	private buildForm(): FormGroup {
		const form: FormGroup = this.fb.group({
			accountID: new FormControl(this.accountType),
			dateRangeDropDownEnum: new FormControl(this.dateRange.toString()),
		});

		return form;
	}

	private buildPayload(): AccountingPayload {
		const payload: AccountingPayload = new AccountingPayload();
		for (const property in payload) {
			if (payload.hasOwnProperty(property)) {
				payload[property] = (this.form.get(property) && this.form.get(property).value) ? this.form.controls[property].value : Constants.emptyInt;
			}
		}

		return payload;
	}

	private getAccountTransactionListByID(payload: AccountingPayload): void {
		this.memberAccountingService.getAccountTransactionListByID(payload).subscribe(response => this.setDropdownValues(response));
	}

	private getAccountTransactionList(): void {
		this.memberAccountingService.getAccountTransactionList().subscribe(response => this.setDropdownValues(response));
	}

	private setDropdownValues(response: AccountTransactionList): void {
		this.accountTransactionList = response;
		this.accountType = response.accountIDUsed;
		this.dateRange = response.dateRangeDropDownEnumUsed;
		this.form.get('accountID').setValue(this.accountType);
		this.form.get('dateRangeDropDownEnum').setValue(this.dateRange.toString());
		this.cd.detectChanges();
	}
}
