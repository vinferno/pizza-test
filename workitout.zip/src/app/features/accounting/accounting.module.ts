import { CommonModule }           from '@angular/common';
import { NgModule }               from '@angular/core';
import {
	FormsModule,
	ReactiveFormsModule,
}                                 from '@angular/forms';

import { FlexLayoutModule }       from '@angular/flex-layout';

import {
	AccountingRoutingModule,
	routedComponents,
}                                 from './accounting-routing.module';
import { ControlsModule }         from '../../infrastructure/shared/controls/controls.module';
import { CovalentModule }         from '../../infrastructure/utils/covalent.module';
import { DevExtremeModule }       from '../../infrastructure/utils/devextreme.module';
import { MaterialModule }         from '../../infrastructure/utils/material.module';
import { SharedModule }           from 'app/infrastructure/shared/shared.module';
import { resolvers }              from '../../infrastructure/core/resolvers/resolvers';

@NgModule({
	imports     : [
		CommonModule,
		AccountingRoutingModule,
		MaterialModule,
		FormsModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		SharedModule,
		ControlsModule,
		CovalentModule,
		DevExtremeModule,
	],
	declarations: [routedComponents],
	providers   : [
		resolvers,
	],
})
export class AccountingModule { }
