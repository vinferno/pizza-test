import {
	ChangeDetectionStrategy,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
 }                           from '@angular/core';

import { Store }             from '@ngrx/store';
import {
	Observable,
	Subscription,
}                            from 'rxjs';

import { animator }          from '../../infrastructure/core/animations/animations';
import { SettingsState }     from '../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-accounting',
	templateUrl     : './accounting.component.html',
	styleUrls       : ['./accounting.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class AccountingComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public navLinks = [
		{
			label : 'Account Transactions',
			path  : 'account-transactions',
		},
		{
			label : 'Benefit Transactions',
			path  : 'benefit-transactions',
		},
	];
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private store: Store<any>,
	) { }

	ngOnInit() {
		this.initializeState();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => { this.settings = settings; });
		this.subscriptions.push(settingsSubscription);
	}
}
