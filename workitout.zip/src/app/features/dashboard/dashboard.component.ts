import {
	Component,
	HostBinding,
	OnInit,
}                   from '@angular/core';

import { Store }    from '@ngrx/store';

import { animator } from '../../infrastructure/core/animations/animations';

@Component({
	selector: 'hg-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss'],
	animations: [animator.slide],
})
export class DashboardComponent implements OnInit {
	@HostBinding('@routeAnimation') routeAnimation = true;
	@HostBinding('style.display') display = 'block';

	public selectedMemberOptions: any = { dashboardTemplate: '' };
	public template;
	public sessionState;
	public session;

	constructor(
		private store: Store<any>,
	) {
		this.sessionState = this.store.select('sessionState');
	}

	ngOnInit() {
		this.sessionState.subscribe( session => {
			this.session = session;
			this.selectedMemberOptions = session.selectedMemberOptions;
			if (this.session.selectedMemberOptions && this.selectedMemberOptions.dashboardTemplate) {
				this.template = this.selectedMemberOptions.dashboardTemplate;
			} else {
				this.template = '';
			}
		});
	}
}
