import { CommonModule }           from '@angular/common';
import { NgModule }               from '@angular/core';
import { CdkTableModule }         from '@angular/cdk/table';
import { MatTableModule } from "@angular/material/table";
import { FormsModule }            from '@angular/forms';
import { FlexLayoutModule }       from '@angular/flex-layout';

import { CoreModule }             from '../../infrastructure/core/core.module';
import { SharedModule }           from 'app/infrastructure/shared/shared.module';
import { EnrollmentWizardBundle } from '../enrollment/enrollment-wizard/enrollment-wizard.component';
import { ControlsModule }         from '../../infrastructure/shared/controls/controls.module';
import { CovalentModule }         from '../../infrastructure/utils/covalent.module';
import { DevExtremeModule }       from '../../infrastructure/utils/devextreme.module';
import { MaterialModule }         from '../../infrastructure/utils/material.module';
import { AccountingModule }       from '../accounting/accounting.module';
import {
	DashboardRoutingModule,
	routedComponents,
}                                 from './dashboard-routing.module';

@NgModule({
	imports: [
		CommonModule,
		CoreModule,
		CdkTableModule,
		DevExtremeModule,
		FlexLayoutModule,
		MatTableModule,
		FormsModule,
		MaterialModule,
		CovalentModule,
		SharedModule.forRoot(),
		ControlsModule,
		AccountingModule,
		DashboardRoutingModule,
	],
	declarations: [routedComponents, EnrollmentWizardBundle],
})
export class DashboardModule { }
