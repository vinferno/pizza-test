import { NgModule }                               from '@angular/core';
import { CommonModule }                           from '@angular/common';
import { RouterModule, Routes }                   from '@angular/router';
import { ReactiveFormsModule }                    from '@angular/forms';

import { CoreModule }                             from '../../infrastructure/core/core.module';

//#region Guards
import { AuthGuard }                               from '../../infrastructure/core/guards/auth.guard';
import { CheckoutCompleteGuard }                   from '../../infrastructure/core/guards/checkout-complete-guard.service';
import { DependentVerificationGuard }              from '../../infrastructure/core/guards/dependent-verification-guard.service';
import { DialogGuardService }                      from '../../infrastructure/core/guards/dialog-guard.service';
import { EnrollmentDashboardInitializeGuard }      from '../../infrastructure/core/guards/enrollment-dashboard-initialize-guard.service';
import { EnrollmentGuard }                         from '../../infrastructure/core/guards/enrollment-guard.service';
import { FormGuardService }                        from '../../infrastructure/core/guards/form-guard.service';
import { LifeEventVerificationGuard }              from '../../infrastructure/core/guards/life-event-verification-guard.service';
import { WidgetAddDependentGuard }                 from '../../infrastructure/core/guards/widget-add-dependent.guard';
import { MemberAccountingGuard }                   from '../../infrastructure/core/guards/member-accounting-guard.service';
//#endregion

//#region Components
import {
	PROFILE_TAB_ROUTES,
	routedComponents as accountRoutedComponents,
	routedEntryComponents as accountRoutedEntryComponents,
}                                                 from '../profile/profile-routing.module';

import { ACCOUNTING_TAB_ROUTES }                  from '../accounting/accounting-routing.module';

import {
	BENEFIT_TAB_ROUTES,
	routedComponents as benefitsRoutedComponents,
	entryComponents as benefitsEntryComponents,
}                                                 from '../benefits/benefits-routing.module';

import { CheckoutCompleteSmartComponent }         from '../checkout-complete/checkout-complete-smart.component';
import { CheckoutCompletePresentationComponent }  from '../checkout-complete/checkout-complete-presentation.component';

import { DashboardComponent }                     from './dashboard.component';

import { DependentVerificationPresentationComponent } from '../dependent-verification/dependent-verification-presentation.component';
import { DependentVerificationSmartComponent }    from '../dependent-verification/dependent-verification-smart.component';
import {
	DependentVerifyComponents,
	DependentVerifyEntryComponents,
}                                                 from '../dependent-verification/index';

import {
	EnrollmentWizardComponent,
	EnrollWizardModalComponent,
}                                                 from '../enrollment/enrollment-wizard/enrollment-wizard.component';

import { FaqComponent }                           from '../faq/faq.component';

import { LifeEventVerificationComponent }         from '../life-event-verification/life-event-verification.component';

import { PayrollComponent }                       from '../payroll/payroll.component';

import {
	routedComponents as enrollmentWizardRoutedComponents,
}                                                 from '../enrollment/enrollment-wizard/enrollment-wizard-forms-routing.module';
import {
	ResourcesRoutingModule,
	RESOURCE_TAB_ROUTES,
	routedComponents as resourcesRoutedComponents,
}                                                 from '../resources/resources-routing.module';

import { ModifyBeneficiaryComponent }              from '../beneficiaries/modify-beneficiary-dialog/modify-beneficiary/modify-beneficiary.component';
import { ModifyBeneficiaryPresentationComponent }  from '../beneficiaries/modify-beneficiary-dialog/modify-beneficiary/modify-beneficiary-presentation.component';
import { ModifyBeneficiaryDialogComponent }        from '../beneficiaries/modify-beneficiary-dialog/modify-beneficiary-dialog.component';
import { BeneficiariesComponent }                  from '../beneficiaries/beneficiaries.component';
import { BeneficiariesPresentationComponent }      from '../beneficiaries/beneficiaries-presentation.component';
import { BeneficiaryCardComponent }                from '../beneficiaries/beneficiary-card/beneficiary-card.component';
import { WidgetAddDependentComponent }             from '../enrollment/enrollment-dashboard/widget-add-dependent/widget-add-dependent.component';
//#endregion

//#region Resolvers
import { TitleResolver }                          from '../../infrastructure/core/resolvers/title.resolver';
import { DependentVerificationResolver }          from '../../infrastructure/core/resolvers/dependent-verification.resolver';
import { EnrollmentOnboardingInitializeResolver } from '../../infrastructure/core/resolvers/enrollment-onboarding-initialize.resolver';
import { LifeEventVerificationResolver }          from '../../infrastructure/core/resolvers/life-event-verification.resolver';
import { WidgetAddDependentResolver }             from '../../infrastructure/core/resolvers/widget-add-dependent.resolver';
import { FormWelcomeComponent } from '../enrollment/enrollment-wizard/forms/form-welcome/form-welcome.component';
//#endregion

const routes: Routes = [
	{
		path: 'dashboard',
		canActivate: [AuthGuard],
		component: DashboardComponent,
		data: {title: 'Dashboard'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path: 'enrollment/:categoryId',
		component: EnrollWizardModalComponent,
		canActivate: [AuthGuard],
		canDeactivate: [DialogGuardService],
	},
	{
		path: 'enrollment/welcome',
		component: EnrollWizardModalComponent,
		canActivate: [AuthGuard, EnrollmentGuard],
		canDeactivate: [FormGuardService],
		data: {title: 'Enrollment'},
		resolve: {
			title: TitleResolver,
			onboarding: EnrollmentOnboardingInitializeResolver,
		},
	},
	{
		path: 'enrollment',
		component: EnrollWizardModalComponent,
		canActivate: [AuthGuard, EnrollmentGuard],
		canDeactivate: [FormGuardService],
		data: {title: 'Enrollment'},
		resolve: {
			title: TitleResolver,
			onboarding: EnrollmentOnboardingInitializeResolver,
		},
	},
	{
		path: 'enrollment-dashboard',
		canActivate: [AuthGuard, EnrollmentDashboardInitializeGuard],
		canActivateChild: [AuthGuard],
		loadChildren: '../enrollment/enrollment-dashboard/enrollment-dashboard.module#EnrollmentDashboardModule',
		data: {title: 'Enrollment'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path       : 'checkout-complete',
		canActivate: [
			AuthGuard,
			CheckoutCompleteGuard,
		],
		canDeactivate: [CheckoutCompleteGuard],
		component  : CheckoutCompleteSmartComponent,
		data: {title: 'Checkout Complete'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path: 'profile',
		canActivate: [AuthGuard],
		canActivateChild: [AuthGuard],
		children: PROFILE_TAB_ROUTES,
		data: {title: 'Profile'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path: 'member-accounting',
		canActivate: [
			AuthGuard,
			MemberAccountingGuard,
		],
		canActivateChild: [AuthGuard],
		children: ACCOUNTING_TAB_ROUTES,
		data: {title: 'Accounting'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path: 'dependent-verification',
		component: DependentVerificationSmartComponent,
		canActivate: [
			AuthGuard,
			DependentVerificationGuard,
		],
		data: {title: 'Dependent Verification'},
		resolve: {
			dependents: DependentVerificationResolver,
			title: TitleResolver,
		},
	},
	{
		path: 'life-event-verification',
		component: LifeEventVerificationComponent,
		canActivate: [
			AuthGuard,
			LifeEventVerificationGuard,
		],
		data: {title: 'Life Event Verification'},
		resolve: {
			lifeEvents: LifeEventVerificationResolver,
			title: TitleResolver,
		},
	},
	{
		path: 'benefits',
		canActivate: [AuthGuard],
		canActivateChild: [AuthGuard],
		children: BENEFIT_TAB_ROUTES,
		data: {title: 'Benefits'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path       : 'beneficiaries',
		canActivate: [AuthGuard],
		component  : BeneficiariesComponent,
		data: {title: 'Beneficiaries'},
		resolve: {
			title: TitleResolver,
		},
	},
	// {
	// 	path          : 'payroll',
	// 	component     : PayrollComponent,
	// },
	{
		path: 'resources',
		canActivate: [AuthGuard],
		canActivateChild: [AuthGuard],
		children: RESOURCE_TAB_ROUTES,
		data: {title: 'Resources'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path: 'faq',
		component: FaqComponent,
		canActivate: [AuthGuard],
		data: {title: 'F. A. Q.'},
		resolve: {
			title: TitleResolver,
		},
	},
	{
		path: 'widget-add-dependent',
		component: WidgetAddDependentComponent,
		canActivate: [
			AuthGuard,
			WidgetAddDependentGuard,
		],
		data: { subTitle: 'Widget Add Dependent'},
		resolve: {
			title: TitleResolver,
		},
	},
];

@NgModule({
	imports: [
		RouterModule.forChild(routes),
		CommonModule,
		ReactiveFormsModule,
		CoreModule,
		ResourcesRoutingModule,
	],
	exports: [RouterModule],
	providers: [
		CheckoutCompleteGuard,
		DependentVerificationGuard,
		DialogGuardService,
		FormGuardService,
		EnrollmentGuard,
		LifeEventVerificationGuard,
		MemberAccountingGuard,
		WidgetAddDependentGuard,
	],
	entryComponents: [
		accountRoutedEntryComponents,
		benefitsEntryComponents,
		EnrollWizardModalComponent,
		DependentVerifyEntryComponents,
		ModifyBeneficiaryDialogComponent,
	],
})
export class DashboardRoutingModule { }

export const routedComponents = [
	accountRoutedComponents,
	BeneficiariesComponent,
	BeneficiariesPresentationComponent,
	BeneficiaryCardComponent,
	benefitsRoutedComponents,
	CheckoutCompleteSmartComponent,
	CheckoutCompletePresentationComponent,
	DependentVerificationPresentationComponent,
	DependentVerificationSmartComponent,
	enrollmentWizardRoutedComponents,
	FaqComponent,
	LifeEventVerificationComponent,
	ModifyBeneficiaryComponent,
	ModifyBeneficiaryPresentationComponent,
	ModifyBeneficiaryDialogComponent,
	PayrollComponent,
	resourcesRoutedComponents,
	DependentVerifyComponents,
	WidgetAddDependentComponent,
];
