import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	Output,
}                        from '@angular/core';

import {
	BeneficiaryPayload,
	BeneficiariesResponse,
}                        from 'app/infrastructure/interfaces/beneficiary';
import { ListItem }      from 'app/infrastructure/interfaces/list-item';
import { SettingsState } from 'app/infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-modify-beneficiary-presentation',
	templateUrl     : './modify-beneficiary-presentation.component.html',
	styleUrls       : ['./modify-beneficiary-presentation.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class ModifyBeneficiaryPresentationComponent {
	@Input() public beneficiariesResponse: BeneficiariesResponse;
	@Input() public beneficiaryRelationshipOptions: ListItem[];
	@Input() public settings: SettingsState;

	@Output() public emitPostForm = new EventEmitter<BeneficiaryPayload>();
	@Output() public emitClose = new EventEmitter<void>();

	public postForm(payload: BeneficiaryPayload): void {
		this.emitPostForm.emit(payload);
	}

	public clearForm(): void {
		this.emitClose.emit();
	}
}
