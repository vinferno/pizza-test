import {
	Component,
	EventEmitter,
	Inject,
	OnInit,
	ChangeDetectionStrategy,
	Output,
}                                 from '@angular/core';
import { MAT_DIALOG_DATA } from "@angular/material/dialog";

import { Store }                  from '@ngrx/store';
import { Observable }             from 'rxjs';
import { map }                    from 'rxjs/operators';

import {
	BeneficiaryPayload,
	BeneficiariesResponse,
}                                 from 'app/infrastructure/interfaces/beneficiary';
import {
	ListItem,
	ListItemList,
}                                 from 'app/infrastructure/interfaces/list-item';
import { LookupService }          from 'app/infrastructure/core/services/lookup.service';
import { MyBeneficiariesService } from 'app/infrastructure/core/services/mybeneficiaries.service';
import { SettingsState }          from 'app/infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-modify-beneficiary',
	template        :
		`<hg-modify-beneficiary-presentation
			[beneficiariesResponse]="(beneficiariesResponse$ | async)"
			[beneficiaryRelationshipOptions]="(beneficiaryRelationshipOptions$ | async)"
			[settings]="(settingsState$ | async)"
			(emitPostForm)="postForm($event)"
			(emitClose)="closeModal()"
		></hg-modify-beneficiary-presentation>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class ModifyBeneficiaryComponent implements OnInit {
	@Output() public emitClose = new EventEmitter<void>();

	public beneficiariesResponse$: Observable<BeneficiariesResponse>;
	public beneficiaryRelationshipOptions$: Observable<ListItem[]>;
	public settingsState$: Observable<SettingsState>;

	constructor(
		@Inject(MAT_DIALOG_DATA) public memberBenefitId: number,
		private lookupService: LookupService,
		private service: MyBeneficiariesService,
		private store: Store<any>,
	) { }

	public ngOnInit(): void {
		this.initializeState();
		this.getBeneficiaryList();
		this.getBeneficiaryRelationships();
	}

	public postForm(payload: BeneficiaryPayload): void {
		this.service.setBeneficiaries(payload).subscribe(() => this.emitClose.emit());
	}

	public closeModal(): void {
		this.emitClose.emit();
	}

	private initializeState(): void {
		this.settingsState$ = this.store.select('settingsState');
	}

	private getBeneficiaryList(): void {
		this.beneficiariesResponse$ = this.service.getBeneficiaryByBenefit(this.memberBenefitId).pipe(map((beneficiariesResponse) => beneficiariesResponse));
	}

	private getBeneficiaryRelationships(): void {
		this.beneficiaryRelationshipOptions$ = this.lookupService.getBeneficiaryRelationships().pipe(map((relationships: ListItemList) => relationships.items));
	}
}
