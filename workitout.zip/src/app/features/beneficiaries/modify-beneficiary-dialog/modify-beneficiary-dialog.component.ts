import {
	Component,
	OnInit,
	ChangeDetectionStrategy,
}                       from '@angular/core';
import { MatDialogRef } from "@angular/material/dialog";

import { ModalService } from '../../../infrastructure/core/services/modal.service';

@Component({
	selector        : 'hg-modify-beneficiary-dialog',
	template        :
		`<hg-modify-beneficiary
			(emitClose)="closeModal($event)"
		></hg-modify-beneficiary>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class ModifyBeneficiaryDialogComponent implements OnInit {
	constructor(
		private dialogRef: MatDialogRef<ModifyBeneficiaryDialogComponent>,
		private modals: ModalService,
	) { }

	public ngOnInit(): void {
		this.modals.addModal(this.dialogRef);
	}

	public closeModal(response: any): void {
		this.dialogRef.close(response);
	}
}
