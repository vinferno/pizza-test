import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	Input,
	Output,
}                                           from '@angular/core';
import { MatDialog } from "@angular/material/dialog";

import { BeneficiaryCard }                  from '../../../infrastructure/interfaces/beneficiary';
import { FormPersistentService }            from '../../../infrastructure/core/services/form-persistent.service';
import { ModalService }                     from '../../../infrastructure/core/services/modal.service';
import { ModifyBeneficiaryDialogComponent } from '../modify-beneficiary-dialog/modify-beneficiary-dialog.component';
import { SettingsState }                    from 'app/infrastructure/store/reducers/settings/settings-state';
import { TableColumns }                     from '../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-beneficiary-card',
	templateUrl     : './beneficiary-card.component.html',
	styleUrls       : ['./beneficiary-card.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BeneficiaryCardComponent {
	@Input() public beneficiaryCards: BeneficiaryCard[];
	@Input() public settings: SettingsState;

	@Output() public closeDialog = new EventEmitter<void>();

	public columnList: TableColumns[] = [
		{
			columnName: 'Name',
			columnId: 'name',
		},
		{
			columnName: 'Relationship',
			columnId: 'relationship',
		},
	];

	constructor(
		public dialog: MatDialog,
		private formService: FormPersistentService,
		private modals: ModalService,
	) { }

	public openDialog(id: number): void {
		const dialogRef = this.dialog.open(ModifyBeneficiaryDialogComponent, { data: id, disableClose: true, autoFocus: false });
		this.formService.setDialogRef(dialogRef);
		dialogRef.afterClosed().subscribe(() => this.closeDialog.emit());
		this.modals.addModal(dialogRef);
	}
}
