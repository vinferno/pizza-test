import {
	ChangeDetectionStrategy,
	Component,
	EventEmitter,
	HostBinding,
	Input,
	Output,
}                              from '@angular/core';

import { animator }            from '../../infrastructure/core/animations/animations';
import { BeneficiaryCardList } from '../../infrastructure/interfaces/beneficiary';
import { SettingsState }       from 'app/infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-beneficiaries-presentation',
	templateUrl     : './beneficiaries-presentation.component.html',
	styleUrls       : ['./beneficiaries-presentation.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BeneficiariesPresentationComponent {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	@Input() public beneficiaryList: BeneficiaryCardList;
	@Input() public settings: SettingsState;

	@Output() public emitClose = new EventEmitter<void>();

	public closeDialog(): void {
		this.emitClose.emit();
	}
}
