import {
	ChangeDetectionStrategy,
	Component,
	OnInit,
}                                 from '@angular/core';

import { Store }                  from '@ngrx/store';
import { Observable }             from 'rxjs';

import { BeneficiaryCardList }    from '../../infrastructure/interfaces/beneficiary';
import { MyBeneficiariesService } from '../../infrastructure/core/services/mybeneficiaries.service';
import { SettingsState }          from 'app/infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-beneficiaries',
	template        :
		`<hg-beneficiaries-presentation
			[beneficiaryList]="(beneficiaryList$ | async)"
			[settings]="(settingsState$ | async)"
			(emitClose)="getBeneficiaryList()"
		></hg-beneficiaries-presentation>`,
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BeneficiariesComponent implements OnInit {
	public beneficiaryList$: Observable<BeneficiaryCardList>;
	public settingsState$: Observable<SettingsState>;

	constructor(
		private myBeneficiariesService: MyBeneficiariesService,
		private store: Store<SettingsState>,
	) { }

	public ngOnInit(): void {
		this.settingsState$ = this.store.select('settingsState');
		this.getBeneficiaryList();
	}

	public getBeneficiaryList(): void {
		this.beneficiaryList$ = this.myBeneficiariesService.getBeneficiary();
	}
}
