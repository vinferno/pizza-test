import { Routes }                             from '@angular/router';

import { benefitResolvers }                   from '../../infrastructure/core/resolvers/benefits/benefit-resolvers';
import { BenefitSummaryComponent }            from './benefit-summary/benefit-summary.component';
import { BenefitSummaryEmailDialogComponent } from './benefit-summary/benefit-summary-email-dialog/benefit-summary-email-dialog.component';
import { CurrentBenefitsComponent }           from './current-benefits/current-benefits.component';
import { EnrollmentRequestComponent }            from './enrollment-request/enrollment-request.component';
import { PendingEOIComponent }                   from './pending-eoi/pending-eoi.component';
import { RenewalBenefitsComponent }              from './renewal-benefits/renewal-benefits.component';
import { TitleResolver }                         from '../../infrastructure/core/resolvers/title.resolver';
import { PaymentInformationComponent }           from './payment-information/payment-information.component';
import { PaymentInformationCollectionComponent } from './payment-information/payment-information-collection/payment-information-collection.component';

export const routedComponents = [
	BenefitSummaryComponent,
	BenefitSummaryEmailDialogComponent,
	CurrentBenefitsComponent,
	EnrollmentRequestComponent,
	PendingEOIComponent,
	RenewalBenefitsComponent,
	PaymentInformationComponent,
	PaymentInformationCollectionComponent,
];

export const entryComponents = [
	BenefitSummaryEmailDialogComponent,
];

export const BENEFIT_TAB_ROUTES: Routes = [
	{
		path       : '',
		redirectTo : 'current-benefits',
		pathMatch  : 'full',
	},
	{
		path       : 'benefit-summary',
		component  : BenefitSummaryComponent,
		data: {title: 'Benefit Summary'},
		resolve: {
			title: TitleResolver,
			benefits: benefitResolvers.BenefitSummaryResolver,
		},
	},
	{
		path       : 'current-benefits',
		component  : CurrentBenefitsComponent,
		data: {title: 'Current Benefits'},
		resolve: {
			title: TitleResolver,
			benefits: benefitResolvers.CurrentBenefitsResolver,
		},
	},
	{
		path       : 'enrollment-requests',
		component  : EnrollmentRequestComponent,
		data: {title: 'Enrollment Requests'},
		resolve: {
			title: TitleResolver,
			benefits: benefitResolvers.EnrollmentRequestsResolver,
		},
	},
	{
		path       : 'benefits-at-renewal',
		component  : RenewalBenefitsComponent,
		data: {title: 'Benefits At Renewal'},
		resolve: {
			title: TitleResolver,
			benefits: benefitResolvers.BenefitsAtRenewalResolver,
		},
	},
	{
		path       : 'pending-eoi',
		component  : PendingEOIComponent,
		data: {title: 'Pending EOI'},
		resolve: {
			title: TitleResolver,
			benefits: benefitResolvers.PendingEOIResolver,
		},
	},
	{
		path       : 'payment-information',
		component  : PaymentInformationComponent,
		data: {title: 'Payment Information'},
	},
];
