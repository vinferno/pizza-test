import {
	ChangeDetectionStrategy,
	Component,
	Input,
	Inject,
	OnDestroy,
	OnInit,
}                            from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
}                            from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";

import { Store }             from '@ngrx/store';
import {
	Observable,
	Subscription,
}                            from 'rxjs';

import {
	BenefitSummaryItemList,
	BenefitSummaryItemPayload,
	BenefitSummaryItem,
}                            from '../../../../infrastructure/interfaces/benefit';
import { IError }            from '../../../../infrastructure/interfaces/error';
import { MyBenefitsService } from '../../../../infrastructure/core/services/mybenefits.service';
import { SettingsState }     from '../../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-benefit-summary-email-dialog',
	templateUrl     : './benefit-summary-email-dialog.component.html',
	styleUrls       : ['./benefit-summary-email-dialog.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BenefitSummaryEmailDialogComponent implements OnInit, OnDestroy {
	public benefitSummaryEmailForm: FormGroup;
	public postError: IError = {
		header      : '',
		description : 'Please contact your HR Administrator if you have any questions.',
	};
	public isPostInvalid: boolean = false;
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		@Inject(MAT_DIALOG_DATA) public benefitSummaryList: BenefitSummaryItem,
		private fb: FormBuilder,
		public dialogRef: MatDialogRef<BenefitSummaryEmailDialogComponent>,
		private myBenefitsService: MyBenefitsService,
		public store: Store<any>,
	) {
		this.benefitSummaryEmailForm = this.fb.group({
			toAddress: new FormControl(''),
		});
	}

	ngOnInit() {
		this.initializeState();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postEmail(): void {
		const payload: BenefitSummaryItemPayload = new BenefitSummaryItemPayload;
		payload.benefitSummaryID = this.benefitSummaryList.benefitSummaryID;
		payload.toAddress = this.benefitSummaryEmailForm.get('toAddress').value;

		this.myBenefitsService.postBenefitsSummaryEmail(payload).subscribe(() => {
			this.dialogRef.close();
		},
		error => {
			this.postError = error;
			this.isPostInvalid = true;
		});
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
		});
		this.subscriptions.push(settingsSubscription);
	}
}
