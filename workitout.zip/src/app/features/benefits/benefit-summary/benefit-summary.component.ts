import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
}                                             from '@angular/core';
import { MatDialog } from "@angular/material/dialog";
import { DomSanitizer, SafeResourceUrl }      from '@angular/platform-browser';
import { ActivatedRoute }                     from '@angular/router';

import { Store }                              from '@ngrx/store';
import {
	Observable,
	Subscription,
}                                             from 'rxjs';

import {
	BenefitSummaryItem,
	BenefitSummaryItemList,
}                                             from '../../../infrastructure/interfaces/benefit';
import { BenefitSummaryEmailDialogComponent } from './benefit-summary-email-dialog/benefit-summary-email-dialog.component';
import { environment }                        from 'environments/environment';
import { ModalService }                       from '../../../infrastructure/core/services/modal.service';
import { SessionState }                       from '../../../infrastructure/store/reducers/session/session-state';
import { SettingsState }                      from '../../../infrastructure/store/reducers/settings/settings-state';
import { TableColumns }                       from '../../../infrastructure/interfaces/table-columns';

@Component({
	selector        : 'hg-benefit-summary',
	templateUrl     : './benefit-summary.component.html',
	styleUrls       : ['./benefit-summary.component.scss'],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class BenefitSummaryComponent implements OnInit, OnDestroy {
	public benefitSummaryList: BenefitSummaryItemList;
	public downloadUrl: SafeResourceUrl = null;
	public displayedColumns: TableColumns[] = [
		{
			columnName : 'File Name',
			columnId   : 'linkText',
		},
		{
			columnName : 'Created On',
			columnId   : 'createdOn',
		},
	];
	public emptyGridMessage: string = 'No benefits or requests currently selected.';
	public session: SessionState;
	public settings: SettingsState;

	private sessionState: Observable<SessionState>;
	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		private cd: ChangeDetectorRef,
		public dialog: MatDialog,
		private modals: ModalService,
		private route: ActivatedRoute,
		private sanitizer: DomSanitizer,
		private store: Store<any>,
	) {
		this.benefitSummaryList = this.route.snapshot.data['benefits'];
	}

	ngOnInit() {
		this.initializeState();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public downloadBenefitSummary(cell: BenefitSummaryItem): void {
		const id = cell.benefitSummaryID;
		const fingerprint = this.session.fingerprint;
		if (id && fingerprint) {
			const url = `${environment.apiRoute}/content/downloads/memberDocument?id=${id}&fp=${fingerprint}`;
			this.downloadUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
		}
	}

	public openDialog(cell: BenefitSummaryItem): void {
		const dialogRef = this.dialog.open(BenefitSummaryEmailDialogComponent, { data: cell });
		this.modals.addModal(dialogRef);
	}

	private initializeState(): void {
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.sessionState.subscribe(session => {
			this.session = session;
		});
		this.subscriptions.push(sessionSubscription);
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}
}
