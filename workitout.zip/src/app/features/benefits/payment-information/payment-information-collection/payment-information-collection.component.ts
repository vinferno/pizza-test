import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	Input,
	OnDestroy,
	OnInit,
}                                   from '@angular/core';
import {
	FormBuilder,
	FormGroup,
	Validators,
}                                   from '@angular/forms';

import { Store }                    from '@ngrx/store';
import { Subscription }             from 'rxjs';

import { IError }                   from '../../../../infrastructure/interfaces/error';
import { IToast }                   from '../../../../infrastructure/interfaces/toast';
import { MaskService }              from '../../../../infrastructure/core/services/mask.service';
import { MyBenefitsService }        from '../../../../infrastructure/core/services/mybenefits.service';
import { SettingsState }            from '../../../../infrastructure/store/reducers/settings/settings-state';
import { USAePay, USAePayPayload }  from '../../../../infrastructure/interfaces/usa-epay';
import { ValidationService }        from '../../../../infrastructure/core/validation/validation.service';
import { ValidationZipcode }        from '../../../../infrastructure/core/validation/validation-zipcode';

@Component({
	selector       : 'hg-payment-information-collection',
	templateUrl    : './payment-information-collection.component.html',
	styleUrls      : ['./payment-information-collection.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PaymentInformationCollectionComponent implements OnInit, OnDestroy {

	public cardDetailForm: FormGroup;
	public ePayForm: FormGroup;
	public getResponse: USAePay = new USAePay();
	public isLoaded: boolean = false;
	public isPostInvalid: boolean = false;
	public payload: USAePayPayload = new USAePayPayload();
	public postError: IError = new IError();
	public settings: SettingsState;

	private subscriptions: Subscription[] = [];

	constructor (
		public cd: ChangeDetectorRef,
		private fb: FormBuilder,
		public service: MyBenefitsService,
		public store: Store<any>,
		private valid: ValidationService,
		public maskService: MaskService,
	) {
		this.buildCardForm();
	}

	ngOnInit(): void {
		const settingsSubscription = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
		this.buildCardForm();
		this.getPaymentInformation();
	}

	ngOnDestroy(): void {
		this.cd.detach();
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	public postForm(): void {
		this.buildPayload();
		this.isPostInvalid = false;
		this.service.postPaymentInformation(this.payload).subscribe();
	}

	public toggleCheckbox(event: HTMLSelectElement): void {
		this.payload.sendReceipt = !!event.value;
		this.cd.detectChanges();
	}

	public maskExp (event: HTMLSelectElement) {
		const original = event.value;
		const justNumbers = original.replace(/[^0-9/]+/g, '');
		const split = justNumbers.split('');
		if (split.length > 2 && split[2] !== '/') {
			split.splice(2, 0, '/');
		}
		event.value = split.join('').substring(0, 5);
		this.cd.detectChanges();
	}

	private getPaymentInformation (): void {
		this.service.getPaymentInformation().subscribe(info => {
			this.buildEPayForm(info);
			this.cd.detectChanges();
		});
	}

	private buildEPayForm(response: USAePay): void {
		this.ePayForm = this.fb.group({
			firstName       : [response ? response.firstName : '', Validators.compose([Validators.required])],
			lastName        : [response ? response.lastName : '', Validators.compose([Validators.required])],
			homeAddressLine1: [response ? response.homeAddressLine1 : '', Validators.compose([Validators.required])],
			homeAddressLine2: [response ? response.homeAddressLine2 : '', Validators.compose([])],
			homeCity        : [response ? response.homeCity : '', Validators.compose([Validators.required])],
			homeState       : [response ? response.homeState : '', Validators.compose([Validators.required])],
			homeZipCode     : [response ? response.homeZipCode : '', Validators.compose([ValidationZipcode.validZipcode(true)])],
			homeEmail       : [response ? response.homeEmail : ''],
		});
	}

	private buildCardForm(): void {
		this.cardDetailForm = this.fb.group({
			cardNumber    : ['', Validators.compose([this.valid.numeric.numbersOnly, Validators.required])],
			cardExpiration: ['', Validators.compose([Validators.required])],
		});
	}

	private buildPayload(): void {
		for (const property in this.payload) {
			if (this.payload.hasOwnProperty(property)) {
				if (this.ePayForm.controls[property]) {
					this.payload[property] = this.ePayForm.controls[property].value;
				}
				if (this.cardDetailForm.controls[property]) {
					this.payload[property] = this.cardDetailForm.controls[property].value;
				}
				if (property === 'cardExpiration') {
					this.payload[property] = this.cardDetailForm.controls[property].value.replace(/[^0-9]+/g, '').substring(0, 4);
				}
			}
		}
	}
}
