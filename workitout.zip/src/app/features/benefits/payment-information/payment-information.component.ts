import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	HostBinding,
	OnDestroy,
	OnInit,
}                             from '@angular/core';
import { ActivatedRoute }     from '@angular/router';

import { Store }              from '@ngrx/store';
import { Subscription }       from 'rxjs';

import { animator }           from '../../../infrastructure/core/animations/animations';
import { BenefitSummaryList } from '../../../infrastructure/interfaces/benefit';
import { SettingsState }      from '../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector       : 'hg-payment-information',
	templateUrl    : './payment-information.component.html',
	styleUrls      : ['./payment-information.component.scss'],
	animations     : [animator.slide],
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PaymentInformationComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	public benefitList: BenefitSummaryList;
	public settings: SettingsState;

	private subscriptions: Subscription[] = [];

	constructor (
		public cd: ChangeDetectorRef,
		private route: ActivatedRoute,
		private store: Store<any>,
	) {
		this.benefitList = this.route.snapshot.data['benefits'];
	}

	ngOnInit () {
		this.initializeState();
	}

	ngOnDestroy () {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	private initializeState (): void {
		const settingsSubscription = this.store.select('settingsState').subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}
}
