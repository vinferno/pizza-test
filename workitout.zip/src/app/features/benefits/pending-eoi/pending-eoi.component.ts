import {
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	Component,
	OnDestroy,
	OnInit,
	HostBinding,
}                             from '@angular/core';
import { ActivatedRoute }     from '@angular/router';

import { Store }              from '@ngrx/store';
import {
	Observable,
	Subscription,
}                             from 'rxjs';

import { animator }           from '../../../infrastructure/core/animations/animations';
import { BenefitSummaryList } from '../../../infrastructure/interfaces/benefit';
import { SettingsState }      from '../../../infrastructure/store/reducers/settings/settings-state';

@Component({
	selector        : 'hg-pending-eoi',
	templateUrl     : './pending-eoi.component.html',
	styleUrls       : ['./pending-eoi.component.scss'],
	animations      : [animator.slide],
	changeDetection : ChangeDetectionStrategy.OnPush,
})
export class PendingEOIComponent implements OnInit, OnDestroy {
	@HostBinding('@routeAnimation') 'true';
	@HostBinding('style.display') display = 'block';

	public pendingEOIList: BenefitSummaryList;
	public settings: SettingsState;

	private settingsState: Observable<SettingsState>;
	private subscriptions: Subscription[] = [];

	constructor(
		public cd: ChangeDetectorRef,
		private route: ActivatedRoute,
		private store: Store<any>,
	) {
		this.pendingEOIList = this.route.snapshot.data['benefits'];
	}

	ngOnInit() {
		this.initializeState();
	}

	ngOnDestroy() {
		this.cd.detach();
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	private initializeState(): void {
		this.settingsState = this.store.select('settingsState');
		const settingsSubscription = this.settingsState.subscribe(settings => {
			this.settings = settings;
			this.cd.detectChanges();
		});
		this.subscriptions.push(settingsSubscription);
	}
}
