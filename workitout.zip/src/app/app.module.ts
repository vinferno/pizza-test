import { FooterService }                    from './infrastructure/core/services/footer.service';
import { ControlsModule }                   from './infrastructure/shared/controls/controls.module';
import { BrowserModule, Title }             from '@angular/platform-browser';
import { BrowserAnimationsModule }          from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	HttpClientModule,
	HttpClientXsrfModule,
}                                           from '@angular/common/http';
import { NgModule }                         from '@angular/core';
import { FlexLayoutModule }                 from '@angular/flex-layout';

import { Ng2Webstorage } from 'ngx-webstorage';
import { RecaptchaModule } from 'ng-recaptcha';
import { NgProgressModule } from '@ngx-progressbar/core';
import { NgProgressHttpModule } from '@ngx-progressbar/http';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { ToastrModule } from 'ngx-toastr';
import 'hammerjs';

import { CovalentModule } from './infrastructure/utils/covalent.module';
import { DevExtremeModule } from './infrastructure/utils/devextreme.module';
import { MaterialModule } from './infrastructure/utils/material.module';
import { AuthService } from './infrastructure/auth/auth.service';
import { AgentAuthService } from './infrastructure/auth/agent-auth.service';
import { CoreModule } from './infrastructure/core/core.module';
import { DashboardModule } from './features/dashboard/dashboard.module';
import { EnrollmentModuleAddService } from './infrastructure/enrollment/enroll-module-add.service';
import { EnrollmentModuleBuyupService } from './infrastructure/enrollment/enroll-module-buyup.service';
import { EnrollmentAddService } from './infrastructure/enrollment/enrollment-add.service';
import { EnrollmentBuyupService } from './infrastructure/enrollment/enrollment-buyup.service';
import { EnrollmentCancelService } from './infrastructure/enrollment/enrollment-cancel.service';
import { EnrollmentDashboardService } from './infrastructure/enrollment/enrollment-dashboard.service';
import { EnrollmentWizardFormService } from './infrastructure/enrollment/enrollment-wizard-form.service';
import { EnrollmentFSAService } from './infrastructure/enrollment/enrollment-fsa.service';
import { EnrollmentTerminateService } from './infrastructure/enrollment/enrollment-terminate.service';
import { EnrollmentWaiveService } from './infrastructure/enrollment/enrollment-waive.service';
import { EnrollmentWizardService } from './infrastructure/enrollment/enrollment-wizard.service';
import { FingerprintService } from './infrastructure/auth/fingerprint.service';
import { LandingModule } from './infrastructure/landing/landing.module';
import { NavigationModule } from './infrastructure/navigation/navigation.module';
import { SharedModule } from './infrastructure/shared/shared.module';
import { AppRoutingModule, routedComponents as mainAppRoutedComponents } from './app-routing.module';

import { AppComponent } from './app.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { StoreModule } from '@ngrx/store';
import { reducers } from './infrastructure/store/reducers/reducers-index';
import { TitleService } from './infrastructure/core/services/title.service';
import { ResizeService } from './infrastructure/core/services/resize.service';

import { environment } from 'environments/environment';
import { DisableAfterService } from './infrastructure/core/services/disableAfter.service';
import { ServiceWorkerModule } from '@angular/service-worker';

import { AccordionModule } from 'primeng/accordion';
import { DropdownModule } from 'primeng/dropdown';


@NgModule({
	declarations: [
		AppComponent,
		DashboardComponent,
		mainAppRoutedComponents,
	],
	imports: [
		StoreModule.forRoot(reducers),
		environment.imports,
		BrowserModule,
		BrowserAnimationsModule,
		CoreModule,
		DevExtremeModule,
		MaterialModule,
		CovalentModule,
		DashboardModule,
		FlexLayoutModule,
		FormsModule,
		ReactiveFormsModule,
		HttpClientModule,
		HttpClientXsrfModule.withOptions(getXSRF()),
		NgProgressModule.forRoot(),
		NgProgressHttpModule.forRoot(),
		LandingModule,
		NavigationModule,
		Ng2Webstorage,
		SharedModule.forRoot(),
		ControlsModule,
		RecaptchaModule.forRoot(),
		RecaptchaFormsModule,
		ToastrModule.forRoot({
			timeOut: 5000,
			preventDuplicates: true,
		}),
		AppRoutingModule,
		ServiceWorkerModule.register('../public/sw.js', {enabled: environment.production}),
		AccordionModule,
		DropdownModule,
	],
	providers: [
		Title,
		AgentAuthService,
		AuthService,
		EnrollmentModuleAddService,
		EnrollmentModuleBuyupService,
		EnrollmentAddService,
		EnrollmentBuyupService,
		EnrollmentCancelService,
		EnrollmentDashboardService,
		EnrollmentWizardFormService,
		EnrollmentFSAService,
		EnrollmentTerminateService,
		EnrollmentWizardService,
		EnrollmentWaiveService,
		FingerprintService,
		FooterService,
		TitleService,
		ResizeService,
		DisableAfterService,
	],
	bootstrap: [AppComponent],
})
export class AppModule {
}

export function getXSRF(): XSRF {
	return (environment.production)
		? { cookieName: '__Host-XSRF-TOKEN', headerName: 'X-XSRF-TOKEN' }
		: { cookieName: 'XSRF-TOKEN', headerName: 'X-XSRF-TOKEN' };
}

export interface XSRF {
	cookieName: string;
	headerName: string;
}
