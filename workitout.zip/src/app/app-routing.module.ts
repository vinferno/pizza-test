import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [
	{
		path        : 'counselor',
		loadChildren: './features/agent-dashboard/agent-dashboard.module#AgentDashboardModule',
		data        : { title: 'Counselor' },
	},
	{
		path     : '**',
		component: NotFoundComponent,
	},
];

@NgModule({
	imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled', useHash: true })],
	exports: [RouterModule],
})
export class AppRoutingModule {
}

export const routedComponents = [NotFoundComponent];
