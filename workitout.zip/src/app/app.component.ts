import {
	Event,
	NavigationCancel,
	NavigationEnd,
	NavigationStart,
	Router,
	RoutesRecognized,
}                                from '@angular/router';
import {
	AfterContentChecked,
	AfterContentInit,
	ApplicationRef,
	ChangeDetectorRef,
	Component,
	HostBinding,
	OnInit,
	ElementRef,
	ViewChild,
}                                from '@angular/core';
import { Title }                 from '@angular/platform-browser';
import { SwUpdate }              from '@angular/service-worker';

import { Store }                 from '@ngrx/store';
import {
	Observable,
	Subscription,
	asyncScheduler,
}                                from 'rxjs';
import { filter,
		 observeOn,
		 scan,
}								 from 'rxjs/operators'

import { Constants, IConstants } from './infrastructure/utils/constants';
import { AuthService }           from './infrastructure/auth/auth.service';
import { AgentAuthService }      from './infrastructure/auth/agent-auth.service';
import { ContentHeaderService }  from './infrastructure/core/services/content-header.service';
import { EnrollmentState }       from './infrastructure/store/reducers/enrollment/enrollment-state';
import { FooterService }         from './infrastructure/core/services/footer.service';
import { IContentHeaderPayload } from './infrastructure/interfaces/content-header';
import { LocalService }          from './infrastructure/core/services/local-storage.service';
import {
	NAVIGATION_CANCEL,
	NAVIGATION_END,
	NAVIGATION_RECOGNIZED,
}                                from './infrastructure/store/reducers/router/router-state';
import { ResizeService }         from './infrastructure/core/services/resize.service';
import { SessionService }        from './infrastructure/core/services/session-storage.service';
import { SessionState }          from './infrastructure/store/reducers/session/session-state';
import { SettingsState }         from './infrastructure/store/reducers/settings/settings-state';
import { stateActions }          from './infrastructure/store/reducers/reducers-index';
import { SubnavState } 			 from './infrastructure/store/reducers/sub-nav/sub-nav-state';
import { environment }           from 'environments/environment';

interface ScrollPositionRestore {
	event: Event;
	positions: { [K: number]: number };
	trigger: 'imperative' | 'popstate' | 'hashchange';
	idToRestore: number;
  }

@Component({
	selector    : 'hg-root',
	templateUrl : './app.component.html',
	styleUrls   : ['./app.component.scss'],
})
export class AppComponent implements OnInit, AfterContentChecked, AfterContentInit {
	@ViewChild('appcontent') private contentArea: ElementRef<HTMLElement>;

	@HostBinding('class') myTheme = ['default'];
	@HostBinding('class.logged-in') logged = false;
	@HostBinding('class.small') BPSmall = false;
	@HostBinding('class.medium') BPMedium = false;
	@HostBinding('class.large') BPLarge = false;
	@HostBinding('class.x-large') BPXLarge = false;
	@HostBinding('class.xx-large') BPXXLarge = false;

	/*	Screen Sizes:
	*	We are using the standard screen sizes provieded by boot strap.
	*	https://getbootstrap.com/docs/4.3/layout/overview/
	* 	Standard monitor size is from the below website, at 2019 the US standard is 1920x1080
	*   https://gs.statcounter.com/screen-resolution-stats/desktop/united-states-of-america
	*/
	public bootStrapPoints = {
		phone : 0,
		landscapePhones : 576,
		tablets : 768,
		laptops : 992,
		computers : 1200,
		stdMonitorSize : 1920,
	};
	public constant: IConstants = Constants;
	public ddlOptions: any;
	public enrollment: EnrollmentState;
	public session: SessionState;
	public settings: SettingsState;
	public subnav: SubnavState;
	public ui;
	public url;

	private enrollmentState: Observable<EnrollmentState>;
	private routerState: Observable<any>;
	private sessionState: Observable<SessionState>;
	private subscriptions: Subscription[] = [];
	private uiState: Observable<any>;

	public constructor (
		public auth: AuthService,
		public agentAuth: AgentAuthService,
		public router: Router,
		public updates: SwUpdate,

		private applicationRef: ApplicationRef,
		private cd: ChangeDetectorRef,
		private contentHeaderService: ContentHeaderService,
		private footerService: FooterService,
		private localService: LocalService,
		private resizeService: ResizeService,
		private sessionService: SessionService,
		private store: Store<any>,
		private titleService: Title,
	) {
		this.sessionService.init();
		this.localService.init();
		this.initializeState();
		this.initializeRoutes();
	}

	public ngOnInit(): void {
		this.localService.currentTheme.subscribe(theme => this.changeTheme(theme));
		this.onResize(null);
		this.initializeUpdatesCheck();
	}

	public ngAfterContentInit(): void {
		window.applicationCache.addEventListener('updateready', this.onUpdateReady);
		if (window.applicationCache.status === window.applicationCache.UPDATEREADY) {
			this.onUpdateReady();
		}
	}

	public ngAfterContentChecked(): void {
		this.cd.detectChanges();
	}

	public initializeUpdatesCheck(): void {
		if (environment.production) {
			this.updates.available.subscribe(() => {
				this.updates.activateUpdate().then(() => {
					window.alert('There is a new version of MyWorkplace available. Click OK to reload');
					document.location.reload();
				});
			});
			this.updates.checkForUpdate().then(() => { });
		}
	}

	public changeTheme(theme?: string): void {
		this.myTheme = [theme];
	}

	public reAdjustFooter() {
		if (document.getElementsByClassName('page')[0]) {
			this.footerService.updateFixedFooter(true);
		}
	}

	public onResize($event): void {
		this.resizeService.resize($event);
	}

	private initializeState(): void {
		this.enrollmentState = this.store.select('enrollmentState');
		const enrollmentSubscription = this.enrollmentState.subscribe(enrollment => {
			this.enrollment = enrollment;
		});
		this.store.select('subnavState').subscribe( subnav => {
			this.subnav = subnav;
		});
		this.subscriptions.push(enrollmentSubscription);
		this.sessionState = this.store.select('sessionState');
		const sessionSubscription = this.sessionState.subscribe(session => {
			this.session = session;
			this.logged = this.auth.isMemberLoggedIn() || this.agentAuth.isAgentLoggedIn();
		});
		this.subscriptions.push(sessionSubscription);
		this.routerState = this.store.select('routerState');
		const urlSubscription = this.routerState.subscribe(url => {
			this.url = url;
		});
		this.subscriptions.push(urlSubscription);
		this.uiState = this.store.select('uiState');
		const uiSubscription = this.uiState.subscribe(ui => {
			this.ui = ui;
			if (this.ui && this.ui.windowWidth && this.ui.type === stateActions.uiActions.types.UI_UPDATE_WINDOW_WIDTH) {
				let screenSize = '';

				switch (true) {
					case this.ui.windowWidth >= this.bootStrapPoints.stdMonitorSize:
						screenSize = 'x-large';
						break;
					case this.ui.windowWidth >= this.bootStrapPoints.computers:
					case this.ui.windowWidth >= this.bootStrapPoints.laptops:
						screenSize = 'large';
						break;
					case this.ui.windowWidth >= this.bootStrapPoints.tablets:
						screenSize = 'medium';
						break;
					default:
						screenSize = 'small';
						break;
				}

				this.store.dispatch(stateActions.uiActions.updateUiIsTabletSize({
					isTabletSize: this.ui.windowWidth < this.bootStrapPoints.laptops,
				}));

				if (this.ui.mediaQueryState !== screenSize) {
					this.setHostBindingSize(screenSize);
					this.store.dispatch(stateActions.uiActions.updateMediaQueryState({ mediaQueryState: screenSize }));
					return;
				} else {
					return;
				}
			}
		});
		this.subscriptions.push(uiSubscription);
		this.store.select('settingsState').subscribe(settings => {
			if (this.settings && this.settings.language !== settings.language) {
				this.getApiTitle();
			}
			this.settings = settings;
		});

		this.router.events
		.pipe(
		  filter(
			event =>
			  event instanceof NavigationStart || event instanceof NavigationEnd,
		  ),
		  scan<Event, ScrollPositionRestore>((acc, event) => ({
			event,
			positions: {
			  ...acc.positions,
			  ...(event instanceof NavigationStart
				? {
					[event.id]: this.contentArea.nativeElement.scrollTop,
				  }
				: {}),
			},
			trigger:
			  event instanceof NavigationStart
				? event.navigationTrigger
				: acc.trigger,
			idToRestore:
			  (event instanceof NavigationStart &&
				event.restoredState &&
				event.restoredState.navigationId + 1) ||
			  acc.idToRestore,
		  })),
		  filter(
			({ event, trigger }) => event instanceof NavigationEnd && !!trigger,
		  ),
		  observeOn(asyncScheduler),
		)
		.subscribe(({ trigger, positions, idToRestore }) => {
		  if (trigger === 'imperative') {
			this.contentArea.nativeElement.scrollTop = 0;
		  }

		  if (trigger === 'popstate') {
			this.contentArea.nativeElement.scrollTop = positions[idToRestore];
		  }
		});
	}

	private getApiTitle(): void {
		if (!this.url || !this.url.current || !this.url.current.url) {
			return;
		}
		const urlString = this.url.current.url.substring(1, this.url.current.url.length);
		if (
			urlString &&
			typeof urlString === 'string' &&
			this.checkBlacklist(urlString)
		) {
			const payload: IContentHeaderPayload = {
				route   : urlString,
				language: 'en',
			};
			this.contentHeaderService.getContentHeader(payload).subscribe((response) => {
				if (response.showContentHeader) {
					if (response.contentTitle.indexOf('Dependents') > -1) { this.applicationRef.tick(); }
				} else {
					this.clearTitle();
				}
			});
		} else {
			this.clearTitle();
		}
	}

	private checkBlacklist(urlString: string): boolean {
		if (this.constant.blacklist.indexOf(urlString) === -1) {
			const isFound = this.constant.blacklistWildcard.filter(route => urlString.includes(route));

			return Boolean(!isFound.length);
		}
	}

	private clearTitle(): void {
		this.store.dispatch(stateActions.uiActions.updateUiTitleInstructions({ titleInstructions: '' }));
		this.store.dispatch(stateActions.uiActions.updateUiTitlePicture({ titlePicture: '' }));
		this.store.dispatch(stateActions.uiActions.updateUiTitleIcon({ titleIcon: '' }));
		this.store.dispatch(stateActions.uiActions.updateUiTitle(''));
	}

	private setHostBindingSize(screenSize: string): void {
		this.BPSmall = screenSize === 'small';
		this.BPMedium = screenSize === 'medium';
		this.BPLarge = screenSize === 'large';
		this.BPXLarge = screenSize === 'x-large';
		this.BPXXLarge = screenSize === 'xx-large';
	}

	private onUpdateReady(): void {
		window.alert('There is a new version of MyWorkplace available. Click OK to reload');
		window.applicationCache.swapCache()
	}

	private initializeRoutes(): void {
		this.router.events.subscribe((event: any) => {
			const state = this.router.routerState;
			const snapshot = state.snapshot;
			let route = snapshot.root;
			while (route.firstChild) {
				route = route.firstChild;
			}

			const url = event.url;
			const queryParams = snapshot.root.queryParams;
			const params = route.params;

			if (event instanceof RoutesRecognized) {
				const urlAfterRedirects = event.urlAfterRedirects;
				this.store.dispatch({
					type   : NAVIGATION_RECOGNIZED,
					payload: {
						url: urlAfterRedirects,
						params,
						queryParams,
					},
				});
			}

			if (event instanceof NavigationEnd) {
				const urlAfterRedirects = event.urlAfterRedirects;
				this.store.dispatch({
					type   : NAVIGATION_END,
					payload: {
						url: urlAfterRedirects,
						params,
						queryParams,
					},
				});
				this.getApiTitle();
			}

			if (event instanceof NavigationCancel) {
				this.store.dispatch({
					type   : NAVIGATION_CANCEL,
					payload: {
						url,
						params,
						queryParams,
					},
				});
			}
			this.reAdjustFooter();
		});
	}
}
